<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$regalId = (int)($_POST['regal_id'] ?? 0);

if ($regalId <= 0) {
    echo json_encode([
        "ok" => false,
        "message" => "Ungültiges Regal."
    ]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT voll_gemeldet 
    FROM lager_regale 
    WHERE id = ?
    LIMIT 1
");
mysqli_stmt_bind_param($stmt, "i", $regalId);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($res);

if (!$row) {
    echo json_encode([
        "ok" => false,
        "message" => "Regal wurde nicht gefunden."
    ]);
    exit;
}

$newStatus = ((int)$row['voll_gemeldet'] === 1) ? 0 : 1;
$now = time();

if ($newStatus === 1) {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE lager_regale
        SET 
            voll_gemeldet = 1,
            voll_gemeldet_at = ?,
            voll_hinweis = 'Manuell im Admin markiert'
        WHERE id = ?
    ");
    mysqli_stmt_bind_param($stmt, "ii", $now, $regalId);
} else {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE lager_regale
        SET 
            voll_gemeldet = 0,
            voll_gemeldet_at = NULL,
            voll_hinweis = NULL
        WHERE id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $regalId);
}

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode([
        "ok" => false,
        "message" => "Datenbankfehler beim Speichern."
    ]);
    exit;
}

echo json_encode([
    "ok" => true,
    "new" => $newStatus,
    "message" => $newStatus === 1 
        ? "Regal wurde als voll markiert."
        : "Regal wurde wieder freigegeben."
]);