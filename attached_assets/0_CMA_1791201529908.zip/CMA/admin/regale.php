<?php
require_once "../functions.php";

$res = mysqli_query($dbhandle, "
    SELECT 
        lr.id,
        lr.regal_nr,
        lr.voll_gemeldet_at,
        lr.voll_hinweis,
        lg.gang_nr
    FROM lager_regale lr
    JOIN lager_gaenge lg ON lg.id = lr.gang_id
    WHERE lr.voll_gemeldet = 1
    ORDER BY lr.voll_gemeldet_at DESC
");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Volle Regale</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">
    <div class="admin-header">
        <h1>Volle Regale</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2>Gemeldete volle Regale</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Gang</th>
                        <th>Regal</th>
                        <th>Gemeldet am</th>
                        <th>Hinweis</th>
                        <th>Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($res) === 0): ?>
                        <tr>
                            <td colspan="5">Aktuell sind keine vollen Regale gemeldet.</td>
                        </tr>
                    <?php endif; ?>

                    <?php while ($row = mysqli_fetch_assoc($res)): ?>
                        <tr class="row-full">
                            <td><?= e($row['gang_nr']) ?></td>
                            <td><?= e($row['regal_nr']) ?></td>
                            <td>
                                <?= $row['voll_gemeldet_at'] ? date("d.m.Y H:i", (int)$row['voll_gemeldet_at']) : '-' ?>
                            </td>
                            <td><?= e($row['voll_hinweis']) ?></td>
                            <td>
                                <form method="post" action="free_regal.php" onsubmit="return confirm('Regal wieder freigeben?');">
                                    <input type="hidden" name="regal_id" value="<?= (int)$row['id'] ?>">
                                    <button type="submit" class="admin-save">Wieder freigeben</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>