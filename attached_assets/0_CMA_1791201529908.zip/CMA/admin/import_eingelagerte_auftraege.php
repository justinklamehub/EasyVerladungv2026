<?php require_once "../functions.php"; ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Eingelagerte Aufträge Import</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>Eingelagerte Aufträge Import</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2>CSV-Datei importieren</h2>

        <p>
            Die Tabelle <strong>eingelagerte_auftraege</strong> wird vor dem Import geleert und anschließend neu befüllt.
        </p>

        <div class="admin-form">
            <label>CSV-Datei auswählen</label>
            <input type="file" id="csvFile" accept=".csv">

            <button type="button" class="admin-save" onclick="startAuftraegeImport()">
                Import starten
            </button>
        </div>

        <div class="import-progress-wrap" style="display:none;" id="progressWrap">
            <div class="import-progress-info">
                <strong id="progressText">0%</strong>
                <span id="progressDetails">Warte...</span>
            </div>
            <div class="import-progress-bar">
                <div id="progressBar"></div>
            </div>
        </div>

        <div id="importResult"></div>
    </div>

    <div class="admin-card">
        <h2>Erwarteter CSV Aufbau</h2>

        <div class="csv-preview">
            <table>
                <thead>
                    <tr>
                        <th>Verkaufsb.</th>
                        <th>LFDAT</th>
                        <th>+KW</th>
                        <th>Debitor</th>
                        <th>Kunde Name 1</th>
                        <th>PLZ</th>
                        <th>Beleg</th>
                        <th>ern.ausl.</th>
                        <th>Ret.klasse</th>
                        <th>Parkkennz.</th>
                        <th>Handling Unit</th>
                        <th>Typ</th>
                        <th>Platz</th>
                        <th>Spediteur</th>
                        <th>Name 1</th>
                        <th>Relation</th>
                        <th>Q</th>
                        <th>KartonAnz</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>123456789</td>
                        <td>49.2024</td>
                        <td>02</td>
                        <td>100000</td>
                        <td>Kunde GmbH</td>
                        <td>27568</td>
                        <td>80000123</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>1000661146</td>
                        <td>001</td>
                        <td>01-04</td>
                        <td>4711</td>
                        <td>Spedition Muster</td>
                        <td>HB</td>
                        <td></td>
                        <td>24</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
const BATCH_SIZE = 300;

function parseCsvLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];

        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ';' && !inQuotes) {
            result.push(current.trim().replace(/^"|"$/g, ''));
            current = '';
        } else {
            current += char;
        }
    }

    result.push(current.trim().replace(/^"|"$/g, ''));
    return result;
}

async function startAuftraegeImport() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (!file) {
        alert('Bitte CSV-Datei auswählen.');
        return;
    }

    if (!confirm('Achtung: Die alte Auftragstabelle wird geleert. Fortfahren?')) {
        return;
    }

    document.getElementById('progressWrap').style.display = 'block';
    document.getElementById('importResult').innerHTML = '';
    setProgress(0, 'Datei wird gelesen...');

    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');

    if (lines.length <= 1) {
        setProgress(0, 'Keine Daten gefunden.');
        return;
    }

    const rows = [];

    for (let i = 1; i < lines.length; i++) {
        const cols = parseCsvLine(lines[i]);

        rows.push({
            verkaufsbeleg: cols[0] || '',
            lfdat: cols[1] || '',
            plus_kw: cols[2] || '',
            debitor: cols[3] || '',
            kunde_name1: cols[4] || '',
            plz: cols[5] || '',
            beleg: cols[6] || '',
            ern_ausl: cols[7] || '',
            ret_klasse: cols[8] || '',
            parkkennz: cols[9] || '',
            handling_unit: cols[10] || '',
            typ: cols[11] || '',
            platz: cols[12] || '',
            spediteur: cols[13] || '',
            spediteur_name1: cols[14] || '',
            relation: cols[15] || '',
            q: cols[16] || '',
            kartonanz: cols[17] || '0'
        });
    }

    setProgress(2, 'Tabelle wird geleert...');

    const resetRes = await fetch('ajax_eingelagerte_reset.php', {
        method: 'POST'
    });

    const resetJson = await resetRes.json();

    if (!resetJson.ok) {
        alert(resetJson.message || 'Tabelle konnte nicht geleert werden.');
        return;
    }

    let imported = 0;
    const total = rows.length;

    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const batch = rows.slice(i, i + BATCH_SIZE);

        const res = await fetch('ajax_eingelagerte_batch.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ rows: batch })
        });

        const json = await res.json();

        if (!json.ok) {
            alert(json.message || 'Fehler beim Import.');
            return;
        }

        imported += json.inserted;

        const percent = Math.round((imported / total) * 100);
        setProgress(percent, `${imported} von ${total} Paletten importiert...`);

        await new Promise(r => setTimeout(r, 50));
    }

    setProgress(100, `Import abgeschlossen. ${imported} Paletten importiert.`);

    document.getElementById('importResult').innerHTML = `
        <div class="admin-alert success" style="margin-top:16px;">
            Import erfolgreich. <strong>${imported}</strong> Paletten wurden importiert.
        </div>
    `;
}

function setProgress(percent, text) {
    document.getElementById('progressText').innerText = percent + '%';
    document.getElementById('progressDetails').innerText = text;
    document.getElementById('progressBar').style.width = percent + '%';
}
</script>

</body>
</html>