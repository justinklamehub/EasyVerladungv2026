<?php require_once "../functions.php"; ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>IST-Bestand Import</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>IST-Bestand Import</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2>CSV-Datei importieren</h2>

        <p>
            Die Tabelle <strong>zlthu_istbestand</strong> wird vor dem Import geleert und anschließend neu befüllt.
        </p>

        <div class="admin-form">
            <label>CSV-Datei auswählen</label>
            <input type="file" id="csvFile" accept=".csv">

            <button type="button" class="admin-save" onclick="startIstbestandImport()">
                Import starten
            </button>
        </div>

        <div class="import-progress-wrap" style="display:none;" id="progressWrap">
            <div class="import-progress-info">
                <strong id="progressText">0%</strong>
                <span id="progressDetails">Warte...</span>
            </div>
            <div class="import-progress-bar">
                <div id="progressBar"></div>
            </div>
        </div>

        <div id="importResult"></div>
    </div>

    <div class="admin-card">
        <h2>Beispiel CSV Aufbau</h2>

        <div class="csv-preview">
            <table>
                <thead>
                    <tr>
                        <th>Typ</th>
                        <th>Lagerplatz</th>
                        <th>Material</th>
                        <th>B</th>
                        <th>Dauer</th>
                        <th>Charge</th>
                        <th>Lagereinh.</th>
                        <th>BME</th>
                        <th>Verfüg.Bestand</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>001</td>
                        <td>01-04</td>
                        <td>1</td>
                        <td></td>
                        <td>000096</td>
                        <td>ALLE</td>
                        <td>1000661146</td>
                        <td>ST</td>
                        <td>2,000</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
const BATCH_SIZE = 300;

function parseCsvLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];

        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ';' && !inQuotes) {
            result.push(current.trim().replace(/^"|"$/g, ''));
            current = '';
        } else {
            current += char;
        }
    }

    result.push(current.trim().replace(/^"|"$/g, ''));
    return result;
}

async function startIstbestandImport() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (!file) {
        alert('Bitte CSV-Datei auswählen.');
        return;
    }

    if (!confirm('Achtung: Die alte IST-Bestand-Tabelle wird geleert. Fortfahren?')) {
        return;
    }

    document.getElementById('progressWrap').style.display = 'block';
    document.getElementById('importResult').innerHTML = '';
    setProgress(0, 'Datei wird gelesen...');

    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');

    if (lines.length <= 1) {
        setProgress(0, 'Keine Daten gefunden.');
        return;
    }

    const rows = [];

    for (let i = 1; i < lines.length; i++) {
        const cols = parseCsvLine(lines[i]);

        rows.push({
            typ: cols[0] || '',
            lagerplatz: cols[1] || '',
            material: cols[2] || '',
            b: cols[3] || '',
            dauer: cols[4] || '',
            charge: cols[5] || '',
            lagereinh: cols[6] || '',
            bme: cols[7] || '',
            verfueg_bestand: cols[8] || '0'
        });
    }

    setProgress(2, 'Tabelle wird geleert...');

    const resetRes = await fetch('ajax_istbestand_reset.php', {
        method: 'POST'
    });

    const resetJson = await resetRes.json();

    if (!resetJson.ok) {
        alert(resetJson.message || 'Tabelle konnte nicht geleert werden.');
        return;
    }

    let imported = 0;
    const total = rows.length;

    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const batch = rows.slice(i, i + BATCH_SIZE);

        const res = await fetch('ajax_istbestand_batch.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ rows: batch })
        });

        const json = await res.json();

        if (!json.ok) {
            alert(json.message || 'Fehler beim Import.');
            return;
        }

        imported += json.inserted;

        const percent = Math.round((imported / total) * 100);
        setProgress(percent, `${imported} von ${total} Zeilen importiert...`);

        await new Promise(r => setTimeout(r, 50));
    }

    setProgress(100, `Import abgeschlossen. ${imported} IST-Bestände importiert.`);

    document.getElementById('importResult').innerHTML = `
        <div class="admin-alert success" style="margin-top:16px;">
            Import erfolgreich. <strong>${imported}</strong> Datensätze wurden importiert.
        </div>
    `;
}

function setProgress(percent, text) {
    document.getElementById('progressText').innerText = percent + '%';
    document.getElementById('progressDetails').innerText = text;
    document.getElementById('progressBar').style.width = percent + '%';
}
</script>

</body>
</html>