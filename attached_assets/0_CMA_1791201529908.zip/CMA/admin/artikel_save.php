<?php
require_once "../functions.php";

$artikelnummer = trim($_POST['artikelnummer'] ?? '');
$ean = trim($_POST['ean'] ?? '');
$artikelname = trim($_POST['artikelname'] ?? '');

if ($artikelnummer === '') {
    header("Location: zuordnungen.php");
    exit;
}

// Prüfen ob Artikel schon existiert
$stmt = mysqli_prepare($dbhandle, "
    SELECT id FROM artikel WHERE artikelnummer = ? LIMIT 1
");
mysqli_stmt_bind_param($stmt, "s", $artikelnummer);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if (mysqli_fetch_assoc($res)) {
    // existiert schon → zurück
    header("Location: zuordnungen.php?q=" . urlencode($artikelnummer));
    exit;
}

// Neu anlegen
$stmt = mysqli_prepare($dbhandle, "
    INSERT INTO artikel (artikelnummer, ean, artikelname, aktiv)
    VALUES (?, ?, ?, 1)
");

mysqli_stmt_bind_param($stmt, "sss", $artikelnummer, $ean, $artikelname);
mysqli_stmt_execute($stmt);

// Danach direkt wieder zur Suche
header("Location: zuordnungen.php?q=" . urlencode($artikelnummer));
exit;