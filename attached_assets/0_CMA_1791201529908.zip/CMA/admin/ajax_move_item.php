<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$zuordnungId = (int)($_POST['zuordnung_id'] ?? 0);
$newRegalId  = (int)($_POST['new_regal_id'] ?? 0);

if ($zuordnungId <= 0 || $newRegalId <= 0) {
    echo json_encode([
        "ok" => false,
        "message" => "Ungültige Daten."
    ]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT id
    FROM lager_regale
    WHERE id = ?
      AND aktiv = 1
    LIMIT 1
");
mysqli_stmt_bind_param($stmt, "i", $newRegalId);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if (!mysqli_fetch_assoc($res)) {
    echo json_encode([
        "ok" => false,
        "message" => "Ziel-Regal wurde nicht gefunden."
    ]);
    exit;
}

$now = time();

$stmt = mysqli_prepare($dbhandle, "
    UPDATE einlagerung_zuordnung
    SET regal_id = ?, updated_at = ?
    WHERE id = ?
      AND aktiv = 1
");

mysqli_stmt_bind_param($stmt, "iii", $newRegalId, $now, $zuordnungId);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode([
        "ok" => false,
        "message" => "Verschieben fehlgeschlagen."
    ]);
    exit;
}

echo json_encode([
    "ok" => true,
    "message" => "Zuordnung wurde verschoben."
]);