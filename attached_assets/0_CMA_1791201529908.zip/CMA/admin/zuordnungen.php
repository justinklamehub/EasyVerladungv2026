<?php
require_once "../functions.php";

$q = trim($_GET['q'] ?? '');

$artikel = null;
$zuordnungen = [];

if ($q !== '') {
    $stmt = mysqli_prepare($dbhandle, "
        SELECT id, artikelnummer, ean, artikelname
        FROM artikel
        WHERE artikelnummer = ? OR ean = ?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "ss", $q, $q);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $artikel = mysqli_fetch_assoc($res);

    if ($artikel) {
        $stmt = mysqli_prepare($dbhandle, "
            SELECT 
                ez.id,
                ez.prioritaet,
                ez.hinweis,
                lr.regal_nr,
                lr.id AS regal_id,
                lg.gang_nr,
                kg.name AS kundengruppe,
                kg.farbe,
                lr.voll_gemeldet
            FROM einlagerung_zuordnung ez
            JOIN lager_regale lr ON lr.id = ez.regal_id
            JOIN lager_gaenge lg ON lg.id = lr.gang_id
            LEFT JOIN kundengruppen kg ON kg.id = ez.kundengruppe_id
            WHERE ez.artikel_id = ?
              AND ez.aktiv = 1
            ORDER BY lr.voll_gemeldet ASC, ez.prioritaet ASC, lg.gang_nr ASC, lr.sortierung ASC
        ");
        mysqli_stmt_bind_param($stmt, "i", $artikel['id']);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);

        while ($row = mysqli_fetch_assoc($res)) {
            $zuordnungen[] = $row;
        }
    }
}

$regale = mysqli_query($dbhandle, "
    SELECT lr.id, lr.regal_nr, lg.gang_nr, lr.voll_gemeldet
    FROM lager_regale lr
    JOIN lager_gaenge lg ON lg.id = lr.gang_id
    WHERE lr.aktiv = 1
    ORDER BY lg.gang_nr ASC, lr.sortierung ASC
");

$kundengruppen = mysqli_query($dbhandle, "
    SELECT id, name, farbe
    FROM kundengruppen
    ORDER BY name ASC
");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Artikel-Zuordnungen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">
    <div class="admin-header">
        <h1>Artikel-Zuordnungen</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <form method="get" class="admin-search" autocomplete="off" autofocus>
        <label>Artikelnummer, EAN oder Artikelname</label>

        <div class="admin-autocomplete-wrap">
            <div class="admin-search-row">
                <input 
                    type="text" 
                    id="articleSearchInput"
                    name="q" 
                    value="<?= e($q) ?>" 
                    placeholder="Mind. 2 Zeichen eingeben..." 
                    autofocus
                >
                <button type="submit">Suchen</button>
            </div>

            <div id="articleSuggestions" class="article-suggestions"></div>
        </div>
    </form>

    <?php if ($q !== '' && !$artikel): ?>
    <div class="admin-alert error">
        Artikel wurde nicht gefunden.
    </div>

    <div class="admin-card">
        <h2>Neuen Artikel anlegen</h2>

        <form method="post" action="artikel_save.php" class="admin-form">
            <label>Artikelnummer</label>
            <input type="text" name="artikelnummer" value="<?= e($q) ?>" required>

            <label>EAN</label>
            <input type="text" name="ean" placeholder="Optional">

            <label>Artikelname</label>
            <input type="text" name="artikelname" placeholder="z. B. Batterie XYZ">

            <button type="submit" class="admin-save">Artikel anlegen</button>
        </form>
    </div>
    <?php endif; ?>

    <?php if ($artikel): ?>
        <div class="admin-card">
            <h2><?= e($artikel['artikelnummer']) ?></h2>

            <form method="post" action="artikel_update.php" class="admin-form" style="margin-top:15px;">
                <input type="hidden" name="artikel_id" value="<?= (int)$artikel['id'] ?>">
                <input type="hidden" name="q" value="<?= e($q) ?>">

                <label>EAN</label>
                <input type="text" name="ean" value="<?= e($artikel['ean']) ?>">

                <label>Artikelname</label>
                <input type="text" name="artikelname" value="<?= e($artikel['artikelname']) ?>">

                <button type="submit" class="admin-save">Artikel speichern</button>
            </form>

            <p><?= e($artikel['artikelname']) ?></p>
            <small>EAN: <?= e($artikel['ean']) ?></small>
        </div>

        <div class="admin-card">
            <h2>Neue Zuordnung hinzufügen</h2>

            <form method="post" action="save_zuordnung.php" class="admin-form">
                <input type="hidden" name="artikel_id" value="<?= (int)$artikel['id'] ?>">
                <input type="hidden" name="q" value="<?= e($q) ?>">

                <label>Regal</label>
                <select name="regal_id" required>
                    <option value="">Bitte wählen</option>
                    <?php while ($r = mysqli_fetch_assoc($regale)): ?>
                        <option value="<?= (int)$r['id'] ?>">
                            Gang <?= e($r['gang_nr']) ?> / Regal <?= e($r['regal_nr']) ?>
                            <?= ((int)$r['voll_gemeldet'] === 1) ? ' - VOLL' : '' ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label>Priorität</label>
                <input type="number" name="prioritaet" value="1" min="1" max="99" required>

                <label>Kundengruppe</label>
                <select name="kundengruppe_id">
                    <option value="">Keine Kundengruppe</option>
                    <?php while ($kg = mysqli_fetch_assoc($kundengruppen)): ?>
                        <option value="<?= (int)$kg['id'] ?>">
                            <?= e($kg['name']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label>Hinweis</label>
                <input type="text" name="hinweis" placeholder="Optionaler Hinweis">

                <button type="submit" class="admin-save">Zuordnung speichern</button>
            </form>
        </div>

        <div class="admin-card">
            <h2>Aktuelle Zuordnungen</h2>

            <?php if (count($zuordnungen) === 0): ?>
                <p>Für diesen Artikel gibt es noch keine Zuordnung.</p>
            <?php else: ?>
                <div class="admin-table-wrap">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Prio</th>
                                <th>Gang</th>
                                <th>Regal</th>
                                <th>Kundengruppe</th>
                                <th>Hinweis</th>
                                <th>Status</th>
                                <th>Aktion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($zuordnungen as $z): ?>
                                <tr class="<?= ((int)$z['voll_gemeldet'] === 1) ? 'row-full' : '' ?>">
                                    <td><?= (int)$z['prioritaet'] ?></td>
                                    <td><?= e($z['gang_nr']) ?></td>
                                    <td><?= e($z['regal_nr']) ?></td>
                                    <td>
                                        <?php if ($z['kundengruppe']): ?>
                                            <span class="kg-badge" style="background:<?= e($z['farbe'] ?: '#ddd') ?>">
                                                <?= e($z['kundengruppe']) ?>
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?= e($z['hinweis']) ?></td>
                                    <td>
                                        <?= ((int)$z['voll_gemeldet'] === 1) ? 'Voll gemeldet' : 'Frei' ?>
                                    </td>
                                    <td>
                                        <form method="post" action="delete_zuordnung.php" onsubmit="return confirm('Zuordnung wirklich löschen?');">
                                            <input type="hidden" name="id" value="<?= (int)$z['id'] ?>">
                                            <input type="hidden" name="q" value="<?= e($q) ?>">
                                            <button type="submit" class="admin-delete">Löschen</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script>
const articleInput = document.getElementById('articleSearchInput');
const suggestionsBox = document.getElementById('articleSuggestions');

let autocompleteTimer = null;

articleInput.addEventListener('input', function () {
    const value = articleInput.value.trim();

    clearTimeout(autocompleteTimer);

    if (value.length < 2) {
        suggestionsBox.innerHTML = '';
        suggestionsBox.style.display = 'none';
        return;
    }

    autocompleteTimer = setTimeout(() => {
        fetch('ajax_article_search.php?q=' + encodeURIComponent(value))
            .then(response => response.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    suggestionsBox.innerHTML = `
                        <div class="article-suggestion-empty">
                            Keine Treffer gefunden
                        </div>
                    `;
                    suggestionsBox.style.display = 'block';
                    return;
                }

                let html = '';

                data.forEach(item => {
                    html += `
                        <div class="article-suggestion-item" onclick="selectArticle('${escapeJs(item.artikelnummer)}')">
                            <strong>${escapeHtml(item.artikelnummer)}</strong>
                            <span>${escapeHtml(item.artikelname || '')}</span>
                            ${item.ean ? `<small>EAN: ${escapeHtml(item.ean)}</small>` : ''}
                        </div>
                    `;
                });

                suggestionsBox.innerHTML = html;
                suggestionsBox.style.display = 'block';
            })
            .catch(() => {
                suggestionsBox.innerHTML = '';
                suggestionsBox.style.display = 'none';
            });
    }, 250);
});

function selectArticle(artikelnummer) {
    window.location.href = 'zuordnungen.php?q=' + encodeURIComponent(artikelnummer);
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.admin-autocomplete-wrap')) {
        suggestionsBox.style.display = 'none';
    }
});

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function escapeJs(value) {
    return String(value ?? '')
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('"', '\\"');
}
</script>

</body>
</html>