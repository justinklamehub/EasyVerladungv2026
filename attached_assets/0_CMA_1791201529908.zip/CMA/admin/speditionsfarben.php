<?php
require_once "../functions.php";

$editId = (int)($_GET['edit'] ?? 0);
$editRow = null;

if ($editId > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        SELECT id, spediteur_name1, farbe, textfarbe, aktiv
        FROM speditionsfarben
        WHERE id = ?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "i", $editId);
    mysqli_stmt_execute($stmt);
    $resEdit = mysqli_stmt_get_result($stmt);
    $editRow = mysqli_fetch_assoc($resEdit);
}

$res = mysqli_query($dbhandle, "
    SELECT id, spediteur_name1, farbe, textfarbe, aktiv
    FROM speditionsfarben
    ORDER BY spediteur_name1 ASC
");

$missingRes = mysqli_query($dbhandle, "
    SELECT DISTINCT ea.spediteur_name1
    FROM eingelagerte_auftraege ea
    LEFT JOIN speditionsfarben sf
        ON sf.spediteur_name1 = ea.spediteur_name1
    WHERE ea.spediteur_name1 <> ''
      AND sf.id IS NULL
    ORDER BY ea.spediteur_name1 ASC
");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Speditionsfarben</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>Speditionsfarben</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2><?= $editRow ? 'Speditionsfarbe bearbeiten' : 'Neue Speditionsfarbe anlegen' ?></h2>

        <form method="post" action="speditionsfarbe_save.php" class="admin-form">
            <input type="hidden" name="id" value="<?= (int)($editRow['id'] ?? 0) ?>">

            <label>Spedition</label>
            <input 
                type="text" 
                name="spediteur_name1" 
                list="speditionsListe"
                value="<?= e($editRow['spediteur_name1'] ?? '') ?>" 
                required
            >

            <datalist id="speditionsListe">
                <?php mysqli_data_seek($missingRes, 0); ?>
                <?php while ($sp = mysqli_fetch_assoc($missingRes)): ?>
                    <option value="<?= e($sp['spediteur_name1']) ?>"></option>
                <?php endwhile; ?>
            </datalist>

            <label>Hintergrundfarbe</label>
            <div class="color-picker-wrap">
                <input type="color" id="farbePicker" value="<?= e($editRow['farbe'] ?? '#ede9fe') ?>">
                <input type="text" name="farbe" id="farbeInput" value="<?= e($editRow['farbe'] ?? '#ede9fe') ?>">
            </div>

            <label>Textfarbe</label>
            <div class="color-picker-wrap">
                <input type="color" id="textfarbePicker" value="<?= e($editRow['textfarbe'] ?? '#111827') ?>">
                <input type="text" name="textfarbe" id="textfarbeInput" value="<?= e($editRow['textfarbe'] ?? '#111827') ?>">
            </div>

            <label style="display:flex; align-items:center; gap:8px; margin-top:8px;">
                <input 
                    type="checkbox" 
                    name="aktiv" 
                    value="1"
                    <?= !isset($editRow['aktiv']) || (int)$editRow['aktiv'] === 1 ? 'checked' : '' ?>
                    style="width:auto;"
                >
                Aktiv
            </label>

            <button type="submit" class="admin-save">
                <?= $editRow ? 'Speichern' : 'Anlegen' ?>
            </button>

            <?php if ($editRow): ?>
                <a href="speditionsfarben.php" class="admin-back" style="display:inline-block; margin-top:10px;">
                    Abbrechen
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="admin-card">
        <h2>Bestehende Speditionsfarben</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Spedition</th>
                        <th>Hintergrund</th>
                        <th>Textfarbe</th>
                        <th>Vorschau</th>
                        <th>Status</th>
                        <th>Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($res) === 0): ?>
                        <tr>
                            <td colspan="6">Noch keine Speditionsfarben vorhanden.</td>
                        </tr>
                    <?php endif; ?>

                    <?php while ($row = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= e($row['spediteur_name1']) ?></td>
                            <td><?= e($row['farbe']) ?></td>
                            <td><?= e($row['textfarbe']) ?></td>
                            <td>
                                <span 
                                    class="kg-badge" 
                                    style="
                                        background:<?= e($row['farbe'] ?: '#ede9fe') ?>;
                                        color:<?= e($row['textfarbe'] ?: '#111827') ?>;
                                    "
                                >
                                    <?= e($row['spediteur_name1']) ?>
                                </span>
                            </td>
                            <td>
                                <?= (int)$row['aktiv'] === 1 ? 'Aktiv' : 'Inaktiv' ?>
                            </td>
                            <td style="display:flex; gap:8px;">
                                <a class="admin-small-btn" href="speditionsfarben.php?edit=<?= (int)$row['id'] ?>">
                                    Bearbeiten
                                </a>

                                <form method="post" action="speditionsfarbe_delete.php" onsubmit="return confirm('Speditionsfarbe wirklich löschen?');">
                                    <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                                    <button type="submit" class="admin-delete">Löschen</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function bindColorPicker(pickerId, inputId) {
    const picker = document.getElementById(pickerId);
    const input = document.getElementById(inputId);

    function updateColor(val) {
        input.value = val;
        input.style.background = val;

        const r = parseInt(val.substr(1,2),16);
        const g = parseInt(val.substr(3,2),16);
        const b = parseInt(val.substr(5,2),16);
        const brightness = (r*299 + g*587 + b*114) / 1000;

        input.style.color = brightness > 150 ? '#000' : '#fff';
    }

    updateColor(input.value);

    picker.addEventListener('input', () => {
        updateColor(picker.value);
    });

    input.addEventListener('input', () => {
        if(/^#([0-9A-F]{3}){1,2}$/i.test(input.value)){
            picker.value = input.value;
            updateColor(input.value);
        }
    });
}

bindColorPicker('farbePicker', 'farbeInput');
bindColorPicker('textfarbePicker', 'textfarbeInput');
</script>

</body>
</html>