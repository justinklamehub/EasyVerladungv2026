<?php
require_once "../functions.php";

$spedition = trim($_GET['spedition'] ?? '');
$relation  = trim($_GET['relation'] ?? '');
$lfdat     = trim($_GET['lfdat'] ?? '');
$plus_kw   = trim($_GET['plus_kw'] ?? '');

$speditionEsc = mysqli_real_escape_string($dbhandle, $spedition);
$relationEsc  = mysqli_real_escape_string($dbhandle, $relation);
$lfdatEsc      = mysqli_real_escape_string($dbhandle, $lfdat);
$plusKwEsc     = mysqli_real_escape_string($dbhandle, $plus_kw);

$res = mysqli_query($dbhandle, "
    SELECT
        verkaufsbeleg,
        lfdat,
        plus_kw,
        debitor,
        kunde_name1,
        parcours_plz,
        beleg,
        ret_klasse,
        parkkennz,
        handling_unit,
        typ,
        platz,
        spediteur,
        spediteur_name1,
        relation,
        q,
        kartonanz
    FROM eingelagerte_auftraege
    WHERE spediteur_name1 = '{$speditionEsc}'
      AND relation = '{$relationEsc}'
      AND lfdat = '{$lfdatEsc}'
      AND plus_kw = '{$plusKwEsc}'
    ORDER BY platz ASC, kunde_name1 ASC, handling_unit ASC
");
?>

<style>
.detail-summary {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin-bottom: 16px;
}

.detail-box {
    background: #f8fafc;
    border-radius: 14px;
    padding: 12px;
}

.detail-box small {
    display: block;
    color: #64748b;
    font-weight: 800;
    text-transform: uppercase;
    font-size: 11px;
    margin-bottom: 4px;
}

.detail-box strong {
    color: #111827;
    font-size: 15px;
}

.detail-table-wrap {
    overflow: auto;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
}

.detail-table {
    width: 100%;
    min-width: 950px;
    border-collapse: collapse;
    font-size: 13px;
}

.detail-table th {
    background: #111827;
    color: #fff;
    padding: 11px;
    text-align: left;
    position: sticky;
    top: 0;
}

.detail-table td {
    padding: 10px 11px;
    border-bottom: 1px solid #e5e7eb;
}

.detail-table tr:hover td {
    background: #f8fafc;
}

.hu-badge {
    background: #e0f2fe;
    color: #075985;
    padding: 4px 8px;
    border-radius: 999px;
    font-weight: 800;
    font-size: 12px;
}

@media (max-width: 800px) {
    .detail-summary {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>

<div class="detail-summary">
    <div class="detail-box">
        <small>Spedition</small>
        <strong><?= e($spedition) ?></strong>
    </div>

    <div class="detail-box">
        <small>Relation</small>
        <strong><?= e($relation) ?></strong>
    </div>

    <div class="detail-box">
        <small>Liefertermin</small>
        <strong><?= e($lfdat) ?></strong>
    </div>

    <div class="detail-box">
        <small>+KW</small>
        <strong><?= e($plus_kw) ?></strong>
    </div>
</div>

<div class="detail-table-wrap">
    <table class="detail-table">
        <thead>
            <tr>
                <th>Platz</th>
                <th>Handling Unit</th>
                <th>Kunde</th>
                <th>Debitor</th>
                <th>Beleg</th>
                <th>Typ</th>
                <th>Ret.klasse</th>
                <th>KartonAnz</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($res && mysqli_num_rows($res) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><strong><?= e($row['platz']) ?></strong></td>
                        <td><span class="hu-badge"><?= e($row['handling_unit']) ?></span></td>
                        <td><?= e($row['kunde_name1']) ?></td>
                        <td><?= e($row['debitor']) ?></td>
                        <td><?= e($row['beleg']) ?></td>
                        <td><?= e($row['typ']) ?></td>
                        <td><?= e($row['ret_klasse']) ?></td>
                        <td><?= (int)$row['kartonanz'] ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align:center; color:#64748b; font-weight:700; padding:20px;">
                        Keine Details gefunden.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>