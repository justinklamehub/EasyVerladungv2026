<?php
require_once "../functions.php";

$id = (int)$_POST['id'];

mysqli_query($dbhandle,"
UPDATE einlagerung_zuordnung
SET aktiv=0
WHERE id=$id
");

echo json_encode(["ok"=>true]);