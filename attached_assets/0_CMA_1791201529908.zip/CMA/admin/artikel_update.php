<?php
require_once "../functions.php";

$id = (int)($_POST['artikel_id'] ?? 0);
$ean = trim($_POST['ean'] ?? '');
$name = trim($_POST['artikelname'] ?? '');
$q = trim($_POST['q'] ?? '');

if ($id > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE artikel
        SET ean = ?, artikelname = ?
        WHERE id = ?
    ");
    mysqli_stmt_bind_param($stmt, "ssi", $ean, $name, $id);
    mysqli_stmt_execute($stmt);
}

header("Location: zuordnungen.php?q=" . urlencode($q));
exit;