<?php require_once "../functions.php"; ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Einlagerungsstrategie Import</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>Einlagerungsstrategie Import</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2>CSV-Datei importieren</h2>

        <p>
            CSV-Aufbau:
            <strong>Artikelnummer;Regal;Kundengruppe;Prio;Hinweis</strong>
        </p>

        <div class="admin-form">
            <label>CSV-Datei auswählen</label>
            <input type="file" id="csvFile" accept=".csv">

            <label class="import-checkbox">
                <input type="checkbox" id="resetBeforeImport">
                Bestehende Einlagerungsstrategie vorher deaktivieren
            </label>

            <button type="button" class="admin-save" onclick="startZuordnungImport()">
                Import starten
            </button>
        </div>

        <div class="import-progress-wrap" style="display:none;" id="progressWrap">
            <div class="import-progress-info">
                <strong id="progressText">0%</strong>
                <span id="progressDetails">Warte...</span>
            </div>
            <div class="import-progress-bar">
                <div id="progressBar"></div>
            </div>
        </div>

        <div id="importResult"></div>
    </div>

    <div class="admin-card">
        <h2>Beispiel CSV Aufbau</h2>

        <div class="csv-preview">
            <table>
                <thead>
                    <tr>
                        <th>Artikelnummer</th>
                        <th>Regal</th>
                        <th>Kundengruppe</th>
                        <th>Prio</th>
                        <th>Hinweis</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>181500</td>
                        <td>01-15</td>
                        <td>EDEKA</td>
                        <td>1</td>
                        <td>Bevorzugter Platz</td>
                    </tr>
                    <tr>
                        <td>181501</td>
                        <td>02-08</td>
                        <td>NETTO</td>
                        <td>2</td>
                        <td>Ausweichplatz</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
const BATCH_SIZE = 300;

function parseCsvLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];

        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ';' && !inQuotes) {
            result.push(current.trim().replace(/^"|"$/g, ''));
            current = '';
        } else {
            current += char;
        }
    }

    result.push(current.trim().replace(/^"|"$/g, ''));
    return result;
}

async function startZuordnungImport() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];
    const resetBeforeImport = document.getElementById('resetBeforeImport').checked;

    if (!file) {
        alert('Bitte CSV-Datei auswählen.');
        return;
    }

    if (resetBeforeImport) {
        if (!confirm('Achtung: Alle bestehenden aktiven Einlagerungszuordnungen werden deaktiviert. Fortfahren?')) {
            return;
        }
    }

    document.getElementById('progressWrap').style.display = 'block';
    document.getElementById('importResult').innerHTML = '';
    setProgress(0, 'Datei wird gelesen...');

    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');

    if (lines.length <= 1) {
        setProgress(0, 'Keine Daten gefunden.');
        return;
    }

    const rows = [];

    for (let i = 1; i < lines.length; i++) {
        const cols = parseCsvLine(lines[i]);

        rows.push({
            artikelnummer: cols[0] || '',
            regal: cols[1] || '',
            kundengruppe: cols[2] || '',
            prio: cols[3] || '1',
            hinweis: cols[4] || ''
        });
    }

    if (resetBeforeImport) {
        setProgress(2, 'Bestehende Strategie wird deaktiviert...');

        const resetRes = await fetch('ajax_import_zuordnung_reset.php', {
            method: 'POST'
        });

        const resetJson = await resetRes.json();

        if (!resetJson.ok) {
            alert(resetJson.message || 'Bestehende Strategie konnte nicht deaktiviert werden.');
            return;
        }
    }

    let imported = 0;
    let skipped = 0;
    const total = rows.length;

    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const batch = rows.slice(i, i + BATCH_SIZE);

        const res = await fetch('ajax_import_zuordnung_batch.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ rows: batch })
        });

        const json = await res.json();

        if (!json.ok) {
            alert(json.message || 'Fehler beim Import.');
            return;
        }

        imported += json.inserted || 0;
        skipped += json.skipped || 0;

        const processed = Math.min(i + BATCH_SIZE, total);
        const percent = Math.round((processed / total) * 100);

        setProgress(percent, `${processed} von ${total} Zeilen verarbeitet...`);

        await new Promise(r => setTimeout(r, 50));
    }

    setProgress(100, `Import abgeschlossen. ${imported} importiert, ${skipped} übersprungen.`);

    document.getElementById('importResult').innerHTML = `
        <div class="admin-alert success" style="margin-top:16px;">
            Import erfolgreich.<br>
            Importiert: <strong>${imported}</strong><br>
            Übersprungen: <strong>${skipped}</strong>
        </div>
    `;
}

function setProgress(percent, text) {
    document.getElementById('progressText').innerText = percent + '%';
    document.getElementById('progressDetails').innerText = text;
    document.getElementById('progressBar').style.width = percent + '%';
}
</script>

</body>
</html>