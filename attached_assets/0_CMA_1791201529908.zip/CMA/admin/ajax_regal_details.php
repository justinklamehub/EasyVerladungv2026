<?php
require_once "../functions.php";

$regalId = (int)($_GET['id'] ?? 0);

if ($regalId <= 0) {
    echo "<div class='admin-alert error'>Ungültiges Regal.</div>";
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT 
        lr.id AS regal_id,
        lr.regal_nr,
        lr.voll_gemeldet,
        lr.voll_gemeldet_at,
        lr.voll_hinweis,
        lg.gang_nr
    FROM lager_regale lr
    JOIN lager_gaenge lg ON lg.id = lr.gang_id
    WHERE lr.id = ?
    LIMIT 1
");
mysqli_stmt_bind_param($stmt, "i", $regalId);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$regal = mysqli_fetch_assoc($res);

if (!$regal) {
    echo "<div class='admin-alert error'>Regal wurde nicht gefunden.</div>";
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT 
        parcours,
        COUNT(*) AS paletten
    FROM zlthu_retoure
    WHERE platz = ?
    GROUP BY parcours
    ORDER BY paletten DESC, parcours ASC
");
mysqli_stmt_bind_param($stmt, "s", $regal['regal_nr']);
mysqli_stmt_execute($stmt);
$retourenRes = mysqli_stmt_get_result($stmt);

$retourenTotal = 0;
$retourenRows = [];

while ($ret = mysqli_fetch_assoc($retourenRes)) {
    $paletten = (int)$ret['paletten'];
    $retourenTotal += $paletten;

    $retourenRows[] = [
        "parcours" => $ret['parcours'],
        "paletten" => $paletten
    ];
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT 
        ez.id AS zuordnung_id,
        ez.prioritaet,
        ez.hinweis,
        a.artikelnummer,
        a.artikelname,
        a.ean,
        kg.name AS kundengruppe,
        kg.farbe
    FROM einlagerung_zuordnung ez
    JOIN artikel a ON a.id = ez.artikel_id
    LEFT JOIN kundengruppen kg ON kg.id = ez.kundengruppe_id
    WHERE ez.regal_id = ?
      AND ez.aktiv = 1
    ORDER BY ez.prioritaet ASC, a.artikelnummer ASC
");
mysqli_stmt_bind_param($stmt, "i", $regalId);
mysqli_stmt_execute($stmt);
$items = mysqli_stmt_get_result($stmt);


$kgList = mysqli_query($dbhandle, "
    SELECT id, name, farbe
    FROM kundengruppen
    ORDER BY name ASC
");

$stmt = mysqli_prepare($dbhandle, "
    SELECT 
        material,
        COUNT(*) AS paletten
    FROM zlthu_istbestand
    WHERE lagerplatz = ?
    GROUP BY material
    ORDER BY paletten DESC, material ASC
");
mysqli_stmt_bind_param($stmt, "s", $regal['regal_nr']);
mysqli_stmt_execute($stmt);
$istRes = mysqli_stmt_get_result($stmt);

$istTotal = 0;
$istRows = [];

while ($ist = mysqli_fetch_assoc($istRes)) {
    $paletten = (int)$ist['paletten'];
    $istTotal += $paletten;

    $istRows[] = [
        "material" => $ist['material'],
        "paletten" => $paletten
    ];
}

$regaleRes = mysqli_query($dbhandle, "
    SELECT 
        lr.id,
        lr.regal_nr,
        lg.gang_nr,
        lr.voll_gemeldet
    FROM lager_regale lr
    JOIN lager_gaenge lg ON lg.id = lr.gang_id
    WHERE lr.aktiv = 1
    ORDER BY lg.gang_nr ASC, lr.sortierung ASC
");
?>

<input type="hidden" id="modalRegalId" value="<?= (int)$regal['regal_id'] ?>">

<div class="regal-detail-head">
    <h3>Gang <?= e($regal['gang_nr']) ?> / Regal <?= e($regal['regal_nr']) ?></h3>

    <div class="regal-status-row">

    <div class="regal-status-left">
        <?php if ((int)$regal['voll_gemeldet'] === 1): ?>
            <div class="full-warning">
                ⚠️ Regal ist voll
            </div>
        <?php else: ?>
            <div class="admin-alert success">
                Regal ist frei.
            </div>
        <?php endif; ?>
    </div>

    <div class="regal-status-right">
        <button 
        type="button" 
        onclick="toggleRegal()" 
        class="modal-btn full-width <?= ((int)$regal['voll_gemeldet'] === 1) ? 'full' : 'free' ?>">
        <?= ((int)$regal['voll_gemeldet'] === 1) 
            ? 'Regal freigeben' 
            : 'Als voll markieren' ?>
        </button>
    </div>

</div>
</div>

<hr>

<div class="retouren-detail-card">
    <div class="retouren-detail-head">
        <strong><?= (int)$retourenTotal ?></strong>
        <span>Retourenpaletten auf diesem Regalplatz</span>
    </div>

    <?php if ($retourenTotal > 0): ?>
        <div class="retouren-detail-list">
            <?php foreach ($retourenRows as $ret): ?>
                <div class="retouren-detail-row">
                    <span><?= e($ret['parcours'] ?: 'Ohne Parcours') ?></span>
                    <b><?= (int)$ret['paletten'] ?> Pal.</b>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="retouren-empty">
            Keine Retourenpaletten auf diesem Platz.
        </div>
    <?php endif; ?>
</div>

<hr>

<div class="retouren-detail-card">
    <div class="retouren-detail-head">
        <strong><?= (int)$istTotal ?></strong>
        <span>IST-Paletten aktuell auf diesem Regalplatz</span>
    </div>

    <?php if ($istTotal > 0): ?>
        <div class="retouren-detail-list">
            <?php foreach ($istRows as $ist): ?>
                <div class="retouren-detail-row">
                    <span><?= e($ist['material']) ?></span>
                    <b><?= (int)$ist['paletten'] ?> Pal.</b>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="retouren-empty">
            Kein IST-Bestand auf diesem Platz.
        </div>
    <?php endif; ?>
</div>

<hr>

<div class="modal-add-modern">
    <div class="modal-autocomplete-wrap">
        <label>Artikel hinzufügen</label>

        <div class="modal-search-row">
            <input 
                type="text" 
                id="newArtikel" 
                placeholder="Artikelnummer, EAN oder Artikelname suchen..."
                autocomplete="off"
            >

            <button type="button" onclick="addArtikel()">
                Hinzufügen
            </button>
        </div>

        <div id="modalArticleSuggestions" class="article-suggestions modal-suggestions"></div>
    </div>

    <div class="modal-add-row">

    <div class="field-prio">
        <label>Prio</label>
        <input type="number" id="newPrioritaet" value="1" min="1" max="99">
    </div>

    <div class="field-kg">
        <label>Kundengruppe</label>
        <select id="newKundengruppe">
            <option value="">Keine</option>
            <?php mysqli_data_seek($kgList, 0); ?>
            <?php while ($kg = mysqli_fetch_assoc($kgList)): ?>
                <option value="<?= (int)$kg['id'] ?>">
                    <?= e($kg['name']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="field-hinweis">
        <label>Hinweis</label>
        <input type="text" id="newHinweis" placeholder="Optional">
    </div>

</div>
</div>

<hr>

<h3>Artikel in diesem Regal</h3>

<?php if (mysqli_num_rows($items) === 0): ?>
    <p>In diesem Regal sind aktuell keine Artikel zugeordnet.</p>
<?php else: ?>
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Prio</th>
                    <th>Artikel</th>
                    <th>Name</th>
                    <th>Kundengruppe</th>
                    <th>Hinweis</th>
                    <th>Aktion</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($items)): ?>
                    <tr>
                        <td><?= (int)$row['prioritaet'] ?></td>
                        <td>
                            <strong><?= e($row['artikelnummer']) ?></strong><br>
                            <small><?= e($row['ean']) ?></small>
                        </td>
                        <td><?= e($row['artikelname']) ?></td>
                        <td>
                            <?php if ($row['kundengruppe']): ?>
                                <span class="kg-badge" style="background:<?= e($row['farbe'] ?: '#ddd') ?>">
                                    <?= e($row['kundengruppe']) ?>
                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?= e($row['hinweis']) ?></td>
                        
                        <td>
                            <div class="modal-action-row">
                                <a class="admin-small-btn" href="zuordnungen.php?q=<?= urlencode($row['artikelnummer']) ?>">
                                    Bearbeiten
                                </a>

                                <button 
                                    type="button" 
                                    class="admin-small-btn move-btn"
                                    onclick="toggleMoveBox(<?= (int)$row['zuordnung_id'] ?>)">
                                    Verschieben
                                </button>

                                <button 
                                    type="button" 
                                    class="admin-delete modal-delete-btn"
                                    onclick="deleteItem(<?= (int)$row['zuordnung_id'] ?>)">
                                    Entfernen
                                </button>
                            </div>

                            <div id="moveBox<?= (int)$row['zuordnung_id'] ?>" class="move-box" style="display:none;">
                                <select id="moveTarget<?= (int)$row['zuordnung_id'] ?>">
                                    <option value="">Ziel-Regal wählen</option>

                                    <?php
                                    mysqli_data_seek($regaleRes, 0);
                                    while ($regalOption = mysqli_fetch_assoc($regaleRes)):
                                    ?>
                                        <option value="<?= (int)$regalOption['id'] ?>">
                                            Gang <?= e($regalOption['gang_nr']) ?> / Regal <?= e($regalOption['regal_nr']) ?>
                                            <?= ((int)$regalOption['voll_gemeldet'] === 1) ? ' - VOLL' : '' ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>

                                <button 
                                    type="button" 
                                    class="admin-save move-confirm-btn"
                                    onclick="moveItem(<?= (int)$row['zuordnung_id'] ?>)">
                                    Speichern
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>