<?php
require_once "../functions.php";

/*
    Filter
*/
$filterGang = $_GET['gang'] ?? '';
$filterKg   = $_GET['kg'] ?? '';
$filterFull = $_GET['full'] ?? '';
$filterArtikel = trim($_GET['artikel'] ?? '');

/*
    Alle Kundengruppen laden (für Filter)
*/
$kgRes = mysqli_query($dbhandle, "SELECT id, name FROM kundengruppen ORDER BY name");
$legendRes = mysqli_query($dbhandle, "
    SELECT name, farbe
    FROM kundengruppen
    ORDER BY name ASC
");
/*
    Daten laden
*/
$sql = "
    SELECT 
        lr.id AS regal_id,
        lr.regal_nr,
        lr.sortierung,
        lr.voll_gemeldet,

        lg.gang_nr,

        a.artikelnummer,
        a.artikelname,

        kg.name AS kundengruppe,
        kg.farbe,

        ret.parcours,
        COALESCE(ret.paletten, 0) AS retouren_paletten

    FROM lager_regale lr

    JOIN lager_gaenge lg 
        ON lg.id = lr.gang_id

    LEFT JOIN einlagerung_zuordnung ez 
        ON ez.regal_id = lr.id 
        AND ez.aktiv = 1

    LEFT JOIN artikel a 
        ON a.id = ez.artikel_id

    LEFT JOIN kundengruppen kg 
        ON kg.id = ez.kundengruppe_id

    LEFT JOIN (
        SELECT 
            platz,
            parcours,
            COUNT(*) AS paletten
        FROM zlthu_retoure
        GROUP BY platz, parcours
    ) ret 
        ON ret.platz = lr.regal_nr
";

$res = mysqli_query($dbhandle, $sql);

/*
    Grid vorbereiten (MEHRERE ARTIKEL PRO REGAL)
*/
$grid = [];

while ($row = mysqli_fetch_assoc($res)) {

    // 🔎 FILTER LOGIK

    if ($filterGang && $row['gang_nr'] !== $filterGang) {
        continue;
    }

    if ($filterFull !== '') {
        if ((int)$row['voll_gemeldet'] !== (int)$filterFull) {
            continue;
        }
    }

    if ($filterKg && $row['kundengruppe'] !== $filterKg) {
        continue;
    }

    // 👉 Grid aufbauen
    $rowNr = substr($row['regal_nr'], 3);
    $gang  = $row['gang_nr'];

    if (!isset($grid[$rowNr][$gang])) {
        $grid[$rowNr][$gang] = [
            "regal_id" => $row['regal_id'],
            "voll" => (int)$row['voll_gemeldet'],
            "retouren_paletten" => 0,
            "retouren_details" => [],
            "items" => [],
            "item_keys" => []
        ];
    }

    // 👉 Artikel deduplizieren
    if (!empty($row['artikelnummer'])) {

        $artikelKey = $row['artikelnummer'];

        if (!isset($grid[$rowNr][$gang]["item_keys"][$artikelKey])) {

            $grid[$rowNr][$gang]["items"][] = [
                "artikelnummer" => $row['artikelnummer'],
                "artikelname" => $row['artikelname'],
                "kundengruppe" => $row['kundengruppe'],
                "farbe" => $row['farbe']
            ];

            $grid[$rowNr][$gang]["item_keys"][$artikelKey] = true;
        }
    }
}

$retRes = mysqli_query($dbhandle, "
    SELECT 
        platz,
        parcours,
        COUNT(*) AS paletten
    FROM zlthu_retoure
    GROUP BY platz, parcours
");

while ($ret = mysqli_fetch_assoc($retRes)) {

    $platz = $ret['platz'];
    $parcours = $ret['parcours'];
    $paletten = (int)$ret['paletten'];

    $parts = explode('-', $platz);

    if (count($parts) !== 2) continue;

    $gang = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if (!isset($grid[$rowNr][$gang])) continue;

    $grid[$rowNr][$gang]['retouren_paletten'] += $paletten;

    $grid[$rowNr][$gang]['retouren_details'][] = [
        'parcours' => $parcours,
        'paletten' => $paletten
    ];
}

$istRes = mysqli_query($dbhandle, "
    SELECT 
        lagerplatz,
        material,
        COUNT(*) AS paletten
    FROM zlthu_istbestand
    GROUP BY lagerplatz, material
");

while ($ist = mysqli_fetch_assoc($istRes)) {

    $platz = $ist['lagerplatz'];
    $material = $ist['material'];
    $paletten = (int)$ist['paletten'];

    $parts = explode('-', $platz);

    if (count($parts) !== 2) continue;

    $gang = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if (!isset($grid[$rowNr][$gang])) continue;

    if (!isset($grid[$rowNr][$gang]['ist_total'])) {
        $grid[$rowNr][$gang]['ist_total'] = 0;
        $grid[$rowNr][$gang]['ist_details'] = [];
    }

    $grid[$rowNr][$gang]['ist_total'] += $paletten;

    $grid[$rowNr][$gang]['ist_details'][] = [
        'material' => $material,
        'paletten' => $paletten
    ];
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Lagerübersicht</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../assets/app.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
body {
    background: #f3f5f8;
}

.lager-page {
    max-width: none;
    padding: 22px;
}

.lager-toolbar {
    background: #ffffff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
    margin-bottom: 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.filter-group select,
.filter-group input {
    min-width: 170px;
    padding: 11px 13px;
    border: 1px solid #d8dee8;
    border-radius: 12px;
    background: #f8fafc;
    font-size: 14px;
    outline: none;
}

.filter-group select:focus,
.filter-group input:focus {
    border-color: #64748b;
    background: #fff;
}

.filter-reset {
    border: 0;
    background: #111827;
    color: #fff;
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 700;
    cursor: pointer;
}

.grid-shell {
    background: #fff;
    border-radius: 20px;
    padding: 14px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.grid-wrap {
    max-height: calc(100vh - 230px);
    overflow: auto;
    border-radius: 14px;
    border: 1px solid #e5e7eb;
}

.grid-table {
    border-collapse: separate;
    border-spacing: 0;
    font-size: 12px;
    min-width: 2450px;
    width: max-content;
}

.grid-table thead th {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #111827;
    color: #fff;
    padding: 12px 10px;
    text-align: center;
    font-size: 13px;
    letter-spacing: .04em;
}

.grid-table thead th:first-child {
    left: 0;
    z-index: 30;
}

.row-label {
    position: sticky;
    left: 0;
    z-index: 10;
    background: #f1f5f9;
    color: #334155;
    font-weight: 800;
    text-align: center;
    min-width: 10px;
    max-width: 30px;
    border-right: 1px solid #dbe3ee;
}

.grid-table td {
    border-right: 1px solid #e5e7eb;
    border-bottom: 1px solid #e5e7eb;
    width: 132px;
    height: 78px;
    padding: 6px;
    vertical-align: top;
    background: #f8fafc;
}

.regal-cell {
    width: 100%;
    height: 100%;
    border-radius: 12px;
    padding: 7px;
    background: #ffffff;
    box-shadow: inset 0 0 0 1px rgba(15, 23, 42, .06);
    cursor: pointer;
    transition: .15s ease;
    overflow: hidden;
}

.regal-cell:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 18px rgba(15, 23, 42, .16);
}

.regal-cell.empty {
    color: #94a3b8;
    background: repeating-linear-gradient(
        -45deg,
        #f8fafc,
        #f8fafc 8px,
        #eef2f7 8px,
        #eef2f7 16px
    );
}

.regal-cell.full {
    background: #fff1f2 !important;
    box-shadow: inset 0 0 0 2px #ef4444;
}

.regal-full-badge {
    display: inline-block;
    background: #dc2626;
    color: #fff;
    padding: 3px 7px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 800;
    margin-bottom: 4px;
}

.item {
    padding: 4px 6px;
    margin-bottom: 4px;
    border-radius: 9px;
    font-size: 11px;
    font-weight: 800;
    color: #111827;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.item small {
    display: block;
    font-weight: 600;
    opacity: .75;
    margin-top: 1px;
}

.more-items {
    font-size: 11px;
    color: #475569;
    font-weight: 700;
    margin-top: 3px;
}
/* ===== MODAL BACKDROP ===== */
.modal-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.65);
    backdrop-filter: blur(4px);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
}

/* ===== MODAL BOX ===== */
.modal {
    width: 100%;
    max-width: 700px;
    max-height: 90vh;
    background: #ffffff;
    border-radius: 18px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.25);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

/* ===== HEADER ===== */
.modal-header {
    padding: 18px 20px;
    background: #111827;
    color: #fff;
    font-size: 18px;
    font-weight: 700;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* ===== CLOSE BUTTON ===== */
.modal-close {
    background: rgba(255,255,255,0.15);
    border: 0;
    color: #fff;
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
}

.modal-close:hover {
    background: rgba(255,255,255,0.25);
}

/* ===== CONTENT ===== */
.modal-body {
    padding: 20px;
    overflow-y: auto;
}

/* ===== FOOTER ===== */
.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
}

/* ===== BUTTON ===== */
.modal-btn {
    background: #111827;
    color: #fff;
    border: 0;
    padding: 10px 14px;
    border-radius: 10px;
    font-weight: bold;
    cursor: pointer;
}

/* ===== FULL WARNING ===== */
.full-warning {
    margin: 10px 0;
    padding: 12px;
    background: #fff1f2;
    color: #b91c1c;
    border-radius: 10px;
    font-weight: 600;
}

/* ===== TABLE INSIDE MODAL ===== */
.modal .admin-table {
    font-size: 13px;
}

.lager-legend {
    background: #ffffff;
    border-radius: 18px;
    padding: 16px 18px;
    margin-bottom: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.legend-title {
    font-weight: 800;
    font-size: 14px;
    margin-bottom: 10px;
    color: #334155;
}

.legend-items {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    background: #f8fafc;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
    color: #1e293b;
}

.legend-color {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    display: inline-block;
}

.legend-item.clickable {
    cursor: pointer;
    transition: all 0.15s ease;
}

.legend-item.clickable:hover {
    transform: translateY(-1px);
    background: #eef2f7;
}

.legend-item.active {
    background: #111827;
    color: #fff;
}

.legend-item.active .legend-color {
    border: 2px solid #fff;
}

.ist-badge {
    position: absolute;
    top: 34px;      /* unter Retouren-Badge */
    right: 6px;
    background: #2563eb;
    color: #fff;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    box-shadow: 0 4px 10px rgba(0,0,0,.25);
    z-index: 20;
}
</style>
</head>
<body>

<div id="overlayLoader" class="overlay-loader" style="display:none;">
    <div class="loader-box">
        <div class="loader-spinner"></div>
        <div class="loader-text">Lade Lagerdaten...</div>
    </div>
</div>

<div class="admin-wrapper lager-page">

<div class="admin-header">
    <h1>Lagerübersicht</h1>
    <a href="index.php" class="admin-back">Zurück</a>
</div>

<div class="lager-toolbar">

    <div class="filter-group">
        <label>Gang</label>
        <select id="filterGang" onchange="applyFilter()">
            <option value="">Alle</option>
            <?php for ($i=1;$i<=18;$i++): ?>
                <?php $g = str_pad($i,2,'0',STR_PAD_LEFT); ?>
                <option value="<?= $g ?>" <?= $filterGang==$g?'selected':'' ?>>
                    <?= $g ?>
                </option>
            <?php endfor; ?>
        </select>
    </div>

    <div class="filter-group">
        <label>Kundengruppe</label>
        <select id="filterKg" onchange="applyFilter()">
            <option value="">Alle</option>
            <?php mysqli_data_seek($kgRes, 0); ?>
            <?php while($kg = mysqli_fetch_assoc($kgRes)): ?>
                <option value="<?= $kg['name'] ?>" <?= $filterKg==$kg['name']?'selected':'' ?>>
                    <?= e($kg['name']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="filter-group">
        <label>Status</label>
        <select id="filterFull" onchange="applyFilter()">
            <option value="">Alle</option>
            <option value="0" <?= $filterFull==='0'?'selected':'' ?>>Nur freie</option>
            <option value="1" <?= $filterFull==='1'?'selected':'' ?>>Nur volle</option>
        </select>
    </div>

    <div class="filter-group">
        <label>Artikelnummer</label>
        <input 
            type="text" 
            id="filterArtikel" 
            value="<?= e($filterArtikel) ?>" 
            placeholder="z. B. 181500"
            oninput="applyFilterDelayed()"
        >
    </div>

    <div class="filter-actions">
        <button onclick="resetFilter()">Reset</button>
    </div>

</div>

<div class="lager-legend">
    <div class="legend-title">Legende</div>

    <div class="legend-items">
        <?php while ($lg = mysqli_fetch_assoc($legendRes)): ?>
            <div 
    class="legend-item clickable <?= ($filterKg === $lg['name']) ? 'active' : '' ?>"
    onclick="filterByKg('<?= e($lg['name']) ?>')"
>
                <span 
                    class="legend-color" 
                    style="background:<?= e($lg['farbe'] ?: '#ddd') ?>">
                </span>
                <span class="legend-text"><?= e($lg['name']) ?></span>
            </div>
        <?php endwhile; ?>

        <div 
    class="legend-item clickable <?= ($filterFull === '1') ? 'active' : '' ?>"
    onclick="filterFullOnly()"
>
            <span class="legend-color" style="background:#fff1f2; border:2px solid #ef4444;"></span>
            <span class="legend-text">Regal voll</span>
        </div>
    </div>
</div>

<div id="gridContainer">
<div class="grid-shell">
<div class="grid-wrap">
<table class="grid-table">
<thead>

<!-- Halle Header -->
<tr class="hall-row">
    <th></th>
    <th colspan="6">Halle 1</th>
    <th colspan="6">Halle 2</th>
    <th colspan="6">Halle 3</th>
</tr>

<!-- Gang Header -->
<tr>
    <th></th>
    <?php for ($g=1;$g<=18;$g++): ?>
        <th><?= str_pad($g,2,'0',STR_PAD_LEFT) ?></th>
    <?php endfor; ?>
</tr>

</thead>

<tbody>
<?php for ($r=45;$r>=1;$r--):
    $rowKey = str_pad($r,2,'0',STR_PAD_LEFT);
?>
<tr>
<td class="row-label"><?= $rowKey ?></td>

<?php for ($g=1;$g<=18;$g++):
    $gangKey = str_pad($g,2,'0',STR_PAD_LEFT);
    $cell = $grid[$rowKey][$gangKey] ?? null;

    $style = "#f8f8f8";
    $class = "";
?>

<td onclick="openModal(<?= $cell['regal_id'] ?? 0 ?>)">
<div class="regal-cell <?= !$cell || !count($cell['items']) ? 'empty' : '' ?> <?= $cell && $cell['voll'] ? 'full' : '' ?>">

    <?php if ($cell && count($cell['items'])): ?>
        <?php foreach ($cell['items'] as $it): ?>
            <div class="item" style="background:<?= $it['farbe'] ?: '#ddd' ?>">
                <strong><?= e($it['artikelnummer']) ?></strong>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <span style="color:#999;">nicht verplant</span>
    <?php endif; ?>

    <!-- 👇 HIER rein -->
    <?php if ($cell && (int)$cell['retouren_paletten'] > 0): ?>
    <div class="retouren-badge tooltip-wrap">
        <?= (int)$cell['retouren_paletten'] ?>

        <div class="retouren-tooltip">
            <strong><?= (int)$cell['retouren_paletten'] ?> Retouren Paletten gesamt</strong>

            <?php if ($cell && !empty($cell['retouren_details'])): ?>
    <?php foreach ($cell['retouren_details'] as $ret): ?>
        <div class="tooltip-row">
            <span><?= e($ret['parcours']) ?></span>
            <b><?= (int)$ret['paletten'] ?> Pal.</b>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="tooltip-row">
        <span>Keine Retouren vorhanden</span>
    </div>
<?php endif; ?>
        </div>
    </div>
    <?php endif; ?>


    <?php if (!empty($cell['ist_total']) && $cell['ist_total'] > 0): ?>
    <div class="ist-badge tooltip-wrap">
        <?= (int)$cell['ist_total'] ?>

        <div class="retouren-tooltip">
            <strong><?= (int)$cell['ist_total'] ?> Bestandspaletten gesamt</strong>

            <?php foreach ($cell['ist_details'] as $ist): ?>
                <div class="tooltip-row">
                    <span><?= e($ist['material']) ?></span>
                    <b><?= (int)$ist['paletten'] ?> Pal.</b>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
</div>
</td>

<?php endfor; ?>
</tr>
<?php endfor; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>

<!-- Modal -->
<div class="modal-backdrop" id="modal">
    <div class="modal">

        <div class="modal-header">
            <span>Regal Details</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>

        <div class="modal-body" id="modalContent">
            Lade...
        </div>

        <div class="modal-footer">
            <button class="modal-btn" onclick="closeModal()">Schließen</button>
        </div>

    </div>
</div>

<script>
toastr.options = {
    closeButton: true,
    progressBar: true,
    positionClass: "toast-top-right",
    timeOut: "3000",
    extendedTimeOut: "1000",
    preventDuplicates: true
};
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
document.getElementById('modal').addEventListener('click', function(e){
    if (e.target === this) {
        closeModal();
    }
});

let filterTimer = null;

function applyFilterDelayed() {
    clearTimeout(filterTimer);
    filterTimer = setTimeout(applyFilter, 500);
}

function applyFilter(){

    const g  = document.getElementById('filterGang').value;
    const kg = document.getElementById('filterKg').value;
    const f  = document.getElementById('filterFull').value;
    const artikel = document.getElementById('filterArtikel').value.trim();

    const loader = document.getElementById('overlayLoader');
    if (loader) loader.style.display = 'flex';

    fetch(`ajax_lager_grid.php?gang=${encodeURIComponent(g)}&kg=${encodeURIComponent(kg)}&full=${encodeURIComponent(f)}&artikel=${encodeURIComponent(artikel)}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById('gridContainer').innerHTML = `
                <div class="grid-shell">
                    <div class="grid-wrap">
                        ${html}
                    </div>
                </div>
            `;
        })
        .catch(() => {
            toastr.error('Fehler beim Laden der Lagerübersicht.');
        })
        .finally(() => {
            if (loader) loader.style.display = 'none';
        });
}

function openModal(id){
    if(!id) return;

    document.getElementById('modal').style.display='flex';
    document.getElementById('modalContent').innerHTML='Lade...';

    fetch('ajax_regal_details.php?id='+id)
        .then(r=>r.text())
        .then(html=>{
            document.getElementById('modalContent').innerHTML=html;
        });
}

function closeModal(){
    document.getElementById('modal').style.display='none';
}

function resetFilter(){
    window.location.href = "lager_uebersicht.php";
}

function filterByKg(kg){
    const g = document.getElementById('filterGang').value;
    const f = document.getElementById('filterFull').value;

    window.location.href = `?gang=${g}&kg=${encodeURIComponent(kg)}&full=${f}`;
}

function filterFullOnly(){
    const g = document.getElementById('filterGang').value;
    const kg = document.getElementById('filterKg').value;

    window.location.href = `?gang=${g}&kg=${encodeURIComponent(kg)}&full=1`;
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function escapeJs(value) {
    return String(value ?? '')
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('"', '\\"');
}



let modalArticleTimer = null;

document.addEventListener('input', function(e) {
    if (e.target.id !== 'newArtikel') return;

    const input = e.target;
    const box = document.getElementById('modalArticleSuggestions');
    const value = input.value.trim();

    clearTimeout(modalArticleTimer);

    if (value.length < 2) {
        box.innerHTML = '';
        box.style.display = 'none';
        return;
    }

    modalArticleTimer = setTimeout(() => {
        fetch('ajax_article_search.php?q=' + encodeURIComponent(value))
            .then(r => r.json())
            .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    box.innerHTML = `
                        <div class="article-suggestion-empty">
                            Keine Treffer gefunden
                        </div>
                    `;
                    box.style.display = 'block';
                    return;
                }

                let html = '';

                data.forEach(item => {
                    html += `
                        <div class="article-suggestion-item" onclick="selectModalArticle('${escapeJs(item.artikelnummer)}')">
                            <strong>${escapeHtml(item.artikelnummer)}</strong>
                            <span>${escapeHtml(item.artikelname || '')}</span>
                            ${item.ean ? `<small>EAN: ${escapeHtml(item.ean)}</small>` : ''}
                        </div>
                    `;
                });

                box.innerHTML = html;
                box.style.display = 'block';
            });
    }, 250);
});

function selectModalArticle(artikelnummer) {
    document.getElementById('newArtikel').value = artikelnummer;
    document.getElementById('modalArticleSuggestions').style.display = 'none';
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.modal-autocomplete-wrap')) {
        const box = document.getElementById('modalArticleSuggestions');
        if (box) box.style.display = 'none';
    }
});
</script>

<script>

function reloadModal(){
    const id = document.getElementById('modalRegalId').value;

    fetch('ajax_regal_details.php?id=' + id)
        .then(r => r.text())
        .then(html => {
            document.getElementById('modalContent').innerHTML = html;
        });
}

function addArtikel(){
    const artikel = document.getElementById('newArtikel').value.trim();
    const regalId = document.getElementById('modalRegalId').value;
    const prioritaet = document.getElementById('newPrioritaet').value || 1;
    const kundengruppeId = document.getElementById('newKundengruppe').value;
    const hinweis = document.getElementById('newHinweis').value.trim();

    if (!artikel) {
        toastr.warning('Bitte Artikel auswählen oder eingeben.');
        return;
    }

    fetch('ajax_add_item.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body:
            'artikelnummer=' + encodeURIComponent(artikel) +
            '&regal_id=' + encodeURIComponent(regalId) +
            '&prioritaet=' + encodeURIComponent(prioritaet) +
            '&kundengruppe_id=' + encodeURIComponent(kundengruppeId) +
            '&hinweis=' + encodeURIComponent(hinweis)
    })
    .then(r => r.json())
    .then(res => {
        if (res.ok) {
            toastr.success('Artikel wurde hinzugefügt.');
            reloadModal();
            applyFilter();
        } else {
            toastr.error(res.message || 'Artikel konnte nicht hinzugefügt werden.');
        }
    })
    .catch(() => {
        toastr.error('Fehler beim Hinzufügen.');
    });
}

function toggleRegal(){
    const modalRegalInput = document.getElementById('modalRegalId');

    if (!modalRegalInput) {
        toastr.error('Regal-ID nicht gefunden.');
        return;
    }

    const id = modalRegalInput.value;

    toastr.info('Regalstatus wird geändert...');

    fetch('ajax_toggle_regal.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'regal_id=' + encodeURIComponent(id)
    })
    .then(r => r.json())
    .then(res => {
        if (!res.ok) {
            toastr.error(res.message || 'Regalstatus konnte nicht geändert werden.');
            return;
        }

        if (parseInt(res.new) === 1) {
            toastr.warning('Regal wurde als voll markiert.');
        } else {
            toastr.success('Regal wurde wieder freigegeben.');
        }

        reloadModal();
        applyFilter();
    })
    .catch(() => {
        toastr.error('Fehler beim Ändern des Regalstatus.');
    });
}

function deleteItem(id){
    fetch('ajax_delete_item.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `id=${id}`
    })
    .then(() => {
        toastr.warning('Artikel entfernt');
        reloadModal();
        applyFilter();
    });
}

</script>

<script>
document.addEventListener('mouseover', function(e) {
    const badge = e.target.closest('.tooltip-wrap');
    if (!badge) return;

    const sourceTooltip = badge.querySelector('.retouren-tooltip');
    const floatingTooltip = document.getElementById('floatingRetourenTooltip');

    if (!sourceTooltip || !floatingTooltip) return;

    floatingTooltip.innerHTML = sourceTooltip.innerHTML;
    floatingTooltip.style.display = 'block';

    const badgeRect = badge.getBoundingClientRect();
    const tooltipRect = floatingTooltip.getBoundingClientRect();

    const spaceBelow = window.innerHeight - badgeRect.bottom;
    const spaceAbove = badgeRect.top;

    let top;

    if (spaceBelow < tooltipRect.height + 12 && spaceAbove > tooltipRect.height + 12) {
        top = badgeRect.top - tooltipRect.height - 8;
    } else {
        top = badgeRect.bottom + 8;
    }

    let left = badgeRect.right - tooltipRect.width;

    if (left < 8) {
        left = 8;
    }

    if (left + tooltipRect.width > window.innerWidth - 8) {
        left = window.innerWidth - tooltipRect.width - 8;
    }

    floatingTooltip.style.top = top + 'px';
    floatingTooltip.style.left = left + 'px';
});

document.addEventListener('mouseout', function(e) {
    const badge = e.target.closest('.tooltip-wrap');
    if (!badge) return;

    const floatingTooltip = document.getElementById('floatingRetourenTooltip');
    if (floatingTooltip) {
        floatingTooltip.style.display = 'none';
        floatingTooltip.innerHTML = '';
    }
});

function toggleMoveBox(id) {
    const box = document.getElementById('moveBox' + id);
    if (!box) return;

    box.style.display = box.style.display === 'none' || box.style.display === '' 
        ? 'flex' 
        : 'none';
}

function moveItem(id) {
    const select = document.getElementById('moveTarget' + id);

    if (!select || !select.value) {
        toastr.warning('Bitte Ziel-Regal auswählen.');
        return;
    }

    fetch('ajax_move_item.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body:
            'zuordnung_id=' + encodeURIComponent(id) +
            '&new_regal_id=' + encodeURIComponent(select.value)
    })
    .then(r => r.json())
    .then(res => {
        if (res.ok) {
            toastr.success(res.message || 'Zuordnung wurde verschoben.');
            reloadModal();
            applyFilter();
        } else {
            toastr.error(res.message || 'Verschieben fehlgeschlagen.');
        }
    })
    .catch(() => {
        toastr.error('Fehler beim Verschieben.');
    });
}
</script>



<div id="floatingRetourenTooltip" class="floating-retouren-tooltip"></div>
</body>
</html>