<?php
require_once "../functions.php";
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents("php://input"), true);
$rows = $data['rows'] ?? [];

if (!is_array($rows) || count($rows) === 0) {
    echo json_encode([
        "ok" => false,
        "message" => "Keine Daten empfangen."
    ]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    INSERT INTO eingelagerte_auftraege (
        verkaufsbeleg,
        lfdat,
        plus_kw,
        debitor,
        kunde_name1,
        plz,
        beleg,
        ern_ausl,
        ret_klasse,
        parkkennz,
        handling_unit,
        typ,
        platz,
        spediteur,
        spediteur_name1,
        relation,
        q,
        kartonanz,
        created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        "ok" => false,
        "message" => "Prepare fehlgeschlagen: " . mysqli_error($dbhandle)
    ]);
    exit;
}

$inserted = 0;
$created_at = time();

mysqli_begin_transaction($dbhandle);

foreach ($rows as $row) {

    $verkaufsbeleg    = trim($row['verkaufsbeleg'] ?? '');
    $lfdat            = trim($row['lfdat'] ?? '');
    $plus_kw          = trim($row['plus_kw'] ?? '');
    $debitor          = trim($row['debitor'] ?? '');
    $kunde_name1      = trim($row['kunde_name1'] ?? '');
    $plz     = trim($row['plz'] ?? '');
    $beleg            = trim($row['beleg'] ?? '');
    $ern_ausl         = trim($row['ern_ausl'] ?? '');
    $ret_klasse       = trim($row['ret_klasse'] ?? '');
    $parkkennz        = trim($row['parkkennz'] ?? '');
    $handling_unit    = trim($row['handling_unit'] ?? '');
    $typ              = trim($row['typ'] ?? '');
    $platz            = trim($row['platz'] ?? '');
    $spediteur        = trim($row['spediteur'] ?? '');
    $spediteur_name1  = trim($row['spediteur_name1'] ?? '');
    $relation         = trim($row['relation'] ?? '');
    $q                = trim($row['q'] ?? '');
    $kartonanz        = (int)str_replace(',', '.', ($row['kartonanz'] ?? 0));

    if ($handling_unit === '' && $beleg === '') {
        continue;
    }

    mysqli_stmt_bind_param(
        $stmt,
        "sssssssssssssssssii",
        $verkaufsbeleg,
        $lfdat,
        $plus_kw,
        $debitor,
        $kunde_name1,
        $plz,
        $beleg,
        $ern_ausl,
        $ret_klasse,
        $parkkennz,
        $handling_unit,
        $typ,
        $platz,
        $spediteur,
        $spediteur_name1,
        $relation,
        $q,
        $kartonanz,
        $created_at
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_rollback($dbhandle);

        echo json_encode([
            "ok" => false,
            "message" => "Insert fehlgeschlagen: " . mysqli_stmt_error($stmt)
        ]);
        exit;
    }

    $inserted++;
}

mysqli_commit($dbhandle);

echo json_encode([
    "ok" => true,
    "inserted" => $inserted
]);