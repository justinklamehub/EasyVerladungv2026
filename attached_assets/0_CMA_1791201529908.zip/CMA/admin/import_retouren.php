<?php require_once "../functions.php"; ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Retouren Import</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>Retouren Import</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2>CSV-Datei importieren</h2>

        <p>
            Die Tabelle <strong>zlthu_retoure</strong> wird vor dem Import geleert und anschließend neu befüllt.
        </p>

        <div class="admin-form">
            <label>CSV-Datei auswählen</label>
            <input type="file" id="csvFile" accept=".csv">

            <button type="button" class="admin-save" onclick="startRetourenImport()">
                Import starten
            </button>
        </div>

        <div class="import-progress-wrap" style="display:none;" id="progressWrap">
            <div class="import-progress-info">
                <strong id="progressText">0%</strong>
                <span id="progressDetails">Warte...</span>
            </div>
            <div class="import-progress-bar">
                <div id="progressBar"></div>
            </div>
        </div>

        <div id="importResult"></div>
    </div>

    <div class="admin-card" style="margin-top:20px;">
    <h2>Beispiel CSV Aufbau</h2>

    <p>Die CSV-Datei muss genau so aufgebaut sein:</p>

    <div class="csv-preview">
        <table>
            <thead>
                <tr>
                    <th>Debitor</th>
                    <th>Name 1</th>
                    <th>Parcoursname</th>
                    <th>Handling Unit</th>
                    <th>Platz</th>
                    <th>KartonAnz</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>5020001026</td>
                    <td>Kaufland Kassel</td>
                    <td>KAUFLAND</td>
                    <td>140046200041892700</td>
                    <td>04-05</td>
                    <td>22</td>
                </tr>
            </tbody>
        </table>
    </div>

    <a href="example_retouren.csv" class="admin-save" style="margin-top:12px; display:inline-block;">
        Beispiel CSV herunterladen
    </a>
</div>

</div>

<script>
const BATCH_SIZE = 500;

function parseCsvLine(line) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];

        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ';' && !inQuotes) {
            result.push(current.trim().replace(/^"|"$/g, ''));
            current = '';
        } else {
            current += char;
        }
    }

    result.push(current.trim().replace(/^"|"$/g, ''));
    return result;
}

async function startRetourenImport() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (!file) {
        alert('Bitte CSV-Datei auswählen.');
        return;
    }

    if (!confirm('Achtung: Die alte Retouren-Tabelle wird geleert. Fortfahren?')) {
        return;
    }

    document.getElementById('progressWrap').style.display = 'block';
    document.getElementById('importResult').innerHTML = '';
    setProgress(0, 'Datei wird gelesen...');

    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');

    if (lines.length <= 1) {
        setProgress(0, 'Keine Daten gefunden.');
        return;
    }

    const rows = [];

    // Header überspringen
    for (let i = 1; i < lines.length; i++) {
        const cols = parseCsvLine(lines[i]);

        rows.push({
            debitor: cols[0] || '',
            name: cols[1] || '',
            parcours: cols[2] || '',
            hu: cols[3] || '',
            platz: cols[4] || '',
            kartons: cols[5] || ''
        });
    }

    setProgress(2, 'Tabelle wird geleert...');

    const resetRes = await fetch('ajax_retouren_reset.php', {
        method: 'POST'
    });

    const resetJson = await resetRes.json();

    if (!resetJson.ok) {
        alert(resetJson.message || 'Tabelle konnte nicht geleert werden.');
        return;
    }

    let imported = 0;
    const total = rows.length;

    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const batch = rows.slice(i, i + BATCH_SIZE);

        const res = await fetch('ajax_retouren_batch.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ rows: batch })
        });

        const json = await res.json();

        if (!json.ok) {
            alert(json.message || 'Fehler beim Import.');
            return;
        }

        imported += json.inserted;

        const percent = Math.round((imported / total) * 100);
        setProgress(percent, `${imported} von ${total} Zeilen importiert...`);
    }

    setProgress(100, `Import abgeschlossen. ${imported} Retourenpaletten importiert.`);

    document.getElementById('importResult').innerHTML = `
        <div class="admin-alert success" style="margin-top:16px;">
            Import erfolgreich. ${imported} Datensätze wurden importiert.
        </div>
    `;
}

function setProgress(percent, text) {
    document.getElementById('progressText').innerText = percent + '%';
    document.getElementById('progressDetails').innerText = text;
    document.getElementById('progressBar').style.width = percent + '%';
}
</script>

</body>
</html>