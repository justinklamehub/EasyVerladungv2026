<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$rows = $input['rows'] ?? [];

if (!is_array($rows) || count($rows) === 0) {
    echo json_encode(["ok" => true, "inserted" => 0]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    INSERT INTO zlthu_istbestand
        (typ, lagerplatz, material, b, dauer, charge, lagereinh, bme, verfueg_bestand)
    VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        "ok" => false,
        "message" => "Prepare Fehler: " . mysqli_error($dbhandle)
    ]);
    exit;
}

$inserted = 0;

mysqli_begin_transaction($dbhandle);

try {
    foreach ($rows as $row) {
        $typ        = trim($row['typ'] ?? '');
        $lagerplatz = trim($row['lagerplatz'] ?? '');
        $material   = trim($row['material'] ?? '');
        $b          = trim($row['b'] ?? '');
        $dauer      = trim($row['dauer'] ?? '');
        $charge     = trim($row['charge'] ?? '');
        $lagereinh  = trim($row['lagereinh'] ?? '');
        $bme        = trim($row['bme'] ?? '');

        $bestandRaw = trim($row['verfueg_bestand'] ?? '0');
        $bestandRaw = str_replace('.', '', $bestandRaw);
        $bestandRaw = str_replace(',', '.', $bestandRaw);
        $bestand = (float)$bestandRaw;

        if ($lagerplatz === '' || $material === '') {
            continue;
        }

        mysqli_stmt_bind_param(
            $stmt,
            "ssssssssd",
            $typ,
            $lagerplatz,
            $material,
            $b,
            $dauer,
            $charge,
            $lagereinh,
            $bme,
            $bestand
        );

        mysqli_stmt_execute($stmt);
        $inserted++;
    }

    mysqli_commit($dbhandle);

    echo json_encode([
        "ok" => true,
        "inserted" => $inserted
    ]);

} catch (Throwable $e) {
    mysqli_rollback($dbhandle);

    echo json_encode([
        "ok" => false,
        "message" => "Import Fehler: " . $e->getMessage()
    ]);
}