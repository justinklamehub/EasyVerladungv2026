<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$rows = $input['rows'] ?? [];

if (!is_array($rows) || count($rows) === 0) {
    echo json_encode([
        "ok" => true,
        "inserted" => 0
    ]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    INSERT INTO zlthu_retoure
        (debitor, name, parcours, hu, platz, kartons)
    VALUES
        (?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        "ok" => false,
        "message" => "Prepare Fehler: " . mysqli_error($dbhandle)
    ]);
    exit;
}

$inserted = 0;

mysqli_begin_transaction($dbhandle);

try {
    foreach ($rows as $row) {
        $debitor  = trim($row['debitor'] ?? '');
        $name     = trim($row['name'] ?? '');
        $parcours = trim($row['parcours'] ?? '');
        $hu       = trim($row['hu'] ?? '');
        $platz    = trim($row['platz'] ?? '');
        $kartons  = trim($row['kartons'] ?? '');

        if ($platz === '' || $hu === '') {
            continue;
        }

        mysqli_stmt_bind_param(
            $stmt,
            "ssssss",
            $debitor,
            $name,
            $parcours,
            $hu,
            $platz,
            $kartons
        );

        mysqli_stmt_execute($stmt);
        $inserted++;
    }

    mysqli_commit($dbhandle);

    echo json_encode([
        "ok" => true,
        "inserted" => $inserted
    ]);

} catch (Throwable $e) {
    mysqli_rollback($dbhandle);

    echo json_encode([
        "ok" => false,
        "message" => "Import Fehler: " . $e->getMessage()
    ]);
}