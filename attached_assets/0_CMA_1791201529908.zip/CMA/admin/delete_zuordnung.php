<?php
require_once "../functions.php";

$id = (int)($_POST['id'] ?? 0);
$q = trim($_POST['q'] ?? '');

if ($id > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE einlagerung_zuordnung
        SET aktiv = 0, updated_at = ?
        WHERE id = ?
    ");

    $now = time();
    mysqli_stmt_bind_param($stmt, "ii", $now, $id);
    mysqli_stmt_execute($stmt);
}

header("Location: zuordnungen.php?q=" . urlencode($q));
exit;