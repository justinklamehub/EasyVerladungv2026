<?php
require_once "../functions.php";

$id              = (int)($_POST['id'] ?? 0);
$spediteurName1  = trim($_POST['spediteur_name1'] ?? '');
$farbe           = trim($_POST['farbe'] ?? '#ede9fe');
$textfarbe       = trim($_POST['textfarbe'] ?? '#111827');
$aktiv           = isset($_POST['aktiv']) ? 1 : 0;
$now             = time();

if ($spediteurName1 === '') {
    header("Location: speditionsfarben.php");
    exit;
}

if ($id > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE speditionsfarben
        SET spediteur_name1 = ?, farbe = ?, textfarbe = ?, aktiv = ?, updated_at = ?
        WHERE id = ?
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssiii",
        $spediteurName1,
        $farbe,
        $textfarbe,
        $aktiv,
        $now,
        $id
    );

    mysqli_stmt_execute($stmt);
} else {
    $stmt = mysqli_prepare($dbhandle, "
        INSERT INTO speditionsfarben (
            spediteur_name1,
            farbe,
            textfarbe,
            aktiv,
            created_at
        ) VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            farbe = VALUES(farbe),
            textfarbe = VALUES(textfarbe),
            aktiv = VALUES(aktiv),
            updated_at = UNIX_TIMESTAMP()
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "sssii",
        $spediteurName1,
        $farbe,
        $textfarbe,
        $aktiv,
        $now
    );

    mysqli_stmt_execute($stmt);
}

header("Location: speditionsfarben.php");
exit;