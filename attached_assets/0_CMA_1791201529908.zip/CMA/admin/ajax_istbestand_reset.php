<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

if (!mysqli_query($dbhandle, "TRUNCATE TABLE zlthu_istbestand")) {
    echo json_encode([
        "ok" => false,
        "message" => "Tabelle konnte nicht geleert werden: " . mysqli_error($dbhandle)
    ]);
    exit;
}

echo json_encode(["ok" => true]);