<?php 
require_once "../functions.php"; 
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Einlagerung Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">

    <style>
        body {
            background: #f3f5f8;
        }

        .admin-dashboard-header {
            margin-bottom: 24px;
        }

        .admin-dashboard-header h1 {
            margin-bottom: 6px;
        }

        .admin-subtitle {
            color: #64748b;
            font-size: 14px;
            font-weight: 600;
        }

        .admin-section {
            margin-bottom: 28px;
        }

        .admin-section-title {
            font-size: 15px;
            font-weight: 900;
            color: #334155;
            text-transform: uppercase;
            letter-spacing: .05em;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .admin-section-title span {
            background: #111827;
            color: #fff;
            border-radius: 999px;
            padding: 4px 9px;
            font-size: 12px;
        }

        .admin-grid.clean {
            margin-top: 0;
        }

        .admin-tile.featured {
            border-left: 6px solid #111827;
        }

        .admin-tile.import {
            border-left: 6px solid #2563eb;
        }

        .admin-tile.masterdata {
            border-left: 6px solid #16a34a;
        }

        .admin-tile.scanner {
            border-left: 6px solid #7c3aed;
        }

        .admin-tile.warning {
            border-left: 6px solid #dc2626;
        }

        .tile-kicker {
            display: block;
            font-size: 11px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: .06em;
            color: #64748b;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-dashboard-header">
        <h1>Einlagerung Admin</h1>
        <div class="admin-subtitle">
            Verwaltung, Importe, Lagerübersichten und Scannerfunktionen
        </div>
    </div>

    <div class="admin-section">
        <div class="admin-section-title">
            <span>01</span> Übersichten & operative Arbeit
        </div>

        <div class="admin-grid clean">
            <a class="admin-tile featured" href="lager_uebersicht.php">
                <span class="tile-kicker">Lager</span>
                <strong>Lagerübersicht</strong>
                <span>Alle Gänge und Regale als farbige Gesamtansicht anzeigen</span>
            </a>

            <a class="admin-tile featured" href="auftraege_lager_grid.php">
                <span class="tile-kicker">Aufträge</span>
                <strong>Aufträge Übersicht</strong>
                <span>Eingelagerte Aufträge je Regal anzeigen</span>
            </a>

            <a class="admin-tile warning" href="regale.php">
                <span class="tile-kicker">Status</span>
                <strong>Volle Regale</strong>
                <span>Gemeldete volle Regale prüfen und wieder freigeben</span>
            </a>

            <a class="admin-tile featured" href="zuordnungen.php">
                <span class="tile-kicker">Strategie</span>
                <strong>Artikelstamm</strong>
                <span>Artikel suchen, anlegen - Regale zuweisen und Prioritäten pflegen</span>
            </a>
        </div>
    </div>

    <div class="admin-section">
        <div class="admin-section-title">
            <span>02</span> Scanner
        </div>

        <div class="admin-grid clean">
            <a class="admin-tile scanner" href="../scanner.php">
                <span class="tile-kicker">Artikel</span>
                <strong>Einlagerungsstrategie Scanner</strong>
                <span>Scanneransicht für die Einlagerungsstrategie testen</span>
            </a>

            <a class="admin-tile scanner" href="../scanner_auftraege.php">
                <span class="tile-kicker">Aufträge</span>
                <strong>Aufträge Scanner</strong>
                <span>Aufträge suchen und Regale vormerken</span>
            </a>
        </div>
    </div>

    <div class="admin-section">
        <div class="admin-section-title">
            <span>03</span> Importe
        </div>

        <div class="admin-grid clean">
            <a class="admin-tile import" href="import_retouren.php">
                <span class="tile-kicker">CSV</span>
                <strong>Retouren Import</strong>
                <span>ZLTHU_RETOURE CSV importieren und Bestand aktualisieren</span>
            </a>

            <a class="admin-tile import" href="import_istbestand.php">
                <span class="tile-kicker">CSV</span>
                <strong>IST-Bestand Import</strong>
                <span>Aktuellen Lagerbestand per CSV importieren</span>
            </a>

            <a class="admin-tile import" href="import_zuordnung.php">
                <span class="tile-kicker">CSV</span>
                <strong>Einlagerungsstrategie Import</strong>
                <span>Artikel, Regale, Kundengruppen und Prioritäten importieren</span>
            </a>

            <a class="admin-tile import" href="import_eingelagerte_auftraege.php">
                <span class="tile-kicker">CSV</span>
                <strong>Eingelagerte Aufträge Import</strong>
                <span>Eingelagerte Aufträge per CSV importieren</span>
            </a>
        </div>
    </div>

    <div class="admin-section">
        <div class="admin-section-title">
            <span>04</span> Stammdaten
        </div>

        <div class="admin-grid clean">
            <a class="admin-tile masterdata" href="kundengruppen.php">
                <span class="tile-kicker">Farben</span>
                <strong>Kundengruppen</strong>
                <span>Kundengruppen anlegen, Farben pflegen und bearbeiten</span>
            </a>

            <a class="admin-tile masterdata" href="speditionsfarben.php">
                <span class="tile-kicker">Farben</span>
                <strong>Speditionsfarben</strong>
                <span>Farben für Speditionen verwalten</span>
            </a>
        </div>
    </div>

</div>

</body>
</html>