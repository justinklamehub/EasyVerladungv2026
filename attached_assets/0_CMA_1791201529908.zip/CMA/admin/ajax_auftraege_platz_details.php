<?php
require_once "../functions.php";

$platz = trim($_GET['platz'] ?? '');
$platzEsc = mysqli_real_escape_string($dbhandle, $platz);

$res = mysqli_query($dbhandle, "
    SELECT
        platz,
        spediteur_name1,
        relation,
        lfdat,
        plus_kw,
        kunde_name1,
        debitor,
        beleg,
        handling_unit,
        typ,
        ret_klasse,
        kartonanz
    FROM eingelagerte_auftraege
    WHERE platz = '{$platzEsc}'
    ORDER BY spediteur_name1 ASC, relation ASC, lfdat ASC, plus_kw ASC, kunde_name1 ASC
");
?>

<style>
.detail-table-wrap {
    overflow: auto;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
}

.detail-table {
    width: 100%;
    min-width: 1000px;
    border-collapse: collapse;
    font-size: 13px;
}

.detail-table th {
    background: #111827;
    color: #fff;
    padding: 11px;
    text-align: left;
    position: sticky;
    top: 0;
}

.detail-table td {
    padding: 10px 11px;
    border-bottom: 1px solid #e5e7eb;
}

.detail-table tr:hover td {
    background: #f8fafc;
}

.hu-badge {
    background: #ede9fe;
    color: #3b0764;
    padding: 4px 8px;
    border-radius: 999px;
    font-weight: 800;
    font-size: 12px;
}
</style>

<div class="detail-table-wrap">
    <table class="detail-table">
        <thead>
            <tr>
                <th>Spedition</th>
                <th>Relation</th>
                <th>Termin</th>
                <th>Kunde</th>
                <th>Debitor</th>
                <th>Beleg</th>
                <th>Handling Unit</th>
                <th>Typ</th>
                <th>KartonAnz</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($res && mysqli_num_rows($res) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($res)): ?>
                    <?php
                        $termin = trim($row['lfdat']);
                        if (trim($row['plus_kw']) !== '') {
                            $termin .= ' + ' . trim($row['plus_kw']);
                        }
                    ?>
                    <tr>
                        <td><strong><?= e($row['spediteur_name1']) ?></strong></td>
                        <td><?= e($row['relation']) ?></td>
                        <td><?= e($termin) ?></td>
                        <td><?= e($row['kunde_name1']) ?></td>
                        <td><?= e($row['debitor']) ?></td>
                        <td><?= e($row['beleg']) ?></td>
                        <td><span class="hu-badge"><?= e($row['handling_unit']) ?></span></td>
                        <td><?= e($row['typ']) ?></td>
                        <td><?= (int)$row['kartonanz'] ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" style="text-align:center; padding:22px; color:#64748b; font-weight:700;">
                        Keine eingelagerten Aufträge auf diesem Stellplatz gefunden.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>