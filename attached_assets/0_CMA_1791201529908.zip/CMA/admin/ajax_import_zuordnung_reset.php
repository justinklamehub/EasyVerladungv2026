<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$now = time();

$stmt = mysqli_prepare($dbhandle, "
    UPDATE einlagerung_zuordnung
    SET aktiv = 0, updated_at = ?
    WHERE aktiv = 1
");

mysqli_stmt_bind_param($stmt, "i", $now);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode([
        "ok" => false,
        "message" => "Strategie konnte nicht deaktiviert werden."
    ]);
    exit;
}

echo json_encode([
    "ok" => true
]);