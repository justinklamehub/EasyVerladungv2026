<?php
require_once "../functions.php";

$id = (int)($_POST['id'] ?? 0);

if ($id > 0) {
    mysqli_begin_transaction($dbhandle);

    try {
        $stmt = mysqli_prepare($dbhandle, "
            UPDATE einlagerung_zuordnung
            SET kundengruppe_id = NULL, updated_at = ?
            WHERE kundengruppe_id = ?
        ");
        $now = time();
        mysqli_stmt_bind_param($stmt, "ii", $now, $id);
        mysqli_stmt_execute($stmt);

        $stmt = mysqli_prepare($dbhandle, "
            DELETE FROM kundengruppen
            WHERE id = ?
        ");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        mysqli_commit($dbhandle);
    } catch (Throwable $e) {
        mysqli_rollback($dbhandle);
    }
}

header("Location: kundengruppen.php");
exit;