<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$q = trim($_GET['q'] ?? '');

if (mb_strlen($q) < 2) {
    echo json_encode([]);
    exit;
}

$like = "%" . $q . "%";

$stmt = mysqli_prepare($dbhandle, "
    SELECT id, artikelnummer, ean, artikelname
    FROM artikel
    WHERE aktiv = 1
      AND (
        artikelnummer LIKE ?
        OR ean LIKE ?
        OR artikelname LIKE ?
      )
    ORDER BY artikelnummer ASC
    LIMIT 20
");

mysqli_stmt_bind_param($stmt, "sss", $like, $like, $like);
mysqli_stmt_execute($stmt);

$res = mysqli_stmt_get_result($stmt);

$data = [];

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = [
        "id" => (int)$row['id'],
        "artikelnummer" => $row['artikelnummer'],
        "ean" => $row['ean'],
        "artikelname" => $row['artikelname']
    ];
}

echo json_encode($data);