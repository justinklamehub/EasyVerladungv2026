<?php
require_once "../functions.php";

/*
    Helper
*/
function getTerminStatus($lfdat) {
    $lfdat = trim($lfdat);
    $today = new DateTime('today');

    // Fixtermin: 18.12.2024
    if (preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $lfdat)) {
        $date = DateTime::createFromFormat('d.m.Y', $lfdat);

        if (!$date) {
            return ['status' => 'unknown', 'label' => 'Unbekannt', 'class' => 'term-unknown', 'days' => null];
        }

        $days = (int)$today->diff($date)->format('%r%a');

        if ($days < 0)  return ['status' => 'red', 'label' => 'Überfällig', 'class' => 'term-red', 'days' => $days];
        if ($days <= 2) return ['status' => 'red', 'label' => 'Kritisch', 'class' => 'term-red', 'days' => $days];
        if ($days <= 7) return ['status' => 'orange', 'label' => 'Bald fällig', 'class' => 'term-orange', 'days' => $days];
        if ($days <= 14) return ['status' => 'yellow', 'label' => 'Demnächst', 'class' => 'term-yellow', 'days' => $days];

        return ['status' => 'green', 'label' => 'Unkritisch', 'class' => 'term-green', 'days' => $days];
    }

    // KW-Termin: 47.2024
    if (preg_match('/^(\d{1,2})\.(\d{4})$/', $lfdat, $m)) {
        $kw = (int)$m[1];
        $year = (int)$m[2];

        // Montag der Liefer-KW
        $kwDate = new DateTime();
        $kwDate->setISODate($year, $kw, 1);
        $kwDate->setTime(0, 0, 0);

        $days = (int)$today->diff($kwDate)->format('%r%a');

        if ($days < 0)  return ['status' => 'red', 'label' => 'KW überfällig', 'class' => 'term-red', 'days' => $days];
        if ($days <= 2) return ['status' => 'red', 'label' => 'KW kritisch', 'class' => 'term-red', 'days' => $days];
        if ($days <= 7) return ['status' => 'orange', 'label' => 'KW bald fällig', 'class' => 'term-orange', 'days' => $days];
        if ($days <= 14) return ['status' => 'yellow', 'label' => 'KW demnächst', 'class' => 'term-yellow', 'days' => $days];

        return ['status' => 'green', 'label' => 'KW unkritisch', 'class' => 'term-green', 'days' => $days];
    }

    return [
        'status' => 'unknown',
        'label' => 'Unbekannt',
        'class' => 'term-unknown',
        'days' => null
    ];
}

function buildTerminFilterUrl($status) {
    $params = $_GET;

    if ($status === '') {
        unset($params['termin_status']);
    } else {
        $params['termin_status'] = $status;
    }

    return '?' . http_build_query($params);
}

/*
    Filter
*/
$filterGang          = $_GET['gang'] ?? '';
$filterSpedition     = trim($_GET['spedition'] ?? '');
$filterRelation      = trim($_GET['relation'] ?? '');
$filterTermin        = trim($_GET['termin'] ?? '');
$filterSuche         = trim($_GET['suche'] ?? '');
$filterTerminStatus  = trim($_GET['termin_status'] ?? '');

/*
    Filterdaten laden
*/
$speditionRes = mysqli_query($dbhandle, "
    SELECT DISTINCT spediteur_name1
    FROM eingelagerte_auftraege
    WHERE spediteur_name1 <> ''
    ORDER BY spediteur_name1 ASC
");

$relationRes = mysqli_query($dbhandle, "
    SELECT DISTINCT relation
    FROM eingelagerte_auftraege
    WHERE relation <> ''
    ORDER BY relation ASC
");

$terminRes = mysqli_query($dbhandle, "
    SELECT DISTINCT lfdat, plus_kw
    FROM eingelagerte_auftraege
    WHERE lfdat <> ''
    ORDER BY lfdat ASC, plus_kw ASC
");

/*
    WHERE für Auftrag-Query mit Alias ea
*/
$where = ["ea.platz <> ''"];

if ($filterGang !== '') {
    $gangEsc = mysqli_real_escape_string($dbhandle, $filterGang);
    $where[] = "ea.platz LIKE '{$gangEsc}-%'";
}

if ($filterSpedition !== '') {
    $speditionEsc = mysqli_real_escape_string($dbhandle, $filterSpedition);
    $where[] = "ea.spediteur_name1 = '{$speditionEsc}'";
}

if ($filterRelation !== '') {
    $relationEsc = mysqli_real_escape_string($dbhandle, $filterRelation);
    $where[] = "ea.relation = '{$relationEsc}'";
}

if ($filterTermin !== '') {
    $terminEsc = mysqli_real_escape_string($dbhandle, $filterTermin);
    $where[] = "CONCAT(ea.lfdat, ' + ', ea.plus_kw) = '{$terminEsc}'";
}

if ($filterSuche !== '') {
    $sucheEsc = mysqli_real_escape_string($dbhandle, $filterSuche);
    $where[] = "
        (
            ea.spediteur_name1 LIKE '%{$sucheEsc}%'
            OR ea.relation LIKE '%{$sucheEsc}%'
            OR ea.kunde_name1 LIKE '%{$sucheEsc}%'
            OR ea.debitor LIKE '%{$sucheEsc}%'
            OR ea.beleg LIKE '%{$sucheEsc}%'
            OR ea.handling_unit LIKE '%{$sucheEsc}%'
            OR ea.platz LIKE '%{$sucheEsc}%'
        )
    ";
}

$whereSql = "WHERE " . implode(" AND ", $where);

/*
    Regale als Basis laden
*/
$regalRes = mysqli_query($dbhandle, "
    SELECT 
        lr.id AS regal_id,
        lr.regal_nr,
        lr.voll_gemeldet,
        lg.gang_nr
    FROM lager_regale lr
    JOIN lager_gaenge lg ON lg.id = lr.gang_id
    ORDER BY lg.gang_nr ASC, lr.regal_nr ASC
");

/*
    Grid vorbereiten
*/
$grid = [];

while ($row = mysqli_fetch_assoc($regalRes)) {

    $parts = explode('-', $row['regal_nr']);
    if (count($parts) !== 2) continue;

    $gang  = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if ($filterGang && $gang !== $filterGang) {
        continue;
    }

    $grid[$rowNr][$gang] = [
        "regal_id" => $row['regal_id'],
        "regal_nr" => $row['regal_nr'],
        "voll" => (int)$row['voll_gemeldet'],
        "auftrag_total" => 0,
        "auftrag_details" => []
    ];
}

/*
    Auftragsdaten laden
*/
$auftragRes = mysqli_query($dbhandle, "
    SELECT 
        ea.platz,
        ea.spediteur_name1,
        ea.relation,
        ea.lfdat,
        ea.plus_kw,
        COALESCE(sf.farbe, '#ede9fe') AS farbe,
        COALESCE(sf.textfarbe, '#3b0764') AS textfarbe,
        COUNT(*) AS paletten
    FROM eingelagerte_auftraege ea
    LEFT JOIN speditionsfarben sf
        ON sf.spediteur_name1 = ea.spediteur_name1
        AND sf.aktiv = 1
    {$whereSql}
    GROUP BY 
        ea.platz,
        ea.spediteur_name1,
        ea.relation,
        ea.lfdat,
        ea.plus_kw,
        sf.farbe,
        sf.textfarbe
    ORDER BY ea.platz ASC, ea.spediteur_name1 ASC
");

/*
    Dynamische KPI-Werte passend zum sichtbaren Grid
*/
$kpi = [
    'paletten' => 0,
    'stellplaetze' => [],
    'speditionen' => [],
    'relationen' => []
];

while ($auftrag = mysqli_fetch_assoc($auftragRes)) {

    /*
        Terminstatus-Filter MUSS vor dem Einfügen ins Grid kommen
    */
    $terminStatus = getTerminStatus($auftrag['lfdat']);

    if ($filterTerminStatus !== '' && $terminStatus['status'] !== $filterTerminStatus) {
        continue;
    }

    $platz = $auftrag['platz'];
    $parts = explode('-', $platz);

    if (count($parts) !== 2) continue;

    $gang  = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if (!isset($grid[$rowNr][$gang])) {
        continue;
    }

    $paletten = (int)$auftrag['paletten'];

    $termin = trim($auftrag['lfdat']);
    if (trim($auftrag['plus_kw']) !== '') {
        $termin .= ' + ' . trim($auftrag['plus_kw']);
    }

    $grid[$rowNr][$gang]['auftrag_total'] += $paletten;

    $grid[$rowNr][$gang]['auftrag_details'][] = [
        "spedition" => $auftrag['spediteur_name1'],
        "relation" => $auftrag['relation'],
        "termin" => $termin,
        "paletten" => $paletten,
        "farbe" => $auftrag['farbe'] ?: '#ede9fe',
        "textfarbe" => $auftrag['textfarbe'] ?: '#3b0764',
        "termin_status" => $terminStatus
    ];

    $kpi['paletten'] += $paletten;
    $kpi['stellplaetze'][$platz] = true;
    $kpi['speditionen'][$auftrag['spediteur_name1']] = true;
    $kpi['relationen'][$auftrag['relation']] = true;
}

$kpiPaletten    = (int)$kpi['paletten'];
$kpiStellplätze = count($kpi['stellplaetze']);
$kpiSpeditionen = count($kpi['speditionen']);
$kpiRelationen  = count($kpi['relationen']);

/*
    Terminübersicht berechnen
    Hier bewusst OHNE termin_status-Filter, damit die Ampel immer alle Status zählt
*/
$terminOverviewRes = mysqli_query($dbhandle, "
    SELECT
        ea.spediteur_name1,
        ea.relation,
        ea.lfdat,
        ea.plus_kw,
        ea.platz,
        COUNT(*) AS paletten
    FROM eingelagerte_auftraege ea
    {$whereSql}
    GROUP BY ea.spediteur_name1, ea.relation, ea.lfdat, ea.plus_kw, ea.platz
    ORDER BY ea.lfdat ASC, ea.plus_kw ASC
");

$terminStats = [
    'red' => 0,
    'orange' => 0,
    'yellow' => 0,
    'green' => 0,
    'kw' => 0,
    'unknown' => 0
];

$terminRows = [];

while ($t = mysqli_fetch_assoc($terminOverviewRes)) {
    $status = getTerminStatus($t['lfdat']);
    $paletten = (int)$t['paletten'];

    $terminStats[$status['status']] += $paletten;

    $termin = trim($t['lfdat']);
    if (trim($t['plus_kw']) !== '') {
        $termin .= ' + ' . trim($t['plus_kw']);
    }

    $terminRows[] = [
        'status' => $status,
        'termin' => $termin,
        'platz' => $t['platz'],
        'spedition' => $t['spediteur_name1'],
        'relation' => $t['relation'],
        'paletten' => $paletten
    ];
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Aufträge Lagergrid</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../assets/app.css">

<style>
body {
    background: #f3f5f8;
}

.lager-page {
    max-width: none;
    padding: 22px;
}

.lager-toolbar {
    background: #ffffff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
    margin-bottom: 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.filter-group select,
.filter-group input {
    min-width: 180px;
    padding: 11px 13px;
    border: 1px solid #d8dee8;
    border-radius: 12px;
    background: #f8fafc;
    font-size: 14px;
    outline: none;
}

.filter-group input {
    min-width: 260px;
}

.filter-actions button {
    border: 0;
    background: #111827;
    color: #fff;
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 700;
    cursor: pointer;
}

.kpi-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(150px, 1fr));
    gap: 14px;
    margin-bottom: 18px;
}

.kpi-card {
    background: #fff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.kpi-label {
    font-size: 12px;
    font-weight: 800;
    color: #64748b;
    text-transform: uppercase;
}

.kpi-value {
    font-size: 30px;
    font-weight: 900;
    color: #111827;
    margin-top: 6px;
}

.grid-shell {
    background: #fff;
    border-radius: 20px;
    padding: 14px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.grid-wrap {
    max-height: calc(100vh - 330px);
    overflow: auto;
    border-radius: 14px;
    border: 1px solid #e5e7eb;
}

.grid-table {
    border-collapse: separate;
    border-spacing: 0;
    font-size: 12px;
    min-width: 2450px;
    width: max-content;
}

.grid-table thead th {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #111827;
    color: #fff;
    padding: 12px 10px;
    text-align: center;
    font-size: 13px;
}

.grid-table thead th:first-child {
    left: 0;
    z-index: 30;
}

.row-label {
    position: sticky;
    left: 0;
    z-index: 10;
    background: #f1f5f9;
    color: #334155;
    font-weight: 800;
    text-align: center;
    min-width: 10px;
    max-width: 30px;
    border-right: 1px solid #dbe3ee;
}

.grid-table td {
    border-right: 1px solid #e5e7eb;
    border-bottom: 1px solid #e5e7eb;
    width: 132px;
    height: 86px;
    padding: 6px;
    vertical-align: top;
    background: #f8fafc;
}

.regal-cell {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 12px;
    padding: 7px;
    background: #ffffff;
    box-shadow: inset 0 0 0 1px rgba(15, 23, 42, .06);
    cursor: pointer;
    transition: .15s ease;
    overflow: hidden;
}

.regal-cell:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 18px rgba(15, 23, 42, .16);
}

.regal-cell.empty {
    color: #94a3b8;
    background: repeating-linear-gradient(
        -45deg,
        #f8fafc,
        #f8fafc 8px,
        #eef2f7 8px,
        #eef2f7 16px
    );
}

.regal-cell.full {
    background: #fff1f2 !important;
    box-shadow: inset 0 0 0 2px #ef4444;
}

.auftrag-count {
    position: absolute;
    top: 6px;
    right: 6px;
    background: #7c3aed;
    color: #fff;
    padding: 5px 9px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 900;
}

.regal-title {
    font-size: 11px;
    font-weight: 900;
    color: #334155;
    margin-bottom: 6px;
}

.auftrag-item {
    background: #ede9fe;
    color: #3b0764;
    padding: 4px 6px;
    border-radius: 9px;
    font-size: 10px;
    font-weight: 800;
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.auftrag-item small {
    display: block;
    opacity: .75;
    font-weight: 700;
    margin-top: 1px;
}

.more-items {
    font-size: 10px;
    color: #475569;
    font-weight: 800;
}

.empty-text {
    color: #94a3b8;
    font-weight: 700;
    font-size: 12px;
}

/* Modal */
.modal-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.65);
    backdrop-filter: blur(4px);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
}

.modal {
    width: 100%;
    max-width: 1050px;
    max-height: 90vh;
    background: #ffffff;
    border-radius: 18px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.25);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.modal-header {
    padding: 18px 20px;
    background: #111827;
    color: #fff;
    font-size: 18px;
    font-weight: 700;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-close {
    background: rgba(255,255,255,0.15);
    border: 0;
    color: #fff;
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
}

.modal-body {
    padding: 20px;
    overflow-y: auto;
}

.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
}

.modal-btn {
    background: #111827;
    color: #fff;
    border: 0;
    padding: 10px 14px;
    border-radius: 10px;
    font-weight: bold;
    cursor: pointer;
}

/* Termine */
.termin-overview {
    background: #ffffff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
    margin-bottom: 18px;
}

.termin-overview h2 {
    margin: 0 0 14px 0;
    font-size: 18px;
}

.termin-ampel {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 14px;
}

.term-pill {
    border-radius: 999px;
    padding: 8px 12px;
    font-weight: 900;
    font-size: 13px;
}

.term-red {
    background: #fee2e2;
    color: #991b1b;
}

.term-orange {
    background: #ffedd5;
    color: #9a3412;
}

.term-yellow {
    background: #fef9c3;
    color: #854d0e;
}

.term-green {
    background: #dcfce7;
    color: #166534;
}

.term-kw {
    background: #dbeafe;
    color: #1e40af;
}

.term-unknown {
    background: #e5e7eb;
    color: #374151;
}

.termin-ampel a {
    text-decoration: none;
    display: inline-block;
}

.active-term {
    outline: 3px solid #111827;
    box-shadow: 0 6px 16px rgba(15, 23, 42, .25);
}

.termin-table-wrap {
    max-height: 230px;
    overflow: auto;
    border-radius: 14px;
    border: 1px solid #e5e7eb;
}

.termin-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.termin-table th {
    position: sticky;
    top: 0;
    background: #111827;
    color: #fff;
    padding: 10px;
    text-align: left;
}

.termin-table td {
    padding: 10px;
    border-bottom: 1px solid #e5e7eb;
}
</style>
</head>

<body>

<div class="admin-wrapper lager-page">

    <div class="admin-header">
        <h1>Aufträge Lagergrid</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-label">Paletten</div>
            <div class="kpi-value"><?= (int)$kpiPaletten ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Stellplätze</div>
            <div class="kpi-value"><?= (int)$kpiStellplätze ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Speditionen</div>
            <div class="kpi-value"><?= (int)$kpiSpeditionen ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Relationen</div>
            <div class="kpi-value"><?= (int)$kpiRelationen ?></div>
        </div>
    </div>

    <div class="termin-overview">
        <h2>Kritische Liefertermine</h2>

        <div class="termin-ampel">
            <a class="term-pill term-red <?= $filterTerminStatus === 'red' ? 'active-term' : '' ?>" href="<?= e(buildTerminFilterUrl('red')) ?>">
                Kritisch: <?= (int)$terminStats['red'] ?> Pal.
            </a>

            <a class="term-pill term-orange <?= $filterTerminStatus === 'orange' ? 'active-term' : '' ?>" href="<?= e(buildTerminFilterUrl('orange')) ?>">
                Bald fällig: <?= (int)$terminStats['orange'] ?> Pal.
            </a>

            <a class="term-pill term-yellow <?= $filterTerminStatus === 'yellow' ? 'active-term' : '' ?>" href="<?= e(buildTerminFilterUrl('yellow')) ?>">
                Demnächst: <?= (int)$terminStats['yellow'] ?> Pal.
            </a>

            <a class="term-pill term-green <?= $filterTerminStatus === 'green' ? 'active-term' : '' ?>" href="<?= e(buildTerminFilterUrl('green')) ?>">
                Unkritisch: <?= (int)$terminStats['green'] ?> Pal.
            </a>

            <a class="term-pill term-kw <?= $filterTerminStatus === 'kw' ? 'active-term' : '' ?>" href="<?= e(buildTerminFilterUrl('kw')) ?>">
                KW-Termine: <?= (int)$terminStats['kw'] ?> Pal.
            </a>

            <?php if ($filterTerminStatus !== ''): ?>
                <a class="term-pill term-unknown" href="<?= e(buildTerminFilterUrl('')) ?>">
                    Terminfilter entfernen
                </a>
            <?php endif; ?>
        </div>

        <div class="termin-table-wrap">
            <table class="termin-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Termin</th>
                        <th>Regal</th>
                        <th>Spedition</th>
                        <th>Relation</th>
                        <th>Paletten</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($terminRows as $row): ?>
                        <?php if (!in_array($row['status']['status'], ['red', 'orange', 'yellow', 'kw'])) continue; ?>

                        <tr>
                            <td>
                                <span class="term-pill <?= e($row['status']['class']) ?>">
                                    <?= e($row['status']['label']) ?>
                                </span>
                            </td>
                            <td><strong><?= e($row['termin']) ?></strong></td>
                            <td><strong><?= e($row['platz']) ?></strong></td>
                            <td><?= e($row['spedition']) ?></td>
                            <td><?= e($row['relation']) ?></td>
                            <td><strong><?= (int)$row['paletten'] ?> Pal.</strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="lager-toolbar">

        <div class="filter-group">
            <label>Gang</label>
            <select id="filterGang" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php for ($i=1; $i<=18; $i++): ?>
                    <?php $g = str_pad($i, 2, '0', STR_PAD_LEFT); ?>
                    <option value="<?= $g ?>" <?= $filterGang === $g ? 'selected' : '' ?>>
                        <?= $g ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Spedition</label>
            <select id="filterSpedition" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($sp = mysqli_fetch_assoc($speditionRes)): ?>
                    <option value="<?= e($sp['spediteur_name1']) ?>" <?= $filterSpedition === $sp['spediteur_name1'] ? 'selected' : '' ?>>
                        <?= e($sp['spediteur_name1']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Relation</label>
            <select id="filterRelation" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($rel = mysqli_fetch_assoc($relationRes)): ?>
                    <option value="<?= e($rel['relation']) ?>" <?= $filterRelation === $rel['relation'] ? 'selected' : '' ?>>
                        <?= e($rel['relation']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Liefertermin / +KW</label>
            <select id="filterTermin" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($te = mysqli_fetch_assoc($terminRes)): ?>
                    <?php
                        $terminValue = trim($te['lfdat']);
                        if (trim($te['plus_kw']) !== '') {
                            $terminValue .= ' + ' . trim($te['plus_kw']);
                        }
                    ?>
                    <option value="<?= e($terminValue) ?>" <?= $filterTermin === $terminValue ? 'selected' : '' ?>>
                        <?= e($terminValue) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Suche</label>
            <input 
                type="text"
                id="filterSuche"
                value="<?= e($filterSuche) ?>"
                placeholder="HU, Beleg, Kunde, Platz..."
                oninput="applyFilterDelayed()"
            >
        </div>

        <div class="filter-actions">
            <button onclick="resetFilter()">Reset</button>
        </div>

    </div>

    <div class="grid-shell">
        <div class="grid-wrap">
            <table class="grid-table">
                <thead>
                    <tr class="hall-row">
                        <th></th>
                        <th colspan="6">Halle 1</th>
                        <th colspan="6">Halle 2</th>
                        <th colspan="6">Halle 3</th>
                    </tr>
                    <tr>
                        <th></th>
                        <?php for ($g=1; $g<=18; $g++): ?>
                            <th><?= str_pad($g, 2, '0', STR_PAD_LEFT) ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>

                <tbody>
                <?php for ($r=45; $r>=1; $r--): ?>
                    <?php $rowKey = str_pad($r, 2, '0', STR_PAD_LEFT); ?>
                    <tr>
                        <td class="row-label"><?= $rowKey ?></td>

                        <?php for ($g=1; $g<=18; $g++): ?>
                            <?php
                                $gangKey = str_pad($g, 2, '0', STR_PAD_LEFT);
                                $cell = $grid[$rowKey][$gangKey] ?? null;
                                $hasAuftraege = $cell && (int)$cell['auftrag_total'] > 0;
                            ?>

                            <td onclick="openAuftragModal('<?= $gangKey ?>-<?= $rowKey ?>')">
                                <div class="regal-cell <?= !$hasAuftraege ? 'empty' : '' ?> <?= $cell && $cell['voll'] ? 'full' : '' ?>">

                                    <div class="regal-title"><?= $gangKey ?>-<?= $rowKey ?></div>

                                    <?php if ($hasAuftraege): ?>
                                        <?php
                                            $firstColor = $cell['auftrag_details'][0]['farbe'] ?? '#7c3aed';
                                            $firstTextColor = $cell['auftrag_details'][0]['textfarbe'] ?? '#ffffff';
                                        ?>

                                        <div 
                                            class="auftrag-count"
                                            style="background:<?= e($firstColor) ?>; color:<?= e($firstTextColor) ?>;"
                                        >
                                            <?= (int)$cell['auftrag_total'] ?>
                                        </div>

                                        <?php $shown = 0; ?>
                                        <?php foreach ($cell['auftrag_details'] as $detail): ?>
                                            <?php if ($shown >= 2) break; ?>
                                            <div 
                                                class="auftrag-item"
                                                style="
                                                    background:<?= e($detail['farbe']) ?>;
                                                    color:<?= e($detail['textfarbe']) ?>;
                                                "
                                            >
                                                <?= e($detail['spedition']) ?>
                                                <small><?= e($detail['relation']) ?> · <?= e($detail['termin']) ?></small>
                                            </div>
                                            <?php $shown++; ?>
                                        <?php endforeach; ?>

                                        <?php if (count($cell['auftrag_details']) > 2): ?>
                                            <div class="more-items">
                                                + <?= count($cell['auftrag_details']) - 2 ?> weitere
                                            </div>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <span class="empty-text">Leer</span>
                                    <?php endif; ?>

                                </div>
                            </td>
                        <?php endfor; ?>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<div class="modal-backdrop" id="modal">
    <div class="modal">
        <div class="modal-header">
            <span id="modalTitle">Auftragsdetails</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>

        <div class="modal-body" id="modalContent">
            Lade...
        </div>

        <div class="modal-footer">
            <button class="modal-btn" onclick="closeModal()">Schließen</button>
        </div>
    </div>
</div>

<script>
let filterTimer = null;

function applyFilterDelayed() {
    clearTimeout(filterTimer);
    filterTimer = setTimeout(applyFilter, 500);
}

function applyFilter() {
    const gang      = document.getElementById('filterGang').value;
    const spedition = document.getElementById('filterSpedition').value;
    const relation  = document.getElementById('filterRelation').value;
    const termin    = document.getElementById('filterTermin').value;
    const suche     = document.getElementById('filterSuche').value.trim();

    const url = new URL(window.location.href);

    url.searchParams.set('gang', gang);
    url.searchParams.set('spedition', spedition);
    url.searchParams.set('relation', relation);
    url.searchParams.set('termin', termin);
    url.searchParams.set('suche', suche);

    if (!gang) url.searchParams.delete('gang');
    if (!spedition) url.searchParams.delete('spedition');
    if (!relation) url.searchParams.delete('relation');
    if (!termin) url.searchParams.delete('termin');
    if (!suche) url.searchParams.delete('suche');

    window.location.href = url.toString();
}

function resetFilter() {
    window.location.href = "auftraege_lager_grid.php";
}

function openAuftragModal(platz) {
    document.getElementById('modal').style.display = 'flex';
    document.getElementById('modalTitle').innerText = 'Auftragsdetails ' + platz;
    document.getElementById('modalContent').innerHTML = 'Lade...';

    fetch('ajax_auftraege_platz_details.php?platz=' + encodeURIComponent(platz))
        .then(r => r.text())
        .then(html => {
            document.getElementById('modalContent').innerHTML = html;
        });
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

document.getElementById('modal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});
</script>

</body>
</html>