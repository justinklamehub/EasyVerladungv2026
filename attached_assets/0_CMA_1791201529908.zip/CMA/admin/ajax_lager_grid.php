<?php
require_once "../functions.php";

$filterGang = $_GET['gang'] ?? '';
$filterKg   = $_GET['kg'] ?? '';
$filterFull = $_GET['full'] ?? '';
$filterArtikel = trim($_GET['artikel'] ?? '');

$sql = "
    SELECT 
        lr.id AS regal_id,
        lr.regal_nr,
        lr.sortierung,
        lr.voll_gemeldet,
        lg.gang_nr,
        a.artikelnummer,
        a.artikelname,
        kg.name AS kundengruppe,
        kg.farbe
    FROM lager_regale lr
    JOIN lager_gaenge lg 
        ON lg.id = lr.gang_id
    LEFT JOIN einlagerung_zuordnung ez 
        ON ez.regal_id = lr.id 
        AND ez.aktiv = 1
    LEFT JOIN artikel a 
        ON a.id = ez.artikel_id
    LEFT JOIN kundengruppen kg 
        ON kg.id = ez.kundengruppe_id
";

$res = mysqli_query($dbhandle, $sql);

$grid = [];

while ($row = mysqli_fetch_assoc($res)) {

    if ($filterGang && $row['gang_nr'] !== $filterGang) {
        continue;
    }

    if ($filterFull !== '' && (int)$row['voll_gemeldet'] !== (int)$filterFull) {
        continue;
    }

    if ($filterKg && $row['kundengruppe'] !== $filterKg) {
        continue;
    }

    if ($filterArtikel !== '') {
        if (stripos((string)$row['artikelnummer'], $filterArtikel) === false) {
            continue;
        }
    }

    $rowNr = substr($row['regal_nr'], 3);
    $gang  = $row['gang_nr'];

    if (!isset($grid[$rowNr][$gang])) {
        $grid[$rowNr][$gang] = [
            "regal_id" => $row['regal_id'],
            "voll" => (int)$row['voll_gemeldet'],
            "retouren_paletten" => 0,
            "retouren_details" => [],
            "ist_total" => 0,
            "ist_details" => [],
            "items" => [],
            "item_keys" => []
        ];
    }

    if (!empty($row['artikelnummer'])) {
        $artikelKey = $row['artikelnummer'];

        if (!isset($grid[$rowNr][$gang]["item_keys"][$artikelKey])) {
            $grid[$rowNr][$gang]["items"][] = [
                "artikelnummer" => $row['artikelnummer'],
                "artikelname" => $row['artikelname'],
                "kundengruppe" => $row['kundengruppe'],
                "farbe" => $row['farbe']
            ];

            $grid[$rowNr][$gang]["item_keys"][$artikelKey] = true;
        }
    }
}

/*
    Retouren separat laden, damit keine Multiplikation mit Artikeln passiert
*/
$retRes = mysqli_query($dbhandle, "
    SELECT 
        platz,
        parcours,
        COUNT(*) AS paletten
    FROM zlthu_retoure
    GROUP BY platz, parcours
");

while ($ret = mysqli_fetch_assoc($retRes)) {
    $platz = $ret['platz'];
    $parcours = $ret['parcours'];
    $paletten = (int)$ret['paletten'];

    $parts = explode('-', $platz);
    if (count($parts) !== 2) continue;

    $gang = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if (!isset($grid[$rowNr][$gang])) continue;

    $grid[$rowNr][$gang]['retouren_paletten'] += $paletten;

    $grid[$rowNr][$gang]['retouren_details'][] = [
        'parcours' => $parcours,
        'paletten' => $paletten
    ];
}

/*
    IST-Bestand separat laden
    Eine Lagereinheit pro Regal = eine Palette
*/
$istRes = mysqli_query($dbhandle, "
    SELECT 
        lagerplatz,
        material,
        COUNT(*) AS paletten
    FROM zlthu_istbestand
    GROUP BY lagerplatz, material
");

while ($ist = mysqli_fetch_assoc($istRes)) {
    $platz = $ist['lagerplatz'];
    $material = $ist['material'];
    $paletten = (int)$ist['paletten'];

    $parts = explode('-', $platz);
    if (count($parts) !== 2) continue;

    $gang = str_pad($parts[0], 2, '0', STR_PAD_LEFT);
    $rowNr = str_pad($parts[1], 2, '0', STR_PAD_LEFT);

    if (!isset($grid[$rowNr][$gang])) continue;

    $grid[$rowNr][$gang]['ist_total'] += $paletten;

    $grid[$rowNr][$gang]['ist_details'][] = [
        'material' => $material,
        'paletten' => $paletten
    ];
}
?>

<table class="grid-table">
<thead>

<tr class="hall-row">
    <th></th>
    <th colspan="6">Halle 1</th>
    <th colspan="6">Halle 2</th>
    <th colspan="6">Halle 3</th>
</tr>

<tr>
    <th></th>
    <?php for ($g = 1; $g <= 18; $g++): ?>
        <th><?= str_pad($g, 2, '0', STR_PAD_LEFT) ?></th>
    <?php endfor; ?>
</tr>

</thead>

<tbody>
<?php for ($r = 45; $r >= 1; $r--): 
    $rowKey = str_pad($r, 2, '0', STR_PAD_LEFT);
?>
<tr>
    <td class="row-label"><?= $rowKey ?></td>

    <?php for ($g = 1; $g <= 18; $g++): 
        $gangKey = str_pad($g, 2, '0', STR_PAD_LEFT);
        $cell = $grid[$rowKey][$gangKey] ?? null;
    ?>

    <td onclick="openModal(<?= $cell['regal_id'] ?? 0 ?>)">
        <div class="regal-cell <?= !$cell || !count($cell['items']) ? 'empty' : '' ?> <?= $cell && $cell['voll'] ? 'full' : '' ?>">

            <?php if ($cell && count($cell['items'])): ?>
                <?php foreach ($cell['items'] as $it): ?>
                    <div class="item" style="background:<?= e($it['farbe'] ?: '#ddd') ?>">
                        <strong><?= e($it['artikelnummer']) ?></strong>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <span style="color:#999;">nicht verplant</span>
            <?php endif; ?>

            <?php if ($cell && (int)$cell['retouren_paletten'] > 0): ?>
                <div class="retouren-badge tooltip-wrap">
                    <?= (int)$cell['retouren_paletten'] ?>

                    <div class="retouren-tooltip">
                        <strong><?= (int)$cell['retouren_paletten'] ?> RetourenRetouren Paletten gesamt</strong>

                        <?php if (!empty($cell['retouren_details'])): ?>
                            <?php foreach ($cell['retouren_details'] as $ret): ?>
                                <div class="tooltip-row">
                                    <span><?= e($ret['parcours']) ?></span>
                                    <b><?= (int)$ret['paletten'] ?> Pal.</b>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="tooltip-row">
                                <span>Keine Retouren vorhanden</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($cell && !empty($cell['ist_total']) && (int)$cell['ist_total'] > 0): ?>
                <div class="ist-badge tooltip-wrap">
                    <?= (int)$cell['ist_total'] ?>

                    <div class="retouren-tooltip">
                        <strong><?= (int)$cell['ist_total'] ?> Bestandspaletten gesamt</strong>

                        <?php foreach ($cell['ist_details'] as $ist): ?>
                            <div class="tooltip-row">
                                <span><?= e($ist['material']) ?></span>
                                <b><?= (int)$ist['paletten'] ?> Pal.</b>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </td>

    <?php endfor; ?>
</tr>
<?php endfor; ?>
</tbody>
</table>