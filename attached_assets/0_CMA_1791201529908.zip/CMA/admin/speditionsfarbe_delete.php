<?php
require_once "../functions.php";

$id = (int)($_POST['id'] ?? 0);

if ($id > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        DELETE FROM speditionsfarben
        WHERE id = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
}

header("Location: speditionsfarben.php");
exit;