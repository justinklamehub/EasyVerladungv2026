<?php
require_once "../functions.php";
header('Content-Type: application/json; charset=utf-8');

$sql = "TRUNCATE TABLE eingelagerte_auftraege";

if (!mysqli_query($dbhandle, $sql)) {
    echo json_encode([
        "ok" => false,
        "message" => "Tabelle konnte nicht geleert werden: " . mysqli_error($dbhandle)
    ]);
    exit;
}

echo json_encode([
    "ok" => true,
    "message" => "Tabelle wurde geleert."
]);