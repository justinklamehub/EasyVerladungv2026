<?php
require_once "../functions.php";

$regalId = (int)($_POST['regal_id'] ?? 0);

if ($regalId > 0) {
    mysqli_begin_transaction($dbhandle);

    try {
        $stmt = mysqli_prepare($dbhandle, "
            UPDATE lager_regale
            SET 
                voll_gemeldet = 0,
                voll_gemeldet_at = NULL,
                voll_hinweis = NULL
            WHERE id = ?
        ");
        mysqli_stmt_bind_param($stmt, "i", $regalId);
        mysqli_stmt_execute($stmt);

        $now = time();

        $stmt = mysqli_prepare($dbhandle, "
            UPDATE regal_voll_meldungen
            SET erledigt = 1, erledigt_at = ?
            WHERE regal_id = ?
              AND erledigt = 0
        ");
        mysqli_stmt_bind_param($stmt, "ii", $now, $regalId);
        mysqli_stmt_execute($stmt);

        mysqli_commit($dbhandle);
    } catch (Throwable $e) {
        mysqli_rollback($dbhandle);
    }
}

header("Location: regale.php");
exit;