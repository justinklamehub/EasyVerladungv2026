<?php
require_once "../functions.php";

$editId = (int)($_GET['edit'] ?? 0);
$editRow = null;

if ($editId > 0) {
    $stmt = mysqli_prepare($dbhandle, "SELECT id, name, farbe FROM kundengruppen WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $editId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $editRow = mysqli_fetch_assoc($res);
}

$res = mysqli_query($dbhandle, "
    SELECT id, name, farbe
    FROM kundengruppen
    ORDER BY name ASC
");
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Kundengruppen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../assets/app.css">
</head>
<body>

<div class="admin-wrapper">

    <div class="admin-header">
        <h1>Kundengruppen</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="admin-card">
        <h2><?= $editRow ? 'Kundengruppe bearbeiten' : 'Neue Kundengruppe anlegen' ?></h2>

        <form method="post" action="kundengruppe_save.php" class="admin-form">
            <input type="hidden" name="id" value="<?= (int)($editRow['id'] ?? 0) ?>">

            <label>Name</label>
            <input type="text" name="name" value="<?= e($editRow['name'] ?? '') ?>" required>

            <label>Farbe</label>
            <div class="color-picker-wrap">
                <input type="color" id="farbePicker" value="<?= e($editRow['farbe'] ?? '#dddddd') ?>">
                <input type="text" name="farbe" id="farbeInput" value="<?= e($editRow['farbe'] ?? '#dddddd') ?>">
            </div>

            <button type="submit" class="admin-save">
                <?= $editRow ? 'Speichern' : 'Anlegen' ?>
            </button>

            <?php if ($editRow): ?>
                <a href="kundengruppen.php" class="admin-back" style="display:inline-block; margin-top:10px;">
                    Abbrechen
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="admin-card">
        <h2>Bestehende Kundengruppen</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Farbe</th>
                        <th>Vorschau</th>
                        <th>Aktion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($res) === 0): ?>
                        <tr>
                            <td colspan="4">Noch keine Kundengruppen vorhanden.</td>
                        </tr>
                    <?php endif; ?>

                    <?php while ($row = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= e($row['name']) ?></td>
                            <td><?= e($row['farbe']) ?></td>
                            <td>
                                <span class="kg-badge" style="background:<?= e($row['farbe'] ?: '#ddd') ?>">
                                    <?= e($row['name']) ?>
                                </span>
                            </td>
                            <td style="display:flex; gap:8px;">
                                <a class="admin-small-btn" href="kundengruppen.php?edit=<?= (int)$row['id'] ?>">
                                    Bearbeiten
                                </a>

                                <form method="post" action="kundengruppe_delete.php" onsubmit="return confirm('Kundengruppe wirklich löschen? Bestehende Zuordnungen verlieren dadurch diese Kundengruppe.');">
                                    <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                                    <button type="submit" class="admin-delete">Löschen</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>


<script>
const picker = document.getElementById('farbePicker');
const input = document.getElementById('farbeInput');

function updateColor(val) {
    input.value = val;
    input.style.background = val;

    // automatische Schriftfarbe je nach Helligkeit
    const r = parseInt(val.substr(1,2),16);
    const g = parseInt(val.substr(3,2),16);
    const b = parseInt(val.substr(5,2),16);
    const brightness = (r*299 + g*587 + b*114) / 1000;

    input.style.color = brightness > 150 ? '#000' : '#fff';
}

// beim Laden
updateColor(input.value);

// Picker → Input
picker.addEventListener('input', () => {
    updateColor(picker.value);
});

// Input → Picker
input.addEventListener('input', () => {
    if(/^#([0-9A-F]{3}){1,2}$/i.test(input.value)){
        picker.value = input.value;
        updateColor(input.value);
    }
});
</script>

</body>
</html>