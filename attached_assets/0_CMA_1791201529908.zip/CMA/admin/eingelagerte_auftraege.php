<?php
require_once "../functions.php";

$filterSpedition = trim($_GET['spedition'] ?? '');
$filterRelation  = trim($_GET['relation'] ?? '');
$filterTermin    = trim($_GET['termin'] ?? '');
$filterSuche     = trim($_GET['suche'] ?? '');

$where = [];

if ($filterSpedition !== '') {
    $speditionEsc = mysqli_real_escape_string($dbhandle, $filterSpedition);
    $where[] = "spediteur_name1 = '{$speditionEsc}'";
}

if ($filterRelation !== '') {
    $relationEsc = mysqli_real_escape_string($dbhandle, $filterRelation);
    $where[] = "relation = '{$relationEsc}'";
}

if ($filterTermin !== '') {
    $terminEsc = mysqli_real_escape_string($dbhandle, $filterTermin);
    $where[] = "CONCAT(lfdat, ' + ', plus_kw) = '{$terminEsc}'";
}

if ($filterSuche !== '') {
    $sucheEsc = mysqli_real_escape_string($dbhandle, $filterSuche);
    $where[] = "
        (
            spediteur_name1 LIKE '%{$sucheEsc}%'
            OR relation LIKE '%{$sucheEsc}%'
            OR kunde_name1 LIKE '%{$sucheEsc}%'
            OR debitor LIKE '%{$sucheEsc}%'
            OR beleg LIKE '%{$sucheEsc}%'
            OR handling_unit LIKE '%{$sucheEsc}%'
            OR platz LIKE '%{$sucheEsc}%'
        )
    ";
}

$whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$speditionRes = mysqli_query($dbhandle, "
    SELECT DISTINCT spediteur_name1
    FROM eingelagerte_auftraege
    WHERE spediteur_name1 <> ''
    ORDER BY spediteur_name1 ASC
");

$relationRes = mysqli_query($dbhandle, "
    SELECT DISTINCT relation
    FROM eingelagerte_auftraege
    WHERE relation <> ''
    ORDER BY relation ASC
");

$terminRes = mysqli_query($dbhandle, "
    SELECT DISTINCT CONCAT(lfdat, ' + ', plus_kw) AS termin_anzeige
    FROM eingelagerte_auftraege
    WHERE lfdat <> ''
    ORDER BY lfdat ASC, plus_kw ASC
");

$kpiRes = mysqli_query($dbhandle, "
    SELECT
        COUNT(*) AS paletten,
        COUNT(DISTINCT spediteur_name1) AS speditionen,
        COUNT(DISTINCT relation) AS relationen,
        COUNT(DISTINCT CONCAT(lfdat, '-', plus_kw)) AS termine
    FROM eingelagerte_auftraege
    {$whereSql}
");

$kpi = mysqli_fetch_assoc($kpiRes);

$res = mysqli_query($dbhandle, "
    SELECT
        spediteur_name1,
        relation,
        lfdat,
        plus_kw,
        COUNT(*) AS paletten
    FROM eingelagerte_auftraege
    {$whereSql}
    GROUP BY spediteur_name1, relation, lfdat, plus_kw
    ORDER BY spediteur_name1 ASC, relation ASC, lfdat ASC, plus_kw ASC
");
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Eingelagerte Aufträge</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../assets/app.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
body {
    background: #f3f5f8;
}

.lager-page {
    max-width: none;
    padding: 22px;
}

.lager-toolbar {
    background: #ffffff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
    margin-bottom: 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.filter-group label {
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.filter-group select,
.filter-group input {
    min-width: 190px;
    padding: 11px 13px;
    border: 1px solid #d8dee8;
    border-radius: 12px;
    background: #f8fafc;
    font-size: 14px;
    outline: none;
}

.filter-group input {
    min-width: 280px;
}

.filter-group select:focus,
.filter-group input:focus {
    border-color: #64748b;
    background: #fff;
}

.filter-actions button {
    border: 0;
    background: #111827;
    color: #fff;
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 700;
    cursor: pointer;
}

.kpi-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(160px, 1fr));
    gap: 14px;
    margin-bottom: 18px;
}

.kpi-card {
    background: #fff;
    border-radius: 18px;
    padding: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.kpi-label {
    font-size: 12px;
    font-weight: 800;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.kpi-value {
    font-size: 30px;
    font-weight: 900;
    color: #111827;
    margin-top: 6px;
}

.grid-shell {
    background: #fff;
    border-radius: 20px;
    padding: 14px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .08);
}

.grid-wrap {
    max-height: calc(100vh - 320px);
    overflow: auto;
    border-radius: 14px;
    border: 1px solid #e5e7eb;
}

.order-table {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
    min-width: 1100px;
    font-size: 13px;
}

.order-table thead th {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #111827;
    color: #fff;
    padding: 13px 12px;
    text-align: left;
    font-size: 13px;
    letter-spacing: .04em;
}

.order-table tbody td {
    border-bottom: 1px solid #e5e7eb;
    padding: 13px 12px;
    background: #fff;
    vertical-align: middle;
}

.order-table tbody tr {
    cursor: pointer;
    transition: .15s ease;
}

.order-table tbody tr:hover td {
    background: #f8fafc;
}

.spedition-name {
    font-weight: 900;
    color: #111827;
}

.badge-relation {
    display: inline-block;
    background: #e0f2fe;
    color: #075985;
    padding: 5px 9px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 800;
}

.badge-paletten {
    display: inline-block;
    background: #111827;
    color: #fff;
    padding: 6px 11px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 900;
}

.termin-box {
    font-weight: 800;
    color: #334155;
}

.empty-state {
    padding: 28px;
    text-align: center;
    color: #64748b;
    font-weight: 700;
}

/* Modal */
.modal-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.65);
    backdrop-filter: blur(4px);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
}

.modal {
    width: 100%;
    max-width: 1000px;
    max-height: 90vh;
    background: #ffffff;
    border-radius: 18px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.25);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.modal-header {
    padding: 18px 20px;
    background: #111827;
    color: #fff;
    font-size: 18px;
    font-weight: 700;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-close {
    background: rgba(255,255,255,0.15);
    border: 0;
    color: #fff;
    padding: 8px 10px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
}

.modal-body {
    padding: 20px;
    overflow-y: auto;
}

.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
}

.modal-btn {
    background: #111827;
    color: #fff;
    border: 0;
    padding: 10px 14px;
    border-radius: 10px;
    font-weight: bold;
    cursor: pointer;
}

@media (max-width: 900px) {
    .kpi-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .filter-group,
    .filter-group select,
    .filter-group input {
        width: 100%;
        min-width: 100%;
    }
}
</style>
</head>

<body>

<div class="admin-wrapper lager-page">

    <div class="admin-header">
        <h1>Eingelagerte Aufträge</h1>
        <a href="index.php" class="admin-back">Zurück</a>
    </div>

    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-label">Paletten</div>
            <div class="kpi-value"><?= (int)($kpi['paletten'] ?? 0) ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Speditionen</div>
            <div class="kpi-value"><?= (int)($kpi['speditionen'] ?? 0) ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Relationen</div>
            <div class="kpi-value"><?= (int)($kpi['relationen'] ?? 0) ?></div>
        </div>

        <div class="kpi-card">
            <div class="kpi-label">Liefertermine</div>
            <div class="kpi-value"><?= (int)($kpi['termine'] ?? 0) ?></div>
        </div>
    </div>

    <div class="lager-toolbar">

        <div class="filter-group">
            <label>Spedition</label>
            <select id="filterSpedition" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($sp = mysqli_fetch_assoc($speditionRes)): ?>
                    <option value="<?= e($sp['spediteur_name1']) ?>" <?= $filterSpedition === $sp['spediteur_name1'] ? 'selected' : '' ?>>
                        <?= e($sp['spediteur_name1']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Leitgebiet</label>
            <select id="filterRelation" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($rel = mysqli_fetch_assoc($relationRes)): ?>
                    <option value="<?= e($rel['relation']) ?>" <?= $filterRelation === $rel['relation'] ? 'selected' : '' ?>>
                        <?= e($rel['relation']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Liefertermin / +KW</label>
            <select id="filterTermin" onchange="applyFilter()">
                <option value="">Alle</option>
                <?php while ($te = mysqli_fetch_assoc($terminRes)): ?>
                    <option value="<?= e($te['termin_anzeige']) ?>" <?= $filterTermin === $te['termin_anzeige'] ? 'selected' : '' ?>>
                        <?= e($te['termin_anzeige']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="filter-group">
            <label>Suche</label>
            <input 
                type="text"
                id="filterSuche"
                value="<?= e($filterSuche) ?>"
                placeholder="Spedition, Kunde, HU, Beleg, Platz..."
                oninput="applyFilterDelayed()"
            >
        </div>

        <div class="filter-actions">
            <button onclick="resetFilter()">Reset</button>
        </div>

    </div>

    <div class="grid-shell">
        <div class="grid-wrap">
            <table class="order-table">
                <thead>
                    <tr>
                        <th>Spedition</th>
                        <th>Leitgebiet / Relation</th>
                        <th>Liefertermin</th>
                        <th>+KW</th>
                        <th style="text-align:right;">Anzahl Paletten</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($res && mysqli_num_rows($res) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($res)): ?>
                            <tr onclick="openDetails(
                                '<?= e($row['spediteur_name1']) ?>',
                                '<?= e($row['relation']) ?>',
                                '<?= e($row['lfdat']) ?>',
                                '<?= e($row['plus_kw']) ?>'
                            )">
                                <td>
                                    <div class="spedition-name"><?= e($row['spediteur_name1']) ?></div>
                                </td>
                                <td>
                                    <span class="badge-relation"><?= e($row['relation']) ?></span>
                                </td>
                                <td>
                                    <div class="termin-box"><?= e($row['lfdat']) ?></div>
                                </td>
                                <td>
                                    <?= e($row['plus_kw']) ?>
                                </td>
                                <td style="text-align:right;">
                                    <span class="badge-paletten"><?= (int)$row['paletten'] ?> Pal.</span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    Keine eingelagerten Aufträge gefunden.
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<div class="modal-backdrop" id="modal">
    <div class="modal">

        <div class="modal-header">
            <span id="modalTitle">Auftragsdetails</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>

        <div class="modal-body" id="modalContent">
            Lade...
        </div>

        <div class="modal-footer">
            <button class="modal-btn" onclick="closeModal()">Schließen</button>
        </div>

    </div>
</div>

<script>
toastr.options = {
    closeButton: true,
    progressBar: true,
    positionClass: "toast-top-right",
    timeOut: "3000",
    extendedTimeOut: "1000",
    preventDuplicates: true
};

let filterTimer = null;

function applyFilterDelayed() {
    clearTimeout(filterTimer);
    filterTimer = setTimeout(applyFilter, 500);
}

function applyFilter() {
    const spedition = document.getElementById('filterSpedition').value;
    const relation  = document.getElementById('filterRelation').value;
    const termin    = document.getElementById('filterTermin').value;
    const suche     = document.getElementById('filterSuche').value.trim();

    const url = new URL(window.location.href);

    url.searchParams.set('spedition', spedition);
    url.searchParams.set('relation', relation);
    url.searchParams.set('termin', termin);
    url.searchParams.set('suche', suche);

    if (!spedition) url.searchParams.delete('spedition');
    if (!relation) url.searchParams.delete('relation');
    if (!termin) url.searchParams.delete('termin');
    if (!suche) url.searchParams.delete('suche');

    window.location.href = url.toString();
}

function resetFilter() {
    window.location.href = "eingelagerte_auftraege.php";
}

function openDetails(spedition, relation, lfdat, plus_kw) {
    document.getElementById('modal').style.display = 'flex';
    document.getElementById('modalContent').innerHTML = 'Lade...';
    document.getElementById('modalTitle').innerText = 'Auftragsdetails';

    const params = new URLSearchParams();
    params.set('spedition', spedition);
    params.set('relation', relation);
    params.set('lfdat', lfdat);
    params.set('plus_kw', plus_kw);

    fetch('ajax_eingelagerte_details.php?' + params.toString())
        .then(r => r.text())
        .then(html => {
            document.getElementById('modalContent').innerHTML = html;
        })
        .catch(() => {
            toastr.error('Details konnten nicht geladen werden.');
        });
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

document.getElementById('modal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});
</script>

</body>
</html>