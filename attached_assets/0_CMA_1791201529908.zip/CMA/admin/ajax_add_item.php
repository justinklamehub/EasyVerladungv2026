<?php
require_once "../functions.php";

header('Content-Type: application/json; charset=utf-8');

$regalId = (int)($_POST['regal_id'] ?? 0);
$artikelnummer = trim($_POST['artikelnummer'] ?? '');
$prioritaet = (int)($_POST['prioritaet'] ?? 1);
$kundengruppeId = ($_POST['kundengruppe_id'] ?? '') !== '' ? (int)$_POST['kundengruppe_id'] : null;
$hinweis = trim($_POST['hinweis'] ?? '');

if ($regalId <= 0 || $artikelnummer === '') {
    echo json_encode([
        "ok" => false,
        "message" => "Regal oder Artikel fehlt."
    ]);
    exit;
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT id 
    FROM artikel 
    WHERE artikelnummer = ? OR ean = ?
    LIMIT 1
");
mysqli_stmt_bind_param($stmt, "ss", $artikelnummer, $artikelnummer);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$artikel = mysqli_fetch_assoc($res);

if (!$artikel) {
    $stmt = mysqli_prepare($dbhandle, "
        INSERT INTO artikel (artikelnummer, aktiv)
        VALUES (?, 1)
    ");
    mysqli_stmt_bind_param($stmt, "s", $artikelnummer);
    mysqli_stmt_execute($stmt);

    $artikelId = mysqli_insert_id($dbhandle);
} else {
    $artikelId = (int)$artikel['id'];
}

$stmt = mysqli_prepare($dbhandle, "
    SELECT id 
    FROM einlagerung_zuordnung
    WHERE artikel_id = ?
      AND regal_id = ?
      AND aktiv = 1
    LIMIT 1
");
mysqli_stmt_bind_param($stmt, "ii", $artikelId, $regalId);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if (mysqli_fetch_assoc($res)) {
    echo json_encode([
        "ok" => false,
        "message" => "Dieser Artikel ist diesem Regal bereits zugeordnet."
    ]);
    exit;
}

$now = time();

$stmt = mysqli_prepare($dbhandle, "
    INSERT INTO einlagerung_zuordnung
        (artikel_id, regal_id, kundengruppe_id, prioritaet, hinweis, aktiv, created_at, updated_at)
    VALUES
        (?, ?, ?, ?, ?, 1, ?, ?)
");

mysqli_stmt_bind_param(
    $stmt,
    "iiiisii",
    $artikelId,
    $regalId,
    $kundengruppeId,
    $prioritaet,
    $hinweis,
    $now,
    $now
);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode([
        "ok" => false,
        "message" => "Fehler beim Speichern."
    ]);
    exit;
}

echo json_encode([
    "ok" => true
]);