<?php
require_once "../functions.php";

$id = (int)($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$farbe = trim($_POST['farbe'] ?? '#dddddd');

if ($name === '') {
    header("Location: kundengruppen.php");
    exit;
}

if ($id > 0) {
    $stmt = mysqli_prepare($dbhandle, "
        UPDATE kundengruppen
        SET name = ?, farbe = ?
        WHERE id = ?
    ");
    mysqli_stmt_bind_param($stmt, "ssi", $name, $farbe, $id);
    mysqli_stmt_execute($stmt);
} else {
    $stmt = mysqli_prepare($dbhandle, "
        INSERT INTO kundengruppen (name, farbe)
        VALUES (?, ?)
    ");
    mysqli_stmt_bind_param($stmt, "ss", $name, $farbe);
    mysqli_stmt_execute($stmt);
}

header("Location: kundengruppen.php");
exit;