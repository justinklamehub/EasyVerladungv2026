<?php include("../functions.php"); ?>

<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>MDE Scan</title>
  <style>
    body { font-family: system-ui, Arial; margin: 12px; }
    .card { border: 1px solid #ddd; border-radius: 12px; padding: 12px; margin-bottom: 12px; }
    .row { display:flex; gap:10px; align-items:center; }
    input { font-size: 18px; padding: 10px; width: 100%; border:1px solid #ccc; border-radius:10px; }
    button { font-size: 18px; padding: 10px 14px; border-radius:10px; border:1px solid #ccc; background:#f7f7f7; }
    button:active { transform: scale(0.99); }
    .muted { opacity: .75; }
    .ok { color: #0a7; }
    .err { color: #c00; }
    table { width:100%; border-collapse: collapse; }
    th, td { border-bottom: 1px solid #eee; padding: 8px; text-align:left; font-size: 14px; }
    .pill { display:inline-block; padding:4px 10px; border:1px solid #ddd; border-radius:999px; font-size: 13px; }
    .right { margin-left:auto; }
    .grid { display:grid; gap:10px; }
  </style>
</head>
<body>

<div class="card">
  <div class="row">
    <b>MDE Scan</b>
    <button class="pill" id="modeBadge" onclick="openModeModal()">
        Modus: Werksverkauf
    </button>
    <span class="pill right" id="deviceBadge">Device: …</span>
  </div>
</div>

<!-- MODE OVERLAY -->
<div id="modeOverlay" style="
  position:fixed; inset:0; background:rgba(0,0,0,.55);
  display:flex; align-items:center; justify-content:center; z-index:9999;">
  <div style="background:#fff; padding:16px; border-radius:14px; width:min(520px, 92vw); border:1px solid #ddd;">
    <div style="font-weight:700; font-size:18px;">Bitte Vorgang auswählen</div>

    <div style="display:flex; gap:10px; margin-top:14px;">
      <button type="button" id="btnWerks" style="flex:1; border:2px solid #0a7; background:#eafff6;">Werksverkauf</button>
      <button type="button" id="btnVern" style="flex:1;">Vernichtung</button>
    
      <div style="margin-top:12px;">
        <label style="display:flex; align-items:center;">
            <input type="checkbox" id="chkKundeNetto">
            Netto
        </label>

        <label style="display:flex; align-items:center;">
            <input type="checkbox" id="chkKware" checked>
            K-Ware
        </label>
    </div>
    </div>

    <div style="display:flex; gap:10px; margin-top:14px;">
      <button type="button" id="btnModeOk" style="flex:1;">Starten</button>
    </div>
  </div>
</div>

<!-- SCAN -->
<div class="card">
  <div class="grid">
    <div>
      <div class="muted">Scan-Feld</div>
      <div class="row">
        <input id="scanInput" type="text" inputmode="numeric" placeholder="Artikelnummer / EAN / VE-EAN scannen" autofocus />
        <button id="btnClear" type="button">X</button>
      </div>
    </div>

    <div id="status" class="muted">Bitte Vorgang auswählen…</div>
  </div>
</div>

<!-- STEP -->
<div class="card" id="stepCard" style="display:none;">
  <div class="row">
    <b id="artName">–</b>
    <span class="pill right" id="unitPill">–</span>
  </div>
  <div class="muted" id="artMeta" style="margin-top:6px;"></div>

  <div style="margin-top:12px;">
    <div class="muted">Menge</div>
    <div class="row">
      <input id="qtyInput" inputmode="decimal" placeholder="Menge eingeben" />
      <button id="btnAdd" type="button">OK</button>
    </div>
  </div>
</div>

<!-- LIST -->
<div class="card">
  <div class="row">
    <b>Liste</b>
    <button id="btnRefresh" type="button" class="right">Aktualisieren</button>
    <button id="btnFinish" type="button">Abschließen</button>
  </div>
  <div id="listWrap" style="margin-top:10px;"></div>
</div>


<script>

function openModeModal() {
    document.getElementById('modeOverlay').style.display = 'flex';
}

(() => {
  const apiUrl = 'api/mde.php';

  // DOM
  const elScan   = document.getElementById('scanInput');
  const elQty    = document.getElementById('qtyInput');
  const elStep   = document.getElementById('stepCard');
  const elStatus = document.getElementById('status');
  const elList   = document.getElementById('listWrap');
  const ov       = document.getElementById('modeOverlay');

  // State
  let current = null;             // aktueller Lookup-Artikel
  let currentMode = 'WERKSVERKAUF'; // priorisiert
  let scanTimer = null;
  let isBusy = false;             // verhindert Doppel-Submit
  let currentKundeNetto = 0;
  let currentWare = 0;

  // Helpers
  function nowModeText() {
    return (currentMode === 'VERNICHTUNG') ? 'Vernichtung' : 'Werksverkauf';
  }

  function nowWareMode() {
    return (currentWare === 1) ? 'K-Ware' : 'Retoure';
  }

  function setStatus(msg, type='') {
    elStatus.className = type === 'err' ? 'err' : (type === 'ok' ? 'ok' : 'muted');
    elStatus.textContent = msg;
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }
  function normalizeCode(code) {
    return String(code || '').trim().replace(/\s+/g, '');
  }
  function isEan(code) {
    const c = normalizeCode(code);
    return /^[0-9]{8}$/.test(c) || /^[0-9]{12}$/.test(c) || /^[0-9]{13}$/.test(c) || /^[0-9]{14}$/.test(c);
  }
  function formatQty(val) {
    if (val === null || val === undefined) return '';
    const num = parseFloat(val);
    if (Number.isInteger(num)) return num.toString();
    return num.toLocaleString('de-DE', { minimumFractionDigits: 0, maximumFractionDigits: 3 });
  }

  function getDeviceId() {
    const key = "mde_device_id";
    let id = localStorage.getItem(key);
    if (!id) {
      id = (crypto?.randomUUID) ? crypto.randomUUID() : ('mde-' + Date.now() + '-' + Math.random().toString(16).slice(2));
      localStorage.setItem(key, id);
    }
    return id;
  }
  document.getElementById('deviceBadge').textContent = "Device: " + getDeviceId().slice(0,8);

  function updateModeBadge() {
    const extra = [];
    if (currentKundeNetto === 1) extra.push('Netto');
    if (currentWare === 1) extra.push('K-Ware');
    document.getElementById('modeBadge').textContent = 'Modus: ' + nowModeText() + (extra.length ? ' / ' + extra.join(' / ') : '');
  }

  function setModeUI() {
    const werks = document.getElementById('btnWerks');
    const vern  = document.getElementById('btnVern');
    if (currentMode === 'WERKSVERKAUF') {
      werks.style.border = '2px solid #0a7'; werks.style.background = '#eafff6';
      vern.style.border  = '1px solid #ccc'; vern.style.background  = '#f7f7f7';
    } else {
      vern.style.border  = '2px solid #0a7'; vern.style.background  = '#eafff6';
      werks.style.border = '1px solid #ccc'; werks.style.background = '#f7f7f7';
    }
  }

  async function post(action, data) {
    const form = new FormData();
    form.append('created_by', getDeviceId());
    form.append('mode', currentMode);
    form.append('kunde_netto', currentKundeNetto); // 👈 NEU
    form.append('kware', currentWare);
    Object.entries(data || {}).forEach(([k,v]) => form.append(k, v));
    const res = await fetch(`${apiUrl}?action=${action}`, { method:'POST', body: form });
    return await res.json();
  }

  async function refreshList() {
    const j = await post('list', {});
    if (!j.ok) { setStatus(j.msg || 'List-Fehler', 'err'); return; }

    const items = j.items || [];
    if (items.length === 0) {
      elList.innerHTML = '<div class="muted">Noch keine Positionen.</div>';
      return;
    }

    elList.innerHTML = `
      <table>
        <thead>
          <tr>
            <th>Artikel</th><th>Name</th><th>Einheit</th><th>Menge</th><th></th>
          </tr>
        </thead>
        <tbody>
          ${items.map(it => `
            <tr>
              <td>${escapeHtml(it.artikelnummer)}</td>
              <td>${escapeHtml(it.artikelname)}</td>
              <td>${escapeHtml(it.einheit)}</td>
              <td>${formatQty(it.qty_input)}</td>
              <td><button type="button" onclick="deleteItem(${it.id})">🗑️</button></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  async function deleteItem(id) {
    if (!confirm('Position wirklich löschen?')) return;
    setStatus('Lösche Position…');

    const j = await post('delete_item', { item_id: id });
    if (!j.ok) { setStatus(j.msg || 'Löschen fehlgeschlagen.', 'err'); return; }

    await refreshList();
    setStatus('Position gelöscht.', 'ok');
    elScan.focus();
  }
  // inline onclick braucht global
  window.deleteItem = deleteItem;

  async function doLookup(rawCode) {
    const code = normalizeCode(rawCode);
    if (!code) return;

    // overlay offen? dann nicht scannen
    if (ov && ov.style.display !== 'none') return;

    if (isBusy) return;
    isBusy = true;

    try {
      setStatus('Suche Artikel…');
      const j = await post('lookup', { code });

      if (!j.ok || !j.found) {
        current = null;
        elStep.style.display = 'none';
        setStatus(j.msg || 'Artikel nicht gefunden.', 'err');
        elScan.select();
        return;
      }

      current = j.data;

      // ✅ Automatismus: EAN -> Menge 1 -> direkt speichern
      if (isEan(code)) {
        elStep.style.display = 'none';
        setStatus('EAN erkannt: Menge = 1 wird gespeichert…');

        const add = await post('add_item', {
          artikelnummer: current.artikelnummer,
          artikelname: current.artikelname,
          scanned_code: current.scanned_code,
          einheit: current.einheit,
          ve_faktor: current.ve_faktor,
          qty_input: 1
        });

        if (!add.ok) {
          setStatus(add.msg || 'Fehler beim Speichern.', 'err');
          current = null;
          elScan.select();
          return;
        }

        await refreshList();
        setStatus('Gespeichert. Nächsten Artikel scannen.', 'ok');
        current = null;
        elScan.value = '';
        elScan.focus();
        return;
      }

      // normaler Flow: Menge abfragen
      document.getElementById('artName').textContent =
        `${current.artikelnummer} – ${current.artikelname}`;

      document.getElementById('unitPill').textContent =
        `Einheit: ${current.einheit}`;

      document.getElementById('artMeta').textContent =
        `Code: ${current.scanned_code} | VE/Inhalt: ${current.ve_faktor}`;

      elStep.style.display = 'block';
      setStatus('Menge eingeben und OK drücken.', 'ok');
      elQty.value = '';
      elQty.focus();

    } finally {
      isBusy = false;
    }
  }

  async function addCurrent() {
    if (!current) return;

    const qty = parseFloat(String(elQty.value).replace(',', '.'));
    if (!qty || qty <= 0) {
      setStatus('Bitte gültige Menge eingeben.', 'err');
      elQty.focus();
      return;
    }

    setStatus('Speichere Position…');
    const j = await post('add_item', {
      artikelnummer: current.artikelnummer,
      artikelname: current.artikelname,
      scanned_code: current.scanned_code,
      einheit: current.einheit,
      ve_faktor: current.ve_faktor,
      qty_input: qty
    });

    if (!j.ok) {
      setStatus(j.msg || 'Fehler beim Speichern.', 'err');
      return;
    }

    await refreshList();
    setStatus('Gespeichert. Nächsten Artikel scannen.', 'ok');

    current = null;
    elStep.style.display = 'none';
    elScan.value = '';
    elScan.focus();
  }

  function openModeOverlay() {
    current = null;
    elStep.style.display = 'none';
    elScan.value = '';
    elQty.value = '';

    currentMode = 'WERKSVERKAUF'; // priorisiert
    currentKundeNetto = 0;
    currentWare = 0;
    document.getElementById('chkKundeNetto').checked = false;
    document.getElementById('chkKware').checked = false;
    setModeUI();
    updateModeBadge();

    if (ov) ov.style.display = 'flex';
    setStatus('Bitte Vorgang auswählen…', '');
  }

  // ---------- Scan Trigger (robust für Zebra + Copy/Paste) ----------
  function triggerScanSubmit() {
    const code = normalizeCode(elScan.value);
    if (!code) return;
    doLookup(code);
  }

  // input-debounce: funktioniert auch wenn Scanner KEIN Enter sendet
  let lastInputAt = 0;
let firstInputAt = 0;
let inputChars = 0;
let pasteTriggered = false;

elScan.addEventListener('paste', () => {
  pasteTriggered = true;
});

elScan.addEventListener('input', () => {
  const now = Date.now();
  const value = normalizeCode(elScan.value);

  // Reset, wenn Feld leer
  if (!value) {
    firstInputAt = 0;
    inputChars = 0;
    pasteTriggered = false;
    return;
  }

  // Timing-Fenster starten
  if (!firstInputAt) firstInputAt = now;

  // Zeichen zählen (heuristisch)
  inputChars = value.length;
  lastInputAt = now;

  // Scanner/Paste Heuristik:
  // - Paste: immer auto
  // - "scan-schnell": z.B. >= 6 Zeichen innerhalb von <= 300ms
  const duration = now - firstInputAt;
  const looksLikeScan = (inputChars >= 6 && duration <= 300);

  if (scanTimer) clearTimeout(scanTimer);

  if (pasteTriggered || looksLikeScan) {
    scanTimer = setTimeout(() => {
      pasteTriggered = false;
      firstInputAt = 0;
      inputChars = 0;
      triggerScanSubmit();
    }, 80); // kurze Ruhephase
  } else {
    // Manuelles Tippen: KEIN Auto-Submit
    // -> nur ENTER soll auslösen
  }
});

  // Enter-Fallback
  elScan.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    if (scanTimer) clearTimeout(scanTimer);

    // Reset Heuristik, damit danach sauber weitergeht
    firstInputAt = 0;
    inputChars = 0;
    pasteTriggered = false;

    triggerScanSubmit();
  }
});

  // ---------- Buttons / Events ----------
  document.getElementById('btnWerks').addEventListener('click', () => {
    currentMode = 'WERKSVERKAUF';
    setModeUI();
    updateModeBadge();
  });
  document.getElementById('btnVern').addEventListener('click', () => {
    currentMode = 'VERNICHTUNG';
    setModeUI();
    updateModeBadge();
  });

  document.getElementById('btnModeOk').addEventListener('click', async () => {
    if (ov) ov.style.display = 'none';

    currentKundeNetto = document.getElementById('chkKundeNetto').checked ? 1 : 0;
    currentWare = document.getElementById('chkKware').checked ? 1 : 0;

    updateModeBadge();
    setStatus(`Modus: ${nowModeText()}${currentKundeNetto ? ' / Netto' : ''}${currentWare ? ' / K-Ware' : ''}. Bereit zum Scannen.`, 'ok');
    await refreshList();
    elScan.focus();
  });

  document.getElementById('btnAdd').addEventListener('click', addCurrent);
  document.getElementById('btnRefresh').addEventListener('click', refreshList);

  document.getElementById('btnClear').addEventListener('click', () => {
    elScan.value = '';
    elScan.focus();
  });

  document.getElementById('btnFinish').addEventListener('click', async () => {
    if (!confirm('Liste abschließen und dem Lagerleitstand schicken?')) return;

    setStatus('Schließe Liste ab…');
    const j = await post('finalize', {});
    if (!j.ok) { setStatus(j.msg || 'Konnte nicht abschließen.', 'err'); return; }

    // UI wieder auf Modus-Auswahl, ohne direkt eine neue leere Session anzulegen
    elList.innerHTML = '<div class="muted">Noch keine Positionen.</div>';
    setStatus(`Abgeschlossen (Session #${j.session_id}).`, 'ok');
    openModeOverlay();
  });

  // Menge Enter = Add
  elQty.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addCurrent();
    }
  });

  // Initial UI
  setModeUI();
  updateModeBadge();
  // absichtlich KEIN refreshList() beim Laden -> erst nach "Starten"
  openModeOverlay();
})();
</script>

</body>
</html>
