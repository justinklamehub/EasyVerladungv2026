<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$user = 'ni1033076_4sql1';
$pass = 'Comet2018';

$mysqli = new mysqli($host, $user, $pass, "wvvn");
if ($mysqli->connect_error) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'msg' => 'DB Verbindung fehlgeschlagen: ' . $mysqli->connect_error]);
  exit;
}
$mysqli->set_charset('utf8mb4');

function send_csv_mail(string $to, string $from, string $subject, string $bodyText, string $filename, string $csv): bool {
  $boundary = "=_MDE_" . md5((string)microtime(true));

  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "From: {$from}\r\n";
  $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"\r\n";

  $message  = "--{$boundary}\r\n";
  $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
  $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
  $message .= $bodyText . "\r\n";

  $message .= "--{$boundary}\r\n";
  $message .= "Content-Type: text/csv; name=\"{$filename}\"\r\n";
  $message .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n";
  $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
  $message .= chunk_split(base64_encode($csv)) . "\r\n";
  $message .= "--{$boundary}--";

  return @mail($to, $subject, $message, $headers);
}

function build_csv(array $rows): string {
    $fmt = function($v) {
      $s = rtrim(rtrim(number_format((float)$v, 3, ',', ''), '0'), ',');
      return $s === '' ? '0' : $s;
    };
  
    $csv = "\xEF\xBB\xBF";
    $csv .= "Artikelnummer;Artikelname;Netto;K-Ware;Menge;Charge\n";
  
    foreach ($rows as $r) {
      $artikelnummer = str_replace(';', ',', $r['artikelnummer']);
      $artikelname   = str_replace(["\r","\n",";"], [' ',' ',','], $r['artikelname']);
      $kundeNettoTxt = ((int)$r['kunde_netto'] === 1) ? 'Ja' : 'Nein';
      $kWare = ((int)$r['kware'] === 1) ? 'Ja' : 'Nein';
  
      $csv .= $artikelnummer . ';'
           . $artikelname . ';'
           . $kundeNettoTxt . ';'
           . $kWare . ';'
           . $fmt($r['qty_stk_sum']) . ';'
           . 'ALLE;' .
           "\n";
    }
  
    return $csv;
  }

// --- Tagesgrenzen (Server-Zeitzone!) ---
$dayStart = strtotime('today 00:00:00');
$dayEnd   = strtotime('tomorrow 00:00:00');
$reportDate = date('Y-m-d', $dayStart);

$toWerks = "LFEGERCometLagerleitstand@comet-seasonal.de"; // anpassen
$toVern  = "LFEGERCometLagerleitstand@comet-seasonal.de"; // anpassen
$from    = "WVVN@comet-seasonal.de";

// pro Modus 1 Mail
$modes = [
  'WERKSVERKAUF' => $toWerks,
  'VERNICHTUNG'  => $toVern
];

foreach ($modes as $mode => $to) {

    // Laufnummer ermitteln (pro Tag + Modus)
    $stmtNo = $mysqli->prepare("
    SELECT MAX(running_no) AS max_no
    FROM mde_daily_reports
    WHERE mode=?
    ");
    $stmtNo->bind_param("s", $mode);
    $stmtNo->execute();
    $resNo = $stmtNo->get_result();
    $rowNo = $resNo ? $resNo->fetch_assoc() : null;

    $runningNo = ($rowNo && $rowNo['max_no'])
    ? ((int)$rowNo['max_no'] + 1)
    : 1;

  // schon gesendet?
  $stmtCheck = $mysqli->prepare("SELECT id FROM mde_daily_reports WHERE report_date=? AND mode=? LIMIT 1");
  $stmtCheck->bind_param("ss", $reportDate, $mode);
  $stmtCheck->execute();
  $resCheck = $stmtCheck->get_result();
  if ($resCheck && $resCheck->fetch_assoc()) {
    echo "Already sent: {$reportDate} {$mode}\n";
    continue;
  }

  // Aggregation über alle Sessions des Tages (status done + finished_at in Zeitraum)
  $sql = "
  SELECT
    i.artikelnummer,
    i.artikelname,
    s.kunde_netto,
    s.kware,
    SUM(i.qty_stk) AS qty_stk_sum
  FROM mde_session_items i
  JOIN mde_sessions s ON s.id = i.session_id
  WHERE s.status='done'
    AND s.mode=?
    AND s.finished_at IS NOT NULL
    AND s.finished_at >= ?
    AND s.finished_at < ?
  GROUP BY i.artikelnummer, i.artikelname, s.kunde_netto
  ORDER BY i.artikelnummer ASC, s.kunde_netto ASC
";

  $stmt = $mysqli->prepare($sql);
  $stmt->bind_param("sii", $mode, $dayStart, $dayEnd);
  $stmt->execute();
  $res = $stmt->get_result();

  $rows = [];
  if ($res) while ($r = $res->fetch_assoc()) $rows[] = $r;

  if (!$rows) {
    echo "No rows for {$reportDate} {$mode}\n";
    // trotzdem loggen? meist NEIN. Ich lasse es weg.
    continue;
  }

  $csv = build_csv($rows);

    $filename = "{$mode}_{$reportDate}_Nr{$runningNo}.csv";
    $subject  = "{$mode} ({$reportDate}) Nr. {$runningNo}";
  $body = "Hallo,\n\nanbei der MDE Tagesreport ({$mode}) für {$reportDate}.\n"
        . "Zusammengefasst über alle abgeschlossenen Listen bis 16:00 Uhr.\n\n"
        . "Viele Grüße\nMDE System\n";

  $ok = send_csv_mail($to, $from, $subject, $body, $filename, $csv);

  if ($ok) {
    $sentAt = time();
    $stmtIns = $mysqli->prepare("
  INSERT INTO mde_daily_reports (report_date, mode, running_no, sent_at)
  VALUES (?, ?, ?, ?)
");
$stmtIns->bind_param("ssii", $reportDate, $mode, $runningNo, $sentAt);
    $stmtIns->execute();
    echo "Sent: {$reportDate} {$mode}\n";
  } else {
    echo "MAIL FAILED: {$reportDate} {$mode}\n";
  }
}