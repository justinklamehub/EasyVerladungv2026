<?php
header('Content-Type: application/json; charset=utf-8');

include("../../functions.php");

$mysqli = new mysqli($host, $user, $pass, "wvvn");
if ($mysqli->connect_error) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'msg' => 'DB Verbindung fehlgeschlagen: ' . $mysqli->connect_error]);
  exit;
}
$mysqli->set_charset('utf8mb4');

$action = $_GET['action'] ?? '';

function json_exit($arr, $code = 200) {
  http_response_code($code);
  echo json_encode($arr);
  exit;
}

function now_ts(): int {
  return time(); // UNIX Timestamp
}

/**
 * Offene Session holen oder erstellen.
 * Hinweis: aktuell "globale" offene Session. Für mehrere Geräte/User: created_by nutzen.
 */
function get_open_session_id(mysqli $mysqli, ?string $createdBy = null, string $mode = 'WERKSVERKAUF', int $kundeNetto = 0, int $kWare = 0): int {
    $createdBy = trim($createdBy ?? '');
    if ($createdBy === '') $createdBy = 'unknown';
  
    $mode = ($mode === 'VERNICHTUNG') ? 'VERNICHTUNG' : 'WERKSVERKAUF';
    $kundeNetto = ($kundeNetto === 1) ? 1 : 0;
    $kWare = ($kWare === 1) ? 1 : 0;
  
    $stmt = $mysqli->prepare("
      SELECT id
      FROM mde_sessions
      WHERE status='open'
        AND created_by=?
        AND mode=?
        AND kunde_netto=?
        AND kware=?
      ORDER BY id DESC
      LIMIT 1
    ");
    $stmt->bind_param("ssii", $createdBy, $mode, $kundeNetto, $kWare);
    $stmt->execute();
    $res = $stmt->get_result();
  
    if ($res && ($row = $res->fetch_assoc())) {
      return (int)$row['id'];
    }
  
    $stmt2 = $mysqli->prepare("
      INSERT INTO mde_sessions (created_at, created_by, mode, kunde_netto, kware, status)
      VALUES (?, ?, ?, ?, ?, 'open')
    ");
    $ca = time();
    $stmt2->bind_param("issii", $ca, $createdBy, $mode, $kundeNetto, $kWare);
    if (!$stmt2->execute()) {
      json_exit(['ok' => false, 'msg' => 'Session konnte nicht erstellt werden: ' . $stmt2->error], 500);
    }
  
    return (int)$mysqli->insert_id;
  }
  

// ---------- lookup ----------
if ($action === 'lookup') {
  $code = trim($_POST['code'] ?? '');
  if ($code === '') json_exit(['ok' => false, 'msg' => 'Kein Code übergeben.'], 400);

  // Spalten ggf. anpassen: artikelnummer, artikelname, ean, ve_ean, ve_faktor
  $sql = "
    SELECT artikelnummer, artikelname, ean, veean AS ve_ean, COALESCE(ve,1) AS ve_faktor
    FROM artikeldaten
    WHERE artikelnummer = ? OR ean = ? OR veean = ?
    LIMIT 1
  ";
  $stmt = $mysqli->prepare($sql);
  if (!$stmt) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);

  $stmt->bind_param("sss", $code, $code, $code);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res ? $res->fetch_assoc() : null;

  if (!$row) {
    json_exit(['ok' => true, 'found' => false, 'msg' => 'Artikel nicht gefunden.']);
  }

  $einheit = (!empty($row['ve_ean']) && $code === $row['ve_ean']) ? 'VE' : 'STK';

  json_exit([
    'ok' => true,
    'found' => true,
    'data' => [
      'artikelnummer' => $row['artikelnummer'],
      'artikelname'   => $row['artikelname'],
      'einheit'       => $einheit,
      've_faktor'     => (float)$row['ve_faktor'],
      'scanned_code'  => $code
    ]
  ]);
}

// ---------- add_item ----------
if ($action === 'add_item') {
  $createdBy = isset($_POST['created_by']) ? trim($_POST['created_by']) : null;
  $mode = isset($_POST['mode']) ? trim($_POST['mode']) : 'WERKSVERKAUF';
  $kundeNetto = isset($_POST['kunde_netto']) ? (int)$_POST['kunde_netto'] : 0;
  $kWare = isset($_POST['kware']) ? (int)$_POST['kware'] : 0;
  $sessionId = get_open_session_id($mysqli, $createdBy, $mode, $kundeNetto, $kWare);

  $artikelnummer = trim($_POST['artikelnummer'] ?? '');
  $artikelname   = trim($_POST['artikelname'] ?? '');
  $scannedCode   = trim($_POST['scanned_code'] ?? '');
  $einheit       = (($_POST['einheit'] ?? 'STK') === 'VE') ? 'VE' : 'STK';

  $qtyInput = (float)str_replace(',', '.', (string)($_POST['qty_input'] ?? '0'));
  $veFaktor = (float)str_replace(',', '.', (string)($_POST['ve_faktor'] ?? '1'));

  if ($artikelnummer === '' || $artikelname === '' || $scannedCode === '' || $qtyInput <= 0) {
    json_exit(['ok' => false, 'msg' => 'Ungültige Daten.'], 400);
  }
  if ($veFaktor <= 0) $veFaktor = 1;

  $qtyStk = ($einheit === 'VE') ? ($qtyInput * $veFaktor) : $qtyInput;

  $createdAt = now_ts();

  $sql = "
    INSERT INTO mde_session_items
      (session_id, scanned_code, artikelnummer, artikelname, einheit, qty_input, ve_faktor, qty_stk, created_at)
    VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ";
  $stmt = $mysqli->prepare($sql);
  if (!$stmt) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);

  // i s s s s d d d i
  $stmt->bind_param(
    "issssdddi",
    $sessionId,
    $scannedCode,
    $artikelnummer,
    $artikelname,
    $einheit,
    $qtyInput,
    $veFaktor,
    $qtyStk,
    $createdAt
  );

  if (!$stmt->execute()) {
    json_exit(['ok' => false, 'msg' => 'Insert fehlgeschlagen: ' . $stmt->error], 500);
  }

  json_exit(['ok' => true, 'session_id' => $sessionId, 'qty_stk' => $qtyStk]);
}

// ---------- list ----------
if ($action === 'list') {
  $createdBy = isset($_POST['created_by']) ? trim($_POST['created_by']) : null;
  $mode = isset($_POST['mode']) ? trim($_POST['mode']) : 'WERKSVERKAUF';
  $kundeNetto = isset($_POST['kunde_netto']) ? (int)$_POST['kunde_netto'] : 0;
  $kWare = isset($_POST['kware']) ? (int)$_POST['kware'] : 0;
  $sessionId = get_open_session_id($mysqli, $createdBy, $mode, $kundeNetto, $kWare);

  $sql = "
    SELECT id, artikelnummer, artikelname, einheit, qty_input, ve_faktor, qty_stk, created_at
    FROM mde_session_items
    WHERE session_id = ?
    ORDER BY id DESC
  ";
  $stmt = $mysqli->prepare($sql);
  if (!$stmt) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);

  $stmt->bind_param("i", $sessionId);
  $stmt->execute();
  $res = $stmt->get_result();

  $items = [];
  if ($res) {
    while ($row = $res->fetch_assoc()) $items[] = $row;
  }

  json_exit(['ok' => true, 'session_id' => $sessionId, 'items' => $items]);
}

// ---------- delete_item ----------
if ($action === 'delete_item') {
    $createdBy = isset($_POST['created_by']) ? trim($_POST['created_by']) : null;
    $mode = isset($_POST['mode']) ? trim($_POST['mode']) : 'WERKSVERKAUF';
    $kundeNetto = isset($_POST['kunde_netto']) ? (int)$_POST['kunde_netto'] : 0;
    $kWare = isset($_POST['kware']) ? (int)$_POST['kware'] : 0;
    $sessionId = get_open_session_id($mysqli, $createdBy, $mode, $kundeNetto, $kWare);
  
    $itemId = (int)($_POST['item_id'] ?? 0);
    if ($itemId <= 0) {
      json_exit(['ok' => false, 'msg' => 'Ungültige item_id.'], 400);
    }
  
    // Nur löschen, wenn Item zur aktuellen Session gehört
    $stmt = $mysqli->prepare("DELETE FROM mde_session_items WHERE id=? AND session_id=?");
    if (!$stmt) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);
  
    $stmt->bind_param("ii", $itemId, $sessionId);
  
    if (!$stmt->execute()) {
      json_exit(['ok' => false, 'msg' => 'Delete fehlgeschlagen: ' . $stmt->error], 500);
    }
  
    if ($stmt->affected_rows === 0) {
      json_exit(['ok' => false, 'msg' => 'Position nicht gefunden oder gehört nicht zur aktuellen Liste.'], 404);
    }
  
    json_exit(['ok' => true, 'msg' => 'Position gelöscht.']);
  }
  

// ---------- finalize ----------
// ---------- finalize (CSV + aggregierte Mengen) ----------
// if ($action === 'finalize') {
//     $createdBy = isset($_POST['created_by']) ? trim($_POST['created_by']) : null;
//     $mode = isset($_POST['mode']) ? trim($_POST['mode']) : 'WERKSVERKAUF';
//     $kundeNetto = isset($_POST['kunde_netto']) ? (int)$_POST['kunde_netto'] : 0;
//     $sessionId = get_open_session_id($mysqli, $createdBy, $mode, $kundeNetto);
  
//     $mode = ($mode === 'VERNICHTUNG') ? 'VERNICHTUNG' : 'WERKSVERKAUF';
  
//     // 1) Aggregierte Items holen
//     $sql = "
//       SELECT
//         artikelnummer,
//         artikelname,
//         einheit,
//         SUM(qty_input) AS qty_input_sum,
//         SUM(qty_stk)   AS qty_stk_sum
//       FROM mde_session_items
//       WHERE session_id = ?
//       GROUP BY artikelnummer, artikelname, einheit
//       ORDER BY artikelnummer ASC
//     ";
//     $stmt = $mysqli->prepare($sql);
//     if (!$stmt) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);
  
//     $stmt->bind_param("i", $sessionId);
//     $stmt->execute();
//     $res = $stmt->get_result();
  
//     $rows = [];
//     if ($res) while ($r = $res->fetch_assoc()) $rows[] = $r;
  
//     if (!$rows) json_exit(['ok' => false, 'msg' => 'Keine Positionen vorhanden.'], 400);
  
//     // 2) Session schließen
//     $finishedAt = time();
//     $stmt2 = $mysqli->prepare("UPDATE mde_sessions SET status='done', finished_at=? WHERE id=?");
//     if (!$stmt2) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);
//     $stmt2->bind_param("ii", $finishedAt, $sessionId);
//     $stmt2->execute();

//     $formatQty = function($v) {
//       // 12.000 -> 12 | 12.500 -> 12,5 (deutsche Darstellung optional)
//       $s = rtrim(rtrim(number_format((float)$v, 3, ',', ''), '0'), ',');
//       return $s === '' ? '0' : $s;
//     };
  
//     $csv = "\xEF\xBB\xBF"; // UTF-8 BOM für Excel
//     $csv .= "Artikelnummer;Artikelname;StueckGesamt;Charge\n";
//     foreach ($rows as $r) {
//       $csv .=
//         str_replace(';', ',', $r['artikelnummer']) . ';' .
//         str_replace(["\r","\n",";"], [' ',' ',','], $r['artikelname']) . ';' .
//         $formatQty($r['qty_input_sum']) . ';' .
//         'ALLE;' . "\n";
//     }
      
//     // 3) CSV bauen (Excel-freundlich: UTF-8 BOM + ; als Trenner)
//     $filename = "{$mode}_Lfd.Nr.:{$sessionId}_" . date('Ymd_His', $finishedAt) . ".csv";
  
//     // 4) Mail mit Attachment (ohne PHPMailer, via MIME Multipart)
//     $to = "LFEGERCometLagerleitstand@comet-seasonal.de"; // <-- anpassen
//     $subject = "$mode - Lfd. Nr.: $sessionId";
  
//     $bodyText =
//         "***** AUTOMATISCH GENERIERTE EMAIL *****\n\n" .
//       "Werksverkauf/Vernichtung abgeschlossen..\n" .
//       "Liste: {$mode}\n" .
//       "Lfd. Nr.: {$sessionId}\n" .
//       "Kunde Netto: " . ($kundeNetto ? 'Ja' : 'Nein') . "\n" .
//       "Zeit: " . date('d.m.Y H:i:s', $finishedAt) . "\n\n" .
//       "Die zusammengefasste CSV ist im Anhang.\n" .
//       "Ebenso wurde diese Datei automatisch wie folgt gespeichert:\n" .
//       "Werksverkauf: Lagerleitstand/Allgemein/Werksverkauf/Belege\n" .
//       "Vernichtung: Lagerleitstand/Allgemein/Vernichtung/Belege\n";
  
//     $boundary = "=_MDE_" . md5((string)microtime(true));
  
//     $headers  = "MIME-Version: 1.0\r\n";
//     $headers .= "From: WVVN@comet-seasonal.de\r\n";
//     $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"\r\n";
  
//     $message  = "--{$boundary}\r\n";
//     $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
//     $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
//     $message .= $bodyText . "\r\n";
  
//     $message .= "--{$boundary}\r\n";
//     $message .= "Content-Type: text/csv; name=\"{$filename}\"\r\n";
//     $message .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n";
//     $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
//     $message .= chunk_split(base64_encode($csv)) . "\r\n";
//     $message .= "--{$boundary}--";
  
//     @mail($to, $subject, $message, $headers);
  
//     json_exit([
//       'ok' => true,
//       'msg' => 'Abgeschlossen und CSV versendet.',
//       'session_id' => $sessionId
//     ]);
//   }

// ---------- finalize (ohne Mail) ----------
if ($action === 'finalize') {
    $createdBy = isset($_POST['created_by']) ? trim($_POST['created_by']) : null;
    $mode = isset($_POST['mode']) ? trim($_POST['mode']) : 'WERKSVERKAUF';
    $kundeNetto = isset($_POST['kunde_netto']) ? (int)$_POST['kunde_netto'] : 0;
    $kWare = isset($_POST['kware']) ? (int)$_POST['kware'] : 0;
  
    $sessionId = get_open_session_id($mysqli, $createdBy, $mode, $kundeNetto, $kWare);
  
    // Prüfen ob Items vorhanden
    $stmt = $mysqli->prepare("SELECT COUNT(*) AS c FROM mde_session_items WHERE session_id=?");
    $stmt->bind_param("i", $sessionId);
    $stmt->execute();
    $res = $stmt->get_result();
    $cnt = ($res && ($row = $res->fetch_assoc())) ? (int)$row['c'] : 0;
  
    if ($cnt <= 0) json_exit(['ok' => false, 'msg' => 'Keine Positionen vorhanden.'], 400);
  
    $finishedAt = time();
    $stmt2 = $mysqli->prepare("UPDATE mde_sessions SET status='done', finished_at=? WHERE id=?");
    if (!$stmt2) json_exit(['ok' => false, 'msg' => 'Prepare fehlgeschlagen: ' . $mysqli->error], 500);
    $stmt2->bind_param("ii", $finishedAt, $sessionId);
    if (!$stmt2->execute()) {
      json_exit(['ok' => false, 'msg' => 'Abschluss fehlgeschlagen: ' . $stmt2->error], 500);
    }
  
    json_exit(['ok' => true, 'msg' => 'Liste abgeschlossen.', 'session_id' => $sessionId]);
  }
  
json_exit(['ok' => false, 'msg' => 'Unknown action'], 404);