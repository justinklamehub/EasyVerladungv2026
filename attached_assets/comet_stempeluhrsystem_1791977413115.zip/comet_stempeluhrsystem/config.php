<?php 
// **************************************************************************
// DEBUG SYSTEMN
// **************************************************************************
$_CONF['modus'] = 'live'; // 'live' oder 'beta'
// **************************************************************************
// SQL-DATENABNK LOGIN
// **************************************************************************
if($_CONF['modus'] == 'beta')
{
    define('DB_NAME', 'ANU');
    define('DB_USER', 'root');
    define('DB_PASS', '0ctlI4dKpeNahlP9JS5eze9DETkufwxicxFxQqW4C0yuKx5dK8');
    define('DB_HOST', 'localhost');
}
else if($_CONF['modus'] == 'live')
{
    define('DB_NAME', 'ANU');
    define('DB_USER', 'root');
    define('DB_PASS', '0ctlI4dKpeNahlP9JS5eze9DETkufwxicxFxQqW4C0yuKx5dK8');
    define('DB_HOST', 'localhost');
}
// **************************************************************************
// SSH-USER LOGIN
// **************************************************************************
define('SSH_USER', 'root');
define('SSH_PASS', '893.Lucy.893');
define('SSH_PORT', 22);
define('SSH_HOST', 'localhost');