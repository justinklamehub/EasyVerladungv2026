<?php
session_set_cookie_params([
    'lifetime' => 0,           // Session-Cookie, läuft beim Browser-Schließen ab
    'path'     => '/',
    'domain'   => '',          // leer lassen = aktueller Host
    'secure'   => true,        // Cookie NUR über HTTPS senden
    'httponly' => true,        // Keine JS-Zugriffe (XSS-Schutz)
    'samesite' => 'Strict'     // Oder 'Lax', wenn du externe Redirect-Logins nutzt
]);
session_start();
// **************************************************************************
// INCLUDES
// **************************************************************************
include("config.php");
// **************************************************************************
// SETTINGS
// **************************************************************************
date_default_timezone_set('Europe/Berlin');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ERROR);

// **************************************************************************
// DATENBANK VERBIDNUNG AUFBAUEN
// **************************************************************************
$dbhandle =  new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$dbhandle->set_charset('utf8mb4')) 
{
    die('set_charset failed: '.$dbhandle->error);
}
// **************************************************************************
// FUNCTIONS
// **************************************************************************
$now = strtotime(date("d.m.Y H:i:s"));

function User($karte, $search)
{
    global $dbhandle, $now;
	$rs = mysqli_query($dbhandle, "SELECT * FROM `mitarbeiter` WHERE `mitarbeiterid`='$karte' LIMIT 1");
	$row =  mysqli_fetch_assoc($rs);
    return $row[$search];
}

function DisplayToast($art, $head, $msg, $time)
{
    if($art == "success") 
    {
        echo "<script>
            window.onload = (event) => {
                toastr.success('$msg', '$head', {timeOut: $time*1000, progressBar: true, showDuration: 300, hideDuration: 100})
              };
        </script>";
    }
    if($art == "error") 
    {
        echo "<script>
            window.onload = (event) => {
                toastr.error('$msg', '$head', {timeOut: $time*1000, progressBar: true, showDuration: 300, hideDuration: 100})
            };
        </script>";
    }
    if($art == "info") 
    {
        echo "<script>
            window.onload = (event) => {
                toastr.info('$msg', '$head', {timeOut: $time*1000, progressBar: true, showDuration: 300, hideDuration: 100})
            };
        </script>";
    }
    if($art == "warning") 
    {
        echo "<script>
            window.onload = (event) => {
                toastr.warning('$msg', '$head', {timeOut: $time*1000, progressBar: true, showDuration: 300, hideDuration: 100})
            };
        </script>";
    }

    ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php 
}