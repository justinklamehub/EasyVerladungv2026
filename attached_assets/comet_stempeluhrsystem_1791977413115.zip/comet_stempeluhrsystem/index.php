<script>
function playSound(type) {
    let audio;
    if (type === "success") {
        audio = new Audio("success.wav");
    } else if (type === "error") {
        audio = new Audio("error.wav");
    }
    audio.play();
}
</script>

<?php 
include('functions.php');

if(isset($_POST['enter']))
{
    $scan = $_POST['karte'];

    $query2 = mysqli_query($dbhandle, "SELECT * FROM `mitarbeiter` WHERE `mitarbeiterid`='$scan' LIMIT 1");
    $anzahl2 = mysqli_num_rows($query2);

    if($anzahl2 == 0)
    {
        DisplayToast("error", "Mitarbeiter nicht gefunden!", "ID $scan nicht gefunden!", 5);
        echo "<script>playSound('error');</script>";
    }
    else 
    {
        $query = mysqli_query($dbhandle, "SELECT * FROM `anwesenheit` WHERE `mitarbeiterid`='$scan' AND `time_begin`!='0' AND `time_end` IS NULL LIMIT 1");
        $anzahl = mysqli_num_rows($query);

        $vorname = User($scan, "vorname");
        $nachname = User($scan, "nachname");
        $mid = User($scan, "mitarbeiterid");

        if($anzahl == 0)
        {
            // Aktuelle Zeit
            $jetzt = time();

            // Heute 06:45 Uhr als Timestamp
            $grenze = strtotime(date('Y-m-d') . ' 06:45:00');

            // Wenn vor 06:45 eingestempelt wird -> auf 06:45 setzen
            // Sonst echte Zeit übernehmen
            $timeBegin = ($jetzt < $grenze) ? $grenze : $jetzt;

            DisplayToast("success", "$vorname $nachname angemeldet!", "Du hast dich erfolgreich angemeldet!", 5);
            mysqli_query($dbhandle, "INSERT INTO `anwesenheit` (`vorname`, `nachname`, `mitarbeiterid`, `time_begin`) VALUES ('$vorname', '$nachname', '$mid', '$timeBegin')");

            echo "<script>playSound('success');</script>";
        }
        else if($anzahl == 1)
        {
            // Aktuelle Zeit
            $jetzt = time();

            // Heute 06:45 Uhr als Timestamp
            $grenze = strtotime(date('Y-m-d') . ' 16:00:00');

            // Wenn vor 06:45 eingestempelt wird -> auf 06:45 setzen
            // Sonst echte Zeit übernehmen
            $timeBegin = ($jetzt > $grenze) ? $grenze : $jetzt;

            DisplayToast("info", "$vorname $nachname abgemeldet!", "Du hast dich erfolgreich abgemeldet!", 5);
            mysqli_query($dbhandle, "UPDATE `anwesenheit` SET `time_end`='$timeBegin' WHERE `mitarbeiterid`='$mid' AND `time_end` IS NULL");

            echo "<script>playSound('success');</script>";
        }
    }
}
?>

<!doctype html>
<html lang="de-DE" dir="ltr" data-navigation-type="default" data-navbar-horizontal-shape="default" data-bs-theme="dark" class="chrome windows fontawesome-i2svg-active fontawesome-i2svg-complete">
    <head>
        <?php include("includes/head.php"); ?>
    </head>

    <body style="padding: 10px;">
        <main class="main" id="top">
            <div class="container">
                <div class="row flex-center min-vh-100 py-5">   
                    <div class="col-3">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h3 class="mb-1">MITARBEITER</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <form method="POST">
                                        <input class="form-control" type="text" name="karte" placeholder="Mitarbeitername" required autofocus autocomplete="false"/> <hr>
                                        <button type="submit" name="enter" class="btn btn-success form-control">BESTÄTIGEN</button>
                                    </form>

                                    <form method="POST" action="admin.php">
                                        <button type="submit" name="enter" class="btn btn-primary form-control">ADMIN PORTAL</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

            

            <!-- <div class="col-9">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3 class="mb-1">MITARBEITER ANWESEND</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <table class="table table-striped table-sm fs-9 mb-0 table-hover">
                                <thead style="font-size: 20px;">
                                    <tr>
                                        <th class="sort align-middle border-top" data-sort="nummer">#</th>
                                        <th class="sort align-middle border-top" data-sort="dbid">Vorname</th>
                                        <th class="sort align-middle border-top" data-sort="kundennummer">Nachname</th>
                                        <th class="sort align-middle border-top" data-sort="kundennummer">Ankunft</th>
                                    </tr>
                                </thead>
                                <tbody class="list" style="font-size: 20px;">
                                    <?php
                                    $number = 0;
                                    $query      =   mysqli_query($dbhandle, "SELECT * FROM `anwesenheit` WHERE `time_end`='0' ORDER BY `id` DESC");											
                                    while($row = mysqli_fetch_array($query))  
                                    {
                                        $number++;
                                        $mid = $row['mitarbeiterid'];
                                        $start = $row['time_begin'];
                                        
                                        $query2      =   mysqli_query($dbhandle, "SELECT * FROM `mitarbeiter` WHERE `mitarbeiterid`='$mid' LIMIT 1");											
                                        while($row2 = mysqli_fetch_array($query2))  
                                        {
                                            ?>
                                            <tr>
                                            <td class="align-middle"><?php echo "#$number"; ?></td> 
                                            <td class="align-middle"><?php echo $row2['vorname']; ?></td> 
                                            <td class="align-middle"><?php echo $row2['nachname']; ?></td>
                                            <td class="align-middle"><?php echo date("d.m.Y H:i", $start); ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }

                                    if($number == 0)
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="100%;" style="color: red;"><center>Keine anwesenden Mitarbeiter gefunden!</center></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> -->
    </body>

</html>

<?php include("includes/scripts.php"); ?>