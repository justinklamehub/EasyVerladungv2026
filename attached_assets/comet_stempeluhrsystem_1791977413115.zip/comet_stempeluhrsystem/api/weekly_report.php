<?php 
include("../functions.php");

$mitarbeiterid = trim($_GET['mitarbeiterid'] ?? '');
$year = (int)($_GET['year'] ?? 0);
$week = (int)($_GET['week'] ?? 0);

if ($mitarbeiterid === '' || $year < 2000 || $year > 2100 || $week < 1 || $week > 53) {
    http_response_code(400);
    echo "Ungültige Parameter.";
    exit;
}

// ISO Woche -> Montag 00:00 bis Sonntag 23:59:59
$start = new DateTime();
$start->setISODate($year, $week);
$start->setTime(0,0,0);

$end = (clone $start);
$end->modify('+6 days')->setTime(23,59,59);

$startTs = $start->getTimestamp();
$endTs   = $end->getTimestamp();

// Mitarbeiterdaten holen
$stmtM = mysqli_prepare($dbhandle, "SELECT vorname, nachname, dienstleister, tatigkeit FROM mitarbeiter WHERE mitarbeiterid = ? LIMIT 1");
mysqli_stmt_bind_param($stmtM, "s", $mitarbeiterid);
mysqli_stmt_execute($stmtM);
mysqli_stmt_bind_result($stmtM, $vorname, $nachname, $dienstleister, $taetigkeit);
mysqli_stmt_fetch($stmtM);
mysqli_stmt_close($stmtM);

if (!$vorname && !$nachname) {
  http_response_code(404);
  echo "Mitarbeiter nicht gefunden.";
  exit;
}

// Anwesenheit in KW holen
$stmt = mysqli_prepare($dbhandle, "
  SELECT id, time_begin, time_end
  FROM anwesenheit
  WHERE mitarbeiterid = ?
    AND time_begin BETWEEN ? AND ?
  ORDER BY time_begin ASC
");
mysqli_stmt_bind_param($stmt, "sii", $mitarbeiterid, $startTs, $endTs);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

// Hilfsfunktionen
$fmtMin = function(int $min): string {
  if ($min <= 0) return "";
  return floor($min/60).":".str_pad((string)($min%60), 2, "0", STR_PAD_LEFT);
};

$rows = [];
$sumGross = 0; $sumPause = 0; $sumNet = 0;

while ($r = mysqli_fetch_assoc($res)) {
  $tb = (int)($r['time_begin'] ?? 0);
  $te = (int)($r['time_end'] ?? 0);

  $grossMin = 0; $pauseMin = 0; $netMin = 0;
  $status = ($te <= 0) ? "OFFEN" : "OK";

  if ($tb > 0 && $te > 0 && $te >= $tb) {
    $grossMin = (int)(($te - $tb) / 60);

    // Pause-Regel: < 8,5h => 30min | >= 8,5h => 45min
    if($grossMin <= 400) $pauseMin = 15;
    elseif ($grossMin >= 510) $pauseMin = 45;
    elseif ($grossMin >= 401) $pauseMin = 30;

    $netMin = max(0, $grossMin - $pauseMin);

    $sumGross += $grossMin;
    $sumPause += $pauseMin;
    $sumNet   += $netMin;
  }

  $rows[] = [
    'id' => (int)$r['id'],
    'begin' => $tb ? date("d.m.Y H:i", $tb) : "",
    'end'   => $te ? date("d.m.Y H:i", $te) : "",
    'gross' => $fmtMin($grossMin),
    'pause' => $fmtMin($pauseMin),
    'net'   => $fmtMin($netMin),
    'status'=> $status
  ];
}
mysqli_stmt_close($stmt);

$title = "Wochenreport KW {$week}/{$year}";
$range = $start->format("d.m.Y") . " – " . $end->format("d.m.Y");
$today = date("d.m.Y");

require('../../vendor/tecnickcom/tcpdf/tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->setCreator('Justin Klame');
$pdf->setAuthor('Justin Klame');
$pdf->setTitle($title);
$pdf->setSubject('Wochenreport '.$mitarbeiterid.'');
$pdf->setKeywords('PDF, Wochenreport '.$mitarbeiterid.'');
// ---------------------------------------------------------

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(true);

// Add a page
// This method has several options, check the source code documentation for more information.

$pdf->SetMargins(12, 12, 12);
$pdf->SetAutoPageBreak(true, 14);

$pdf->AddPage();
$pdf->SetFont('dejavusans', '', 10);


$h = function($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };
$html = '
<style>
  body { font-family: dejavusans, sans-serif; font-size: 10pt; color: #111; }
  .header { width: 100%; margin-bottom: 10px; }
  .header .left { width: 70%; }
  .header .right { width: 30%; text-align: right; font-size: 9pt; color: #444; }
  h1 { font-size: 16pt; margin: 0; padding: 0; }
  .subtitle { font-size: 10pt; color: #444; margin-top: 2px; }
  .box { border: 1px solid #999; padding: 8px; border-radius: 4px; }
  .meta { width: 100%; margin-top: 8px; }
  .meta td { font-size: 9.5pt; padding: 2px 0; }
  .meta .label { color: #444; width: 28%; }
  .meta .value { font-weight: bold; }

  .tbl { border-collapse: collapse; width: 100%; margin-top: 10px; }
  .tbl th { background: #f2f2f2; font-weight: bold; border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .tbl td { border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .right { text-align: right; }
  .center { text-align: center; }
  .status-open { color: #b58900; font-weight: bold; }

  .totals { width: 100%; margin-top: 10px; border-collapse: collapse; }
  .totals th, .totals td { border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .totals th { background: #f7f7f7; text-align: right; width: 70%; }
  .totals td { text-align: right; width: 30%; }

  .note { margin-top: 10px; font-size: 8.8pt; color: #555; line-height: 1.35; }

  .sign { width: 100%; margin-top: 18px; }
  .sign td { width: 50%; vertical-align: top; }
  .line { border-top: 1px solid #000; width: 80%; margin: 28px auto 6px auto; }
  .siglabel { text-align: center; font-size: 9pt; color: #222; }
  .datebox { margin-top: 8px; font-size: 9pt; color: #222; }
</style>

<table class="header" cellspacing="0" cellpadding="0">
  <tr>
    <td class="left">
      <h1>'.$h($title).'</h1>
      <div class="subtitle">Zeitraum: '.$h($range).'</div>
    </td>
    <td class="right">
      Erstellt am: '.$h($today).'<br>
      MitarbeiterID: '.$h($mitarbeiterid).'
    </td>
  </tr>
</table>

<br>

<div class="box">
  <table class="meta" cellspacing="0" cellpadding="0">
    <tr>
      <td class="label">Mitarbeiter</td>
      <td class="value">'.$h($nachname.', '.$vorname).' ('.$h($mitarbeiterid).')</td>
    </tr>
    <tr>
      <td class="label">Dienstleister</td>
      <td class="value">'.$h($dienstleister ?? '').'</td>
    </tr>
    <tr>
      <td class="label">Tätigkeit</td>
      <td class="value">'.$h($taetigkeit ?? '').'</td>
    </tr>
    <tr>
      <td class="label">Kalenderwoche</td>
      <td class="value">KW '.$h($week).'/'.$h($year).'</td>
    </tr>
  </table>
</div>

<br><br>

<table class="tbl" cellspacing="0" cellpadding="0">
  <thead>
    <tr>
      <th width="30%">Beginn</th>
      <th width="30%">Ende</th>
      <th width="13%" class="right">Brutto</th>
      <th width="13%" class="right">Pause</th>
      <th width="14%" class="right">Netto</th>
    </tr>
  </thead>
  <tbody>
';

foreach ($rows as $r) {
  $statusHtml = ($r['status'] === 'OFFEN')
    ? '<span class="status-open">OFFEN</span>'
    : 'OK';

  $html .= '
    <tr>
      <td width="30%">'.$h($r['begin']).'</td>
      <td width="30%">'.$h($r['end']).'</td>
      <td width="13%" class="right">'.$h($r['gross']).'</td>
      <td width="13%" class="right">'.$h($r['pause']).'</td>
      <td width="14%" class="right"><b>'.$h($r['net']).'</b></td>
    </tr>
  ';
}

$html .= '
  </tbody>
</table>

<br><br>

<table class="totals" cellspacing="0" cellpadding="0">
  <tr>
    <th>Summe Brutto</th>
    <td style="text-align: right;">'.$h($fmtMin($sumGross)).'</td>
  </tr>
  <tr>
    <th>Summe Pause</th>
    <td style="text-align: right;">'.$h($fmtMin($sumPause)).'</td>
  </tr>
  <tr>
    <th><b>Summe Netto</b></th>
    <td style="text-align: right;"><b>'.$h($fmtMin($sumNet)).'</b></td>
  </tr>
</table>
<br>

<div class="note">
  <b>Hinweis:</b> <br>
  Pausenzeit wird gemäß Vorgabe automatisch berechnet: <br>
  - unter 6h = 15 Minuten, <br>
  - unter 8,5h = 30 Minuten, <br>
  - ab 8,5h = 45 Minuten. <br>
</div>

<table class="sign" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <div class="datebox">Datum: ________________________________</div>
      <div class="line"></div>
      <div class="siglabel">Unterschrift ANÜ-Mitarbeiter</div>
      <br><br><hr style="width: 95%;">
    </td>
    <td>
      <div class="datebox">  </div>
      <div class="line"></div>
      <div class="siglabel">Unterschrift COMET Mitarbeiter</div>
      <br><br><hr style="width: 95%;">
    </td>
  </tr>
</table>
';

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 0, 0, true, '', true);

$pdf->Output('Wochenreport_'.$mitarbeiterid.'.pdf', 'I');
//============================================================+
// END OF FILE
//============================================================+