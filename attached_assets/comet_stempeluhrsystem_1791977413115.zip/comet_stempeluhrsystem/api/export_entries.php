<?php
include("../functions.php");

$format = $_GET['format'] ?? 'csv';
$format = strtolower($format);

// Filter aus GET
$only_open  = isset($_GET['only_open']) ? 1 : 0;
$open_first = isset($_GET['open_first']) ? 1 : 0;
$filter_mid = trim($_GET['mid'] ?? '');
$date_from  = trim($_GET['from'] ?? '');
$date_to    = trim($_GET['to'] ?? '');

// Query bauen (wie admin)
$where  = [];
$params = [];
$types  = "";

if ($only_open) {
    $where[] = "(time_end IS NULL OR time_end <= 0)";
}
if ($filter_mid !== "") {
    $where[]  = "mitarbeiterid LIKE ?";
    $params[] = "%".$filter_mid."%";
    $types   .= "s";
}
if ($date_from !== "") {
    $fromTs = strtotime($date_from . " 00:00:00");
    if ($fromTs !== false) {
        $where[]  = "time_begin >= ?";
        $params[] = (int)$fromTs;
        $types   .= "i";
    }
}
if ($date_to !== "") {
    $toTs = strtotime($date_to . " 23:59:59");
    if ($toTs !== false) {
        $where[]  = "time_begin <= ?";
        $params[] = (int)$toTs;
        $types   .= "i";
    }
}

$sql = "
SELECT 
  a.id,
  a.vorname,
  a.nachname,
  a.mitarbeiterid,
  a.time_begin,
  a.time_end,
  m.dienstleister,
  m.tatigkeit
FROM anwesenheit a
LEFT JOIN mitarbeiter m ON m.mitarbeiterid = a.mitarbeiterid
";
if (!empty($where)) $sql .= " WHERE ".implode(" AND ", $where);

if ($open_first) {
    $sql .= " ORDER BY (time_end IS NULL OR time_end <= 0) DESC, time_begin DESC";
} else {
    $sql .= " ORDER BY time_begin DESC";
}

$stmt = mysqli_prepare($dbhandle, $sql);
if (!$stmt) {
    http_response_code(500);
    echo "SQL Fehler: ".mysqli_error($dbhandle);
    exit;
}
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);

// ⚠️ benötigt mysqlnd, sonst sag Bescheid -> ich gebe bind_result Version
$result = mysqli_stmt_get_result($stmt);

$rows = [];
while ($r = mysqli_fetch_assoc($result)) {
    $tb = (int)($r['time_begin'] ?? 0);
    $te = (int)($r['time_end'] ?? 0);

    $r['time_begin_readable'] = $tb ? date("Y-m-d H:i:s", $tb) : "";
    $r['time_end_readable']   = $te ? date("Y-m-d H:i:s", $te) : "";

    $gross_minutes = 0;
    $pauseMin = 0;
    $net_minutes = 0;

    $gross_duration = "";
    $pause_duration = "";
    $net_duration = "";

    if ($tb > 0 && $te > 0 && $te >= $tb) {
        $gross_minutes = (int)(($te - $tb) / 60);

        // Pausenregel: < 8,5h => 30min, >= 8,5h => 45min
        // 8,5h = 510 Minuten
        if($gross_minutes <= 400)
        {
            $pauseMin = 15;
        }
        else if ($gross_minutes >= 510) {
            $pauseMin = 45;
        } else {
            $pauseMin = 30;
        }

        $net_minutes = max(0, $gross_minutes - $pauseMin);

        $gross_duration = floor($gross_minutes/60).":".str_pad($gross_minutes%60, 2, "0", STR_PAD_LEFT);
        $pause_duration = floor($pauseMin/60).":".str_pad($pauseMin%60, 2, "0", STR_PAD_LEFT);
        $net_duration   = floor($net_minutes/60).":".str_pad($net_minutes%60, 2, "0", STR_PAD_LEFT);
    }

    $r['gross_minutes'] = $gross_minutes;
    $r['pause_minutes'] = $pauseMin;
    $r['net_minutes']   = $net_minutes;

    $r['gross_duration'] = $gross_duration;
    $r['pause_duration'] = $pause_duration;
    $r['net_duration']   = $net_duration;

        $rows[] = $r;
}
mysqli_stmt_close($stmt);

// ---------- CSV ----------
if ($format === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="zeiterfassung_export.csv"');

    $out = fopen('php://output', 'w');

    // UTF-8 BOM für Excel (optional)
    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, [
        'ID','Vorname','Nachname','MitarbeiterID','Dienstleister','Tätigkeit','Arbeitsbeginn','Arbeitsende',
        'Gesamtarbeitszeit','Pausenzeit','Arbeitszeit'
      ], ';');      


    foreach ($rows as $r) {
        fputcsv($out, [
            $r['id'],
            $r['vorname'],
            $r['nachname'],
            $r['mitarbeiterid'],
            $r['dienstleister'],
            $r['tatigkeit'],
            $r['time_begin_readable'],
            $r['time_end_readable'],
            $r['gross_duration'],
            $r['pause_duration'],
            $r['net_duration'],
          ], ';');
                  
    }
    fclose($out);
    exit;
}

http_response_code(400);
echo "Ungültiges Format";
