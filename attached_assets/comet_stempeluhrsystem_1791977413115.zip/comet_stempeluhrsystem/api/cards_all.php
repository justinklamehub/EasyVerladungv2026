<?php

include("../functions.php");

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../vendor/tecnickcom/tcpdf/tcpdf.php';

/*
|--------------------------------------------------------------------------
| MITARBEITER LADEN
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        mitarbeiterid,
        vorname,
        nachname,
        dienstleister,
        tatigkeit
    FROM mitarbeiter
    ORDER BY nachname ASC, vorname ASC
";

$result = mysqli_query($dbhandle, $sql);

if (!$result) {
    http_response_code(500);
    die("Fehler beim Laden der Mitarbeiter.");
}

$mitarbeiter = [];

while ($row = mysqli_fetch_assoc($result)) {
    $mitarbeiter[] = $row;
}

if (count($mitarbeiter) === 0) {
    die("Keine Mitarbeiter gefunden.");
}


/*
|--------------------------------------------------------------------------
| PDF ERSTELLEN
|--------------------------------------------------------------------------
*/

$pdf = new TCPDF(
    PDF_PAGE_ORIENTATION,
    PDF_UNIT,
    PDF_PAGE_FORMAT,
    true,
    'UTF-8',
    false
);

$pdf->SetCreator('Justin Klame');
$pdf->SetAuthor('Justin Klame');
$pdf->SetTitle('Alle Mitarbeiter Stempelkarten');
$pdf->SetSubject('Stempelkarten');
$pdf->SetKeywords('PDF, Stempelkarten, Mitarbeiter');

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(false);

$pdf->AddPage();


/*
|--------------------------------------------------------------------------
| KARTEN-EINSTELLUNGEN
|--------------------------------------------------------------------------
|
| ID-1 Kartenformat:
| 85.60 mm x 53.98 mm
|
*/

$cardWidth  = 85.60;
$cardHeight = 53.98;

// Abstand zwischen Karten
$gapX = 8;
$gapY = 8;

// Seitenmaße
$pageWidth  = $pdf->getPageWidth();
$pageHeight = $pdf->getPageHeight();

// Nutzbare Breite für 2 Karten
$totalWidth = ($cardWidth * 2) + $gapX;

// Karten horizontal zentrieren
$startX = ($pageWidth - $totalWidth) / 2;

// Oben starten
$startY = 12;

// Aktuelle Position
$column = 0;
$row    = 0;


/*
|--------------------------------------------------------------------------
| BARCODE GENERATOR
|--------------------------------------------------------------------------
*/

$generator = new Picqer\Barcode\BarcodeGeneratorPNG();


/*
|--------------------------------------------------------------------------
| ALLE MITARBEITER DURCHLAUFEN
|--------------------------------------------------------------------------
*/

foreach ($mitarbeiter as $index => $m) {

    $mitarbeiterid = trim($m['mitarbeiterid']);
    $vorname       = trim($m['vorname']);
    $nachname      = trim($m['nachname']);
    $dienstleister = trim($m['dienstleister'] ?? '');
    $taetigkeit    = trim($m['tatigkeit'] ?? '');

    if ($mitarbeiterid === '') {
        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | POSITION BERECHNEN
    |--------------------------------------------------------------------------
    */

    $cardX = $startX + ($column * ($cardWidth + $gapX));
    $cardY = $startY + ($row * ($cardHeight + $gapY));


    /*
    |--------------------------------------------------------------------------
    | PRÜFEN, OB KARTE NOCH AUF SEITE PASST
    |--------------------------------------------------------------------------
    */

    if (($cardY + $cardHeight) > ($pageHeight - 10)) {

        $pdf->AddPage();

        $column = 0;
        $row    = 0;

        $cardX = $startX;
        $cardY = $startY;
    }


    /*
    |--------------------------------------------------------------------------
    | BARCODE ERSTELLEN
    |--------------------------------------------------------------------------
    */

    try {

        $barcodeBinary = $generator->getBarcode(
            $mitarbeiterid,
            $generator::TYPE_CODE_128
        );

    } catch (Exception $e) {

        // Falls ein Barcode fehlerhaft sein sollte,
        // Mitarbeiter überspringen
        continue;
    }


    /*
    |--------------------------------------------------------------------------
    | KARTENRAHMEN
    |--------------------------------------------------------------------------
    */

    $pdf->SetDrawColor(0, 0, 0);
    $pdf->SetLineWidth(0.25);

    $pdf->Rect(
        $cardX,
        $cardY,
        $cardWidth,
        $cardHeight
    );


    /*
    |--------------------------------------------------------------------------
    | TRENNLINIEN
    |--------------------------------------------------------------------------
    */

    $line1Y = $cardY + 15;
    $line2Y = $cardY + 23;
    $line3Y = $cardY + 31;

    $pdf->Line(
        $cardX,
        $line1Y,
        $cardX + $cardWidth,
        $line1Y
    );

    $pdf->Line(
        $cardX,
        $line2Y,
        $cardX + $cardWidth,
        $line2Y
    );

    $pdf->Line(
        $cardX,
        $line3Y,
        $cardX + $cardWidth,
        $line3Y
    );


    /*
    |--------------------------------------------------------------------------
    | TITEL
    |--------------------------------------------------------------------------
    */

    $pdf->SetTextColor(0, 0, 0);

    $pdf->SetFont(
        'dejavusans',
        'B',
        12
    );

    $pdf->SetXY(
        $cardX,
        $cardY + 4
    );

    $pdf->Cell(
        $cardWidth,
        5,
        'STEMPELKARTE',
        0,
        1,
        'C'
    );


    /*
    |--------------------------------------------------------------------------
    | COMET ANÜ
    |--------------------------------------------------------------------------
    */

    $pdf->SetFont(
        'dejavusans',
        'B',
        10
    );

    $pdf->SetXY(
        $cardX,
        $cardY + 9
    );

    $pdf->Cell(
        $cardWidth,
        4.5,
        'COMET - ANÜ',
        0,
        1,
        'C'
    );


    /*
    |--------------------------------------------------------------------------
    | MITARBEITER-ID
    |--------------------------------------------------------------------------
    */

    $pdf->SetFont(
        'dejavusans',
        'B',
        9
    );

    $pdf->SetXY(
        $cardX,
        $line1Y + 2
    );

    $pdf->Cell(
        $cardWidth,
        4.5,
        $mitarbeiterid,
        0,
        1,
        'C'
    );


    /*
    |--------------------------------------------------------------------------
    | MITARBEITERNAME
    |--------------------------------------------------------------------------
    */

    $pdf->SetFont(
        'dejavusans',
        'B',
        10
    );

    $pdf->SetXY(
        $cardX + 2,
        $line2Y + 2
    );

    $pdf->Cell(
        $cardWidth - 4,
        5.5,
        $nachname . ', ' . $vorname,
        0,
        1,
        'C'
    );


    /*
    |--------------------------------------------------------------------------
    | BARCODE
    |--------------------------------------------------------------------------
    */

    $barcodeW = $cardWidth - 20;
    $barcodeH = 12;

    $barcodeX =
        $cardX +
        (($cardWidth - $barcodeW) / 2);

    $barcodeY =
        $line3Y + 4;


    /*
    |--------------------------------------------------------------------------
    | PNG DIREKT IN PDF EINBETTEN
    |--------------------------------------------------------------------------
    */

    $pdf->Image(
        '@' . $barcodeBinary,
        $barcodeX,
        $barcodeY,
        $barcodeW,
        $barcodeH,
        'PNG'
    );


    /*
    |--------------------------------------------------------------------------
    | NÄCHSTE POSITION
    |--------------------------------------------------------------------------
    */

    $column++;

    // Nach 2 Karten nächste Zeile
    if ($column >= 2) {

        $column = 0;
        $row++;
    }
}


/*
|--------------------------------------------------------------------------
| PDF AUSGEBEN
|--------------------------------------------------------------------------
*/

$pdf->Output(
    'Alle_Stempelkarten.pdf',
    'I'
);

exit;