<?php
header('Content-Type: application/json; charset=utf-8');
include("../functions.php");

// Pflicht
$mitarbeiterid = $_POST['mitarbeiterid'] ?? '';
$tb = $_POST['time_begin'] ?? '';
$te = $_POST['time_end'] ?? '';

if ($mitarbeiterid === '' || $tb === '') {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Mitarbeiter und Beginn sind Pflicht']);
  exit;
}

if (!ctype_digit((string)$tb)) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Ungültiger Beginn-Timestamp']);
  exit;
}
$time_begin = (int)$tb;

$time_end = null;
if ($te !== '') {
  if (!ctype_digit((string)$te)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Ungültiger Ende-Timestamp']);
    exit;
  }
  $time_end = (int)$te;
  if ($time_end < $time_begin) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Ende darf nicht vor Beginn liegen']);
    exit;
  }
}

// Mitarbeiterdaten ziehen (vorname/nachname in anwesenheit speichern, wie bei dir im Schema)
$stmtM = mysqli_prepare($dbhandle, "SELECT vorname, nachname FROM mitarbeiter WHERE mitarbeiterid = ? LIMIT 1");
mysqli_stmt_bind_param($stmtM, "s", $mitarbeiterid);
mysqli_stmt_execute($stmtM);
mysqli_stmt_bind_result($stmtM, $vorname, $nachname);
mysqli_stmt_fetch($stmtM);
mysqli_stmt_close($stmtM);

if (empty($vorname) && empty($nachname)) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Mitarbeiter nicht gefunden']);
  exit;
}

// Insert
$stmt = mysqli_prepare($dbhandle, "INSERT INTO anwesenheit (vorname, nachname, mitarbeiterid, time_begin, time_end) VALUES (?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sssii", $vorname, $nachname, $mitarbeiterid, $time_begin, $time_end);

$ok = mysqli_stmt_execute($stmt);
$err = mysqli_stmt_error($stmt);
mysqli_stmt_close($stmt);

if(!$ok){
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$err ?: 'Insert fehlgeschlagen']);
  exit;
}

echo json_encode(['success'=>true]);
