<?php
header('Content-Type: application/json; charset=utf-8');

include("../functions.php"); // $dbhandle

$vorname  = trim($_POST['vorname'] ?? '');
$nachname = trim($_POST['nachname'] ?? '');
$tatigkeit = trim($_POST['tatigkeit'] ?? '');
$dl = trim($_POST['dl'] ?? '');

if ($vorname === '' || $nachname === '') {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Bitte Vorname und Nachname ausfüllen.']);
  exit;
}

// Eindeutige MitarbeiterID erzeugen: M + YY + 6-stellige Zahl
// Beispiel: M26-000123
function generateId(int $n): string {
  $yy = date("y");
  return "M{$yy}" . str_pad((string)$n, 6, "0", STR_PAD_LEFT);
}

// Nächste Nummer bestimmen (aus vorhandenen IDs)
$yy = date("y");
$prefix = "M{$yy}";

$stmtMax = mysqli_prepare($dbhandle, "SELECT MAX(CAST(SUBSTRING(mitarbeiterid, 5) AS UNSIGNED)) AS mx
                                     FROM mitarbeiter
                                     WHERE mitarbeiterid LIKE CONCAT(?, '%')");
mysqli_stmt_bind_param($stmtMax, "s", $prefix);
mysqli_stmt_execute($stmtMax);
mysqli_stmt_bind_result($stmtMax, $mx);
mysqli_stmt_fetch($stmtMax);
mysqli_stmt_close($stmtMax);

$next = ((int)$mx) + 1;
$mitarbeiterid = generateId($next);

// Insert
$stmt = mysqli_prepare($dbhandle, "INSERT INTO mitarbeiter (vorname, nachname, mitarbeiterid, tatigkeit, dienstleister) VALUES (?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sssss", $vorname, $nachname, $mitarbeiterid, $tatigkeit, $dl);
$ok = mysqli_stmt_execute($stmt);
$err = mysqli_stmt_error($stmt);
mysqli_stmt_close($stmt);

if (!$ok) {
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$err ?: 'Insert fehlgeschlagen']);
  exit;
}

echo json_encode(['success'=>true, 'mitarbeiterid'=>$mitarbeiterid]);
exit;
