<?php
header('Content-Type: application/json; charset=utf-8');
include("../functions.php"); // $dbhandle

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$vorname = trim($_POST['vorname'] ?? '');
$nachname = trim($_POST['nachname'] ?? '');
$dienstleister = trim($_POST['dienstleister'] ?? '');
$taetigkeit = trim($_POST['taetigkeit'] ?? '');

if ($id <= 0) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Ungültige ID']);
  exit;
}
if ($vorname === '' || $nachname === '') {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Vorname und Nachname sind Pflicht.']);
  exit;
}

$stmt = mysqli_prepare($dbhandle, "UPDATE mitarbeiter SET vorname=?, nachname=?, dienstleister=?, tatigkeit=? WHERE id=?");
if (!$stmt) {
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>'Prepare fehlgeschlagen: '.mysqli_error($dbhandle)]);
  exit;
}
mysqli_stmt_bind_param($stmt, "ssssi", $vorname, $nachname, $dienstleister, $taetigkeit, $id);
$ok = mysqli_stmt_execute($stmt);
$err = mysqli_stmt_error($stmt);
mysqli_stmt_close($stmt);

if (!$ok) {
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$err ?: 'Update fehlgeschlagen']);
  exit;
}

echo json_encode(['success'=>true]);
