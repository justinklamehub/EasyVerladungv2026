<?php 
include("../functions.php");

$mitarbeiterid = trim($_GET['mitarbeiterid'] ?? '');

if ($mitarbeiterid === '') {
    http_response_code(400);
    echo "Ungültige Parameter.";
    exit;
}

// Mitarbeiterdaten holen
$stmtM = mysqli_prepare($dbhandle, "SELECT vorname, nachname, dienstleister, tatigkeit FROM mitarbeiter WHERE mitarbeiterid = ? LIMIT 1");
mysqli_stmt_bind_param($stmtM, "s", $mitarbeiterid);
mysqli_stmt_execute($stmtM);
mysqli_stmt_bind_result($stmtM, $vorname, $nachname, $dienstleister, $taetigkeit);
mysqli_stmt_fetch($stmtM);
mysqli_stmt_close($stmtM);

if (!$vorname && !$nachname) {
    http_response_code(404);
    echo "Mitarbeiter nicht gefunden.";
    exit;
}

// Barcode Generator
require_once __DIR__ . '/../vendor/autoload.php';

$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
$code2 = $mitarbeiterid;
$code  = $mitarbeiterid;
foreach (str_split($code) as $key => $c) {
    $code2 .= $c;
    if (count(str_split($code)) != $key) {
        $code2 .= '';
    }
}
$barcode = base64_encode($generator->getBarcode($code, "C128"));

$title = "Mitarbeiter Stempelkarte - $vorname $nachname ($mitarbeiterid)";

require_once __DIR__ . '/../vendor/tecnickcom/tcpdf/tcpdf.php';

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->setCreator('Justin Klame');
$pdf->setAuthor('Justin Klame');
$pdf->setTitle($title);
$pdf->setSubject('Stempelkarte '.$mitarbeiterid.'');
$pdf->setKeywords('PDF, Stempelkarte '.$mitarbeiterid.'');

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(true);

// Seitenränder
$pdf->SetMargins(12, 12, 12);
$pdf->SetAutoPageBreak(true, 14);

$pdf->AddPage();
$pdf->SetFont('dejavusans', '', 10);

$h = function($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };

$html = '
<style>
  body { font-family: dejavusans, sans-serif; font-size: 10pt; color: #111; }
  .header { width: 100%; margin-bottom: 10px; }
  .header .left { width: 70%; }
  .header .right { width: 30%; text-align: right; font-size: 9pt; color: #444; }
  h1 { font-size: 16pt; margin: 0; padding: 0; }
  .subtitle { font-size: 10pt; color: #444; margin-top: 2px; }
  .box { border: 1px solid #999; padding: 8px; border-radius: 4px; }
  .meta { width: 100%; margin-top: 8px; }
  .meta td { font-size: 9.5pt; padding: 2px 0; }
  .meta .label { color: #444; width: 28%; }
  .meta .value { font-weight: bold; }

  .tbl { border-collapse: collapse; width: 100%; margin-top: 10px; }
  .tbl th { background: #f2f2f2; font-weight: bold; border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .tbl td { border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .right { text-align: right; }
  .center { text-align: center; }
  .status-open { color: #b58900; font-weight: bold; }

  .totals { width: 100%; margin-top: 10px; border-collapse: collapse; }
  .totals th, .totals td { border: 1px solid #999; padding: 6px; font-size: 9.5pt; }
  .totals th { background: #f7f7f7; text-align: right; width: 70%; }
  .totals td { text-align: right; width: 30%; }

  .note { margin-top: 10px; font-size: 8.8pt; color: #555; line-height: 1.35; }

  .sign { width: 100%; margin-top: 18px; }
  .sign td { width: 50%; vertical-align: top; }
  .line { border-top: 1px solid #000; width: 80%; margin: 28px auto 6px auto; }
  .siglabel { text-align: center; font-size: 9pt; color: #222; }
  .datebox { margin-top: 8px; font-size: 9pt; color: #222; }
</style>

<table class="header" cellspacing="0" cellpadding="0">
  <tr>
    <td class="left">
      <h1>'.$h($title).'</h1>
    </td>
    <td class="right">
      MitarbeiterID: '.$h($mitarbeiterid).'
    </td>
  </tr>
</table>

<br>

<div class="box">
  <table class="meta" cellspacing="0" cellpadding="0">
    <tr>
      <td class="label">Mitarbeiter</td>
      <td class="value">'.$h($nachname.', '.$vorname).' ('.$h($mitarbeiterid).')</td>
    </tr>
    <tr>
      <td class="label">Dienstleister</td>
      <td class="value">'.$h($dienstleister ?? '').'</td>
    </tr>
    <tr>
      <td class="label">Tätigkeit</td>
      <td class="value">'.$h($taetigkeit ?? '').'</td>
    </tr>
    <tr>
      <td class="label">Barcode</td>
      <td class="value"><img src="data:image/png;base64, '.$barcode.'" alt="barcode"></td>
    </tr>
  </table>
</div>

<br><br>';

// Oberen HTML-Teil ausgeben
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);


/**
 * ----------------------------------------------------------------
 * STEMPELKARTE IM PERSONALAUSWEIS-FORMAT
 * Format ID-1: 85.60 mm × 53.98 mm
 * ----------------------------------------------------------------
 */

// Kartenmaße
$cardWidth  = 85.60;
$cardHeight = 53.98;

// Aktuelle Position nach HTML
$startY = $pdf->GetY() + 4;

// Horizontal zentrieren auf A4
$pageWidth = $pdf->getPageWidth();
$cardX = ($pageWidth - $cardWidth) / 2;
$cardY = $startY;

// Falls Karte unten nicht mehr passt -> neue Seite
$bottomLimit = $pdf->getPageHeight() - 20;
if (($cardY + $cardHeight) > $bottomLimit) {
    $pdf->AddPage();
    $cardY = 20;
}

// Linienbreite / Farbe
$pdf->SetDrawColor(0, 0, 0);
$pdf->SetLineWidth(0.25);

// Außenrahmen
$pdf->Rect($cardX, $cardY, $cardWidth, $cardHeight);

// Bereiche / horizontale Linien
$line1Y = $cardY + 15; // unter Titelblock
$line2Y = $cardY + 23; // unter Mitarbeiter-ID
$line3Y = $cardY + 31; // unter Name

$pdf->Line($cardX, $line1Y, $cardX + $cardWidth, $line1Y);
$pdf->Line($cardX, $line2Y, $cardX + $cardWidth, $line2Y);
$pdf->Line($cardX, $line3Y, $cardX + $cardWidth, $line3Y);

// Titel
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('dejavusans', 'B', 12);
$pdf->SetXY($cardX, $cardY + 4);
$pdf->Cell($cardWidth, 5, 'STEMPELKARTE', 0, 1, 'C', false, '', 0, false, 'T', 'M');

$pdf->SetFont('dejavusans', 'B', 10);
$pdf->SetX($cardX);
$pdf->Cell($cardWidth, 4.5, 'COMET - ANÜ', 0, 1, 'C', false, '', 0, false, 'T', 'M');

// Mitarbeiter-ID
$pdf->SetFont('dejavusans', 'B', 9);
$pdf->SetXY($cardX, $line1Y + 2.2);
$pdf->Cell($cardWidth, 4.5, $mitarbeiterid, 0, 1, 'C', false, '', 0, false, 'T', 'M');

// Name
$pdf->SetFont('dejavusans', 'B', 10);
$pdf->SetXY($cardX + 2, $line2Y + 2.2);
$pdf->Cell($cardWidth - 4, 5.5, $nachname.', '.$vorname, 0, 1, 'C', false, '', 0, false, 'T', 'M');

// Barcode
$barcodeStyle = [
    'align' => 'C',
    'border' => false,
    'padding' => 0,
    'fgcolor' => [0,0,0],
    'bgcolor' => false,
    'text' => false
];

// gewünschte Größe des Barcodes
$barcodeW = $cardWidth - 20; // etwas Rand links/rechts
$barcodeH = 12;

// EXAKT zentrieren
$barcodeX = $cardX + (($cardWidth - $barcodeW) / 2);
$barcodeY = $line3Y + 5;

// Base64 → Bild
$pdf->Image(
    '@'.base64_decode($barcode),
    $barcodeX,
    $barcodeY,
    $barcodeW,
    $barcodeH,
    'PNG'
);

// Optional etwas Platz danach setzen
$pdf->SetY($cardY + $cardHeight + 5);

$pdf->Output('Stempelkarte_'.$mitarbeiterid.'.pdf', 'I');