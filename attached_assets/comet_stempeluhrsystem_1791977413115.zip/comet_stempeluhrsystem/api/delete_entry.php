<?php
header('Content-Type: application/json; charset=utf-8');
include("../functions.php");

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Ungültige ID']);
  exit;
}

$stmt = mysqli_prepare($dbhandle, "DELETE FROM anwesenheit WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
$ok = mysqli_stmt_execute($stmt);
$err = mysqli_stmt_error($stmt);
mysqli_stmt_close($stmt);

if(!$ok){
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$err ?: 'Delete fehlgeschlagen']);
  exit;
}

echo json_encode(['success'=>true]);
