<?php
header('Content-Type: application/json; charset=utf-8');

include("../functions.php"); // $dbhandle

$id    = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$field = $_POST['field'] ?? '';
$value = $_POST['value'] ?? '';

$allowed = ['time_begin','time_end'];
if ($id <= 0 || !in_array($field, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>'Ungültige Eingaben']);
    exit;
}

// value ist Unix-Sekunden oder "" (leer)
$dbValue = null;
if ($value !== '') {
    if (!ctype_digit((string)$value)) {
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>'Ungültiger Timestamp']);
        exit;
    }
    $dbValue = (int)$value;
}

// UPDATE: int oder NULL
$sql = "UPDATE anwesenheit SET $field = ? WHERE id = ?";
$stmt = mysqli_prepare($dbhandle, $sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'Prepare fehlgeschlagen: '.mysqli_error($dbhandle)]);
    exit;
}

mysqli_stmt_bind_param($stmt, "ii", $dbValue, $id);
// ⚠️ bind_param kann NULL nicht als "i" – daher Trick:
if ($dbValue === null) {
    mysqli_stmt_bind_param($stmt, "si", $null = null, $id); // NULL als string param
}
$ok = mysqli_stmt_execute($stmt);
$err = mysqli_stmt_error($stmt);
mysqli_stmt_close($stmt);

if (!$ok) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'Update fehlgeschlagen: '.$err]);
    exit;
}

// Dauer berechnen
$q = mysqli_prepare($dbhandle, "SELECT time_begin, time_end FROM anwesenheit WHERE id = ?");
mysqli_stmt_bind_param($q, "i", $id);
mysqli_stmt_execute($q);
mysqli_stmt_bind_result($q, $tb, $te);
mysqli_stmt_fetch($q);
mysqli_stmt_close($q);

$duration = "";
if (!empty($tb) && !empty($te) && $te >= $tb) {
    $mins = (int)(($te - $tb) / 60);
    $duration = floor($mins/60).":".str_pad($mins%60, 2, "0", STR_PAD_LEFT);
}

echo json_encode([
    'success' => true,
    'unix'    => $dbValue ?? 0,
    'duration'=> $duration
]);
exit;
