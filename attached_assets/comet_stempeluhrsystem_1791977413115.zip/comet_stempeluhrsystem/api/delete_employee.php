<?php
header('Content-Type: application/json; charset=utf-8');
include("../functions.php"); // $dbhandle

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) {
  http_response_code(400);
  echo json_encode(['success'=>false,'error'=>'Ungültige ID']);
  exit;
}

// MitarbeiterID holen (für Check in anwesenheit)
$stmt = mysqli_prepare($dbhandle, "SELECT mitarbeiterid FROM mitarbeiter WHERE id=? LIMIT 1");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $mid);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

if (!$mid) {
  http_response_code(404);
  echo json_encode(['success'=>false,'error'=>'Mitarbeiter nicht gefunden']);
  exit;
}

// Löschen
$stmt3 = mysqli_prepare($dbhandle, "DELETE FROM mitarbeiter WHERE id=?");
mysqli_stmt_bind_param($stmt3, "i", $id);
$ok = mysqli_stmt_execute($stmt3);
$err = mysqli_stmt_error($stmt3);
mysqli_stmt_close($stmt3);

if (!$ok) {
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$err ?: 'Delete fehlgeschlagen']);
  exit;
}

echo json_encode(['success'=>true]);