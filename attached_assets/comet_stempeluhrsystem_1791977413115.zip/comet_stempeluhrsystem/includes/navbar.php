<nav class="navbar navbar-top fixed-top navbar-expand" id="navbarDefault">
	<div class="collapse navbar-collapse justify-content-between">
		<div class="navbar-logo">
			<button class="btn navbar-toggler navbar-toggler-humburger-icon hover-bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#navbarVerticalCollapse" aria-controls="navbarVerticalCollapse" aria-expanded="false" aria-label="Toggle Navigation"><span class="navbar-toggle-icon"><span class="toggle-line"></span></span></button>
			<a class="navbar-brand me-1 me-sm-3" href="?admin=dashboard">
				<div class="d-flex align-items-center">
					<div class="d-flex align-items-center">
						<img src="https://easy-retoure.de/images/imageedit_1_7980017635.png" alt="phoenix" width="120">
						<h5 class="logo-text ms-2 d-none d-sm-block">ZEITERFASSUNG ADMINPORTAL</h5>
					</div>
				</div>
			</a>
		</div>

		<ul class="navbar-nav navbar-nav-icons flex-row">
			<li class="nav-item dropdown">
				<a class="nav-link lh-1 pe-0" id="navbarDropdownUser" href="#!" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-haspopup="true" aria-expanded="false">
					<div class="avatar avatar-l ">
						<img class="rounded-circle " src="https://easy-retoure.de/images/img_avatar.png" alt="">
					</div>
				</a>
				<div class="dropdown-menu dropdown-menu-end navbar-dropdown-caret py-0 dropdown-profile shadow border" aria-labelledby="navbarDropdownUser">
					<div class="card position-relative border-0">
						<div class="card-body p-0">
							<div class="text-center pt-4 pb-3">
								<div class="avatar avatar-xl ">
									<img class="rounded-circle " src="https://easy-retoure.de/images/img_avatar.png" alt="">
								</div>
								<h6 class="mt-2 text-body-emphasis">Leitstand</h6>
							</div>
						</div>
						<div class="card-footer p-1 border-top border-translucent">
							<div class="px-3"> 
								<a class="btn btn-phoenix-danger d-flex flex-center w-100" href="../logout.php"> 
									<i class="fas fa-sign-out-alt me-2"></i> Abmelden
								</a>
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</nav> 