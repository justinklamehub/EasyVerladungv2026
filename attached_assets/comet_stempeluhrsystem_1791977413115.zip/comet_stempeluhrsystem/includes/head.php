<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- ===============================================-->
<!-- TITLE DER WEBSEITE -->
<!-- ===============================================-->
<title>Mitarbeitererfassung</title>
<!-- ===============================================-->
<!-- FAVICONS -->
<!-- ===============================================-->
<meta name="theme-color" content="#0f111a">
<!-- ===============================================-->
<!-- STYLESHEETS -->
<!-- ===============================================-->
<link href="https://prium.github.io/phoenix/v1.20.1/assets/css/theme-rtl.min.css" type="text/css" rel="stylesheet" id="style-rtl">
<link href="https://prium.github.io/phoenix/v1.20.1/assets/css/theme.min.css" type="text/css" rel="stylesheet" id="style-default">
<link href="https://prium.github.io/phoenix/v1.20.1/assets/css/user-rtl.min.css" type="text/css" rel="stylesheet" id="user-style-rtl">
<link href="https://prium.github.io/phoenix/v1.20.1/assets/css/user.min.css" type="text/css" rel="stylesheet" id="user-style-default">
<link href="https://prium.github.io/phoenix/v1.20.1/vendors/flatpickr/flatpickr.min.css" rel="stylesheet" />

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css" rel="stylesheet" type="text/css" />
<link href="https://prium.github.io/phoenix/v1.20.1/vendors/choices/choices.min.css" rel="stylesheet" />

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js"></script>

<meta charset="utf-8">

<style>
    td.editable { cursor: pointer; }
    td.editable:hover { background: #646f8f; }
    .cell-saving { opacity: .6; }
    .cell-error { outline: 2px solid #dc3545; }
    .cell-ok { outline: 2px solid #198754; }
  </style>