<!-- ===============================================-->
<!-- JAVASCRIPTS -->
<!-- ===============================================-->
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/popper/popper.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/bootstrap/bootstrap.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/anchorjs/anchor.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/is/is.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/fontawesome/all.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/lodash/lodash.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/list.js/list.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/feather-icons/feather.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/dayjs/dayjs.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/assets/js/phoenix.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/assets/js/flatpickr.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/prism/prism.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/choices/choices.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/leaflet/leaflet.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/leaflet.markercluster/leaflet.markercluster.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/leaflet.tilelayer.colorfilter/leaflet-tilelayer-colorfilter.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/vendors/echarts/echarts.min.js"></script>
<script src="https://prium.github.io/phoenix/v1.20.1/assets/js/ecommerce-dashboard.js"></script>
<!-- ===============================================-->
<!-- LIGHT/DARK -->
<!-- ===============================================-->
<script nonce="<?= $nonce ?>">
    document.getElementById("themeControlToggle").onclick = function()
    {
        var checkbox = document.getElementById("themeControlToggle");

        if(checkbox.value == "dark")
        {
            var element = document.querySelector("#html");
            element.classList.replace("dark", "light");

            checkbox.value = "light";
        }
        else
        {            
            var element = document.querySelector("#html");
            element.classList.replace("light", "dark");

            checkbox.value = "dark";
        }
    };
</script>

<script nonce="<?= $nonce ?>">
    $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

<script>
function containsHTMLorJS(value) {
    const patterns = [
        /<\s*script/gi,           // <script>
        /<[^>]+>/g,               // irgendein HTML-Tag
        /on\w+\s*=/gi,            // onerror= onclick=
        /javascript:/gi
    ];

    return patterns.some(rx => rx.test(value));
}
</script>