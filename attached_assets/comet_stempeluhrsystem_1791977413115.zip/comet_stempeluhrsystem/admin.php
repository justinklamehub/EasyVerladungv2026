<?php
include('functions.php');

$username = "Leitstand";
$year = date("Y");
$password = "Leitstand";

function ts_to_input($ts) {
    $ts = (int)$ts;
    return $ts > 0 ? date("Y-m-d\\TH:i", $ts) : "";
}
function ts_to_display($ts) {
    $ts = (int)$ts;
    return $ts > 0 ? date("d.m.Y H:i", $ts) : "";
}

?>
<html lang="de-DE" dir="ltr" data-navigation-type="default" data-navbar-horizontal-shape="default" data-bs-theme="dark" class="chrome windows fontawesome-i2svg-active fontawesome-i2svg-complete">
    <head>
        <?php include("includes/head.php"); ?>
    </head>
	<?php include("includes/scripts.php"); ?>
<!-- Admin Bereich hier / Nach Login  -->
<body>
	<main class="main" id="top">
		<?php include("includes/navbar.php"); ?>

		<div class="content" style="margin-right: 0px;">

		<?php
		$only_open  = isset($_GET['only_open']) ? 1 : 0;
		$open_first = isset($_GET['open_first']) ? 1 : 0;

		$filter_mid = trim($_GET['mid'] ?? '');
		$date_from  = trim($_GET['from'] ?? '');
		$date_to    = trim($_GET['to'] ?? '');

		// Quick ranges
		$today = date("Y-m-d");

		// ISO-Woche (Mo-So)
		$weekStart = date("Y-m-d", strtotime("monday this week"));
		$weekEnd   = date("Y-m-d", strtotime("sunday this week"));

		// Monat
		$monthStart = date("Y-m-01");
		$monthEnd   = date("Y-m-t");

		// Letzte 7 Tage
		$last7Start = date("Y-m-d", strtotime("-6 days"));
		$last7End   = $today;

		// Helper: Basis-Parameter beibehalten (z.B. mid, only_open, open_first)
		$base = [
		'mid' => $filter_mid,
		// Checkboxen bewusst nicht hardcoden – wird pro Button gesetzt
		];

		?>

<form method="get" class="card mb-3 p-3">
  <div class="row g-2 align-items-end">

    <div class="col-md-3">
      <label class="form-label">MitarbeiterID</label>
      <input type="text" class="form-control" name="mid" value="<?=htmlspecialchars($filter_mid)?>" placeholder="z.B. 1234">
    </div>

    <div class="col-md-3">
      <label class="form-label">Von (Datum)</label>
      <input type="date" class="form-control" name="from" value="<?=htmlspecialchars($date_from)?>">
    </div>

    <div class="col-md-3">
      <label class="form-label">Bis (Datum)</label>
      <input type="date" class="form-control" name="to" value="<?=htmlspecialchars($date_to)?>">
    </div>

    <div class="col-md-3 d-flex gap-3">
      <div class="form-check mt-4">
        <input class="form-check-input" type="checkbox" id="only_open" name="only_open" <?= $only_open ? "checked" : "" ?>>
        <label class="form-check-label" for="only_open">Nur offene</label>
      </div>

      <div class="form-check mt-4">
        <input class="form-check-input" type="checkbox" id="open_first" name="open_first" <?= $open_first ? "checked" : "" ?>>
        <label class="form-check-label" for="open_first">Offene zuerst</label>
      </div>
    </div>

  </div>

  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Filtern</button>
    <a class="btn btn-outline-secondary" href="admin.php">Zurücksetzen</a>
  </div>

  <div class="mt-3 d-flex flex-wrap gap-2">
  <?php
    // Button-Links bauen
    $btnToday = "admin.php?".http_build_query(array_merge($base, [
      'from' => $today, 'to' => $today,
      'only_open' => $only_open ? 1 : null,
      'open_first' => $open_first ? 1 : null
    ]));

    $btnWeek = "admin.php?".http_build_query(array_merge($base, [
      'from' => $weekStart, 'to' => $weekEnd,
      'only_open' => $only_open ? 1 : null,
      'open_first' => $open_first ? 1 : null
    ]));

    $btnMonth = "admin.php?".http_build_query(array_merge($base, [
      'from' => $monthStart, 'to' => $monthEnd,
      'only_open' => $only_open ? 1 : null,
      'open_first' => $open_first ? 1 : null
    ]));

    $btnLast7 = "admin.php?".http_build_query(array_merge($base, [
      'from' => $last7Start, 'to' => $last7End,
      'only_open' => $only_open ? 1 : null,
      'open_first' => $open_first ? 1 : null
    ]));

    $btnOpen = "admin.php?".http_build_query(array_merge($base, [
      'only_open' => 1,
      'open_first' => 1,
      'from' => $date_from ?: null,
      'to' => $date_to ?: null
    ]));
  ?>

  <a class="btn btn-outline-info btn-sm" href="<?=htmlspecialchars($btnToday)?>">Heute</a>
  <a class="btn btn-outline-info btn-sm" href="<?=htmlspecialchars($btnWeek)?>">Diese Woche</a>
  <a class="btn btn-outline-info btn-sm" href="<?=htmlspecialchars($btnMonth)?>">Dieser Monat</a>
  <a class="btn btn-outline-info btn-sm" href="<?=htmlspecialchars($btnLast7)?>">Letzte 7 Tage</a>

  <a class="btn btn-outline-warning btn-sm" href="<?=htmlspecialchars($btnOpen)?>">Nur offene</a>

  <!-- NEU: Export -->
  <div class="btn-group">
    <a class="btn btn-outline-info" href="<?= htmlspecialchars('api/export_entries.php?'.http_build_query(array_merge($_GET, ['format'=>'csv']))) ?>">
      Export CSV
    </a>
  </div>

  <button class="btn btn-primary"
          type="button"
          data-bs-toggle="modal"
          data-bs-target="#modalNewEntry">
    + Eintrag anlegen
  </button>

  <button class="btn btn-outline-light" type="button" data-bs-toggle="modal" data-bs-target="#modalEmployees">
    Mitarbeiter auflisten
  </button>

  <button class="btn btn-success" style="float: right;"
          type="button"
          data-bs-toggle="modal"
          data-bs-target="#modalNewEmployee">
    + Mitarbeiter anlegen
  </button>

  <a href="api/cards_all.php" target="_blank" class="btn btn-primary">
    Alle Stempelkarten / Barcodes anzeigen
</a>
</div>

</form>


		<?php
		// Mitarbeiter-Liste für Dropdown
		$mitarbeiter = [];
		$qm = mysqli_query($dbhandle, "SELECT id, vorname, nachname, mitarbeiterid FROM mitarbeiter ORDER BY nachname, vorname");
		while($m = mysqli_fetch_assoc($qm)) $mitarbeiter[] = $m;
		?>

			<div class="table-responsive">
				<table class="table table-bordered table-hover table-striped align-middle" >
					<thead class="table-dark">
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>MitarbeiterID</th>
							<th>Beginn</th>
							<th>Ende</th>
							<th>Pausenzeit</th>
							<th>Dauer</th>
							<th>Aktionen</th>
						</tr>
					</thead>

					<tbody>
					<?php
					$where  = [];
					$params = [];
					$types  = "";
					
					// Nur offene (time_end NULL oder 0)
					if ($only_open) {
						$where[] = "(time_end IS NULL OR time_end <= 0)";
					}
					
					// MitarbeiterID Filter
					if ($filter_mid !== "") {
						$where[]  = "mitarbeiterid LIKE ?";
						$params[] = "%".$filter_mid."%";
						$types   .= "s";
					}
					
					// Datum von/bis (Unix time_begin)
					if ($date_from !== "") {
						$fromTs = strtotime($date_from . " 00:00:00");
						if ($fromTs !== false) {
							$where[]  = "time_begin >= ?";
							$params[] = (int)$fromTs;
							$types   .= "i";
						}
					}
					
					if ($date_to !== "") {
						$toTs = strtotime($date_to . " 23:59:59");
						if ($toTs !== false) {
							$where[]  = "time_begin <= ?";
							$params[] = (int)$toTs;
							$types   .= "i";
						}
					}
					
					$sql = "SELECT * FROM anwesenheit";
					if (!empty($where)) {
						$sql .= " WHERE " . implode(" AND ", $where);
					}
					
					if ($open_first) {
						$sql .= " ORDER BY (time_end IS NULL OR time_end <= 0) DESC, time_begin DESC";
					} else {
						$sql .= " ORDER BY time_begin DESC";
					}
					
					$stmt = mysqli_prepare($dbhandle, $sql);
					if (!$stmt) {
						die("SQL Fehler: ".mysqli_error($dbhandle));
					}
					if (!empty($params)) {
						mysqli_stmt_bind_param($stmt, $types, ...$params);
					}
					mysqli_stmt_execute($stmt);
					
					// benötigt mysqlnd – wenn bei dir nicht vorhanden, sag Bescheid, dann baue ich es ohne get_result()
					$result = mysqli_stmt_get_result($stmt);
					
					while($row = mysqli_fetch_assoc($result)) 
					{

						$id = (int)($row['id'] ?? 0);

						$vorname = $row['vorname'] ?? '';
						$nachname = $row['nachname'] ?? '';
						$mid = $row['mitarbeiterid'] ?? '';

						$tb = (int)($row['time_begin'] ?? 0);
						$te = (int)($row['time_end'] ?? 0);

						// Dauer (hh:mm)
						$dauer = "";
						$pauseMin = 0;

						if ($tb > 0 && $te > 0 && $te >= $tb) {

							$mins = (int)(($te - $tb) / 60);

                            // Pausenregel
                            if($mins <= 400)
                            {   
                                $pauseMin = 15;
                            }
                            elseif ($mins >= 510) {          // 8,5h = 510 Minuten
								$pauseMin = 45;
							} elseif ($mins >= 360) {
								$pauseMin = 30;
                            }

							$arbeitsMin = max(0, $mins - $pauseMin);

							$dauer = floor($arbeitsMin/60) . ":" . str_pad($arbeitsMin%60, 2, "0", STR_PAD_LEFT);
						}

						$pauseDisplay = $pauseMin > 0 ? floor($pauseMin/60) . ":" . str_pad($pauseMin%60, 2, "0", STR_PAD_LEFT): "";


						$tb_input = ts_to_input($tb);
						$te_input = ts_to_input($te);

						$tb_disp = ts_to_display($tb);
						$te_disp = ts_to_display($te);



						$isOpen = ($te <= 0); // offen wenn time_end 0/NULL
						$rowClass = $isOpen ? "table-warning" : "";
						echo "<tr class='{$rowClass}'>";

						echo "<td>{$id}</td>";
						echo "<td>".htmlspecialchars($vorname." ".$nachname)."</td>";
						echo "<td>".htmlspecialchars($mid)."</td>";

						echo "<td class='editable'
								data-id='{$id}'
								data-field='time_begin'
								data-value='".htmlspecialchars($tb_input)."'>"
								.htmlspecialchars($tb_disp).
							"</td>";

						echo "<td class='editable'
								data-id='{$id}'
								data-field='time_end'
								data-value='".htmlspecialchars($te_input)."'>"
								.htmlspecialchars($te_disp).
							"</td>";

						echo "<td>".htmlspecialchars($pauseDisplay)."</td>";
						echo "<td class='duration'>".htmlspecialchars($dauer)."</td>";

						echo "<td>
								<button type='button' class='btn btn-danger btn-sm btn-delete'
										data-id='{$id}'>Löschen</button>
								</td>";

						echo "</tr>";
					}
					?>
					</tbody>
				</table>
			</div>
			
		</div>
	</main>
</body>

<div class="modal fade" id="modalNewEmployee" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Neuen Mitarbeiter anlegen</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Schließen"></button>
      </div>

      <div class="modal-body">
		<form id="formNewEmployee" class="row g-3">
			<div class="col-md-6">
				<label class="form-label">Vorname</label>
				<input type="text" class="form-control" name="vorname" required>
			</div>

			<div class="col-md-6">
				<label class="form-label">Nachname</label>
				<input type="text" class="form-control" name="nachname" required>
			</div>

			<div class="col-md-6">
				<label class="form-label">Dienstleister</label>
				<input type="text" class="form-control" name="dienstleister" required>
			</div>

			<div class="col-md-6">
				<label class="form-label">Tätigkeit</label>
				<input type="text" class="form-control" name="tatigkeit" required>
			</div>
			</form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Abbrechen</button>
        <button type="button" class="btn btn-success" id="btnCreateEmployee">Anlegen</button>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="modalNewEntry" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Neuen Eintrag manuell anlegen</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Schließen"></button>
      </div>

      <div class="modal-body">
        <form id="formNewEntry" class="row g-3">

          <div class="col-md-6">
            <label class="form-label">Mitarbeiter</label>
            <select class="form-select" name="mitarbeiterid" required>
              <option value="">Bitte wählen…</option>
              <?php foreach($mitarbeiter as $m): ?>
                <option value="<?=htmlspecialchars($m['mitarbeiterid'])?>">
                  <?=htmlspecialchars($m['nachname'].", ".$m['vorname']." (".$m['mitarbeiterid'].")")?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-3">
            <label class="form-label">Beginn</label>
            <input type="datetime-local" class="form-control" name="time_begin" required>
          </div>

          <div class="col-md-3">
            <label class="form-label">Ende (optional)</label>
            <input type="datetime-local" class="form-control" name="time_end">
          </div>

        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Abbrechen</button>
        <button type="button" class="btn btn-primary" id="btnCreateEntry">Anlegen</button>
      </div>

    </div>
  </div>
</div>

<?php
// Mitarbeiter für Liste laden (einmalig)
$mitarbeiter_list = [];
$qml = mysqli_query($dbhandle, "SELECT * FROM mitarbeiter ORDER BY nachname, vorname");
while($m = mysqli_fetch_assoc($qml)) $mitarbeiter_list[] = $m;
?>

<?php
// Mitarbeiter laden (inkl. dienstleister/taetigkeit falls vorhanden)
$mitarbeiter_list = [];
$qml = mysqli_query($dbhandle, "SELECT id, vorname, nachname, mitarbeiterid, dienstleister, tatigkeit FROM mitarbeiter ORDER BY nachname, vorname");
while($m = mysqli_fetch_assoc($qml)) $mitarbeiter_list[] = $m;
?>

<div class="modal fade" id="modalEmployees" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Mitarbeiter</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Schließen"></button>
      </div>

      <div class="modal-body">
        <div class="table-responsive">
          <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>Mitarbeiter</th>
                <th>Vorname</th>
                <th>Nachname</th>
                <th>Dienstleister</th>
                <th>Tätigkeit</th>
				<th style="width:260px;">Report</th>
                <th style="width:180px;">Aktionen</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($mitarbeiter_list as $m): ?>
                <tr data-id="<?= (int)$m['id'] ?>">
                  <td><span class="badge bg-secondary"><?= htmlspecialchars($m['mitarbeiterid']) ?></span></td>

                  <td>
                    <input class="form-control form-control-sm emp-vorname"
                           value="<?= htmlspecialchars($m['vorname'] ?? '') ?>">
                  </td>
                  <td>
                    <input class="form-control form-control-sm emp-nachname"
                           value="<?= htmlspecialchars($m['nachname'] ?? '') ?>">
                  </td>
                  <td>
                    <input class="form-control form-control-sm emp-dienstleister"
                           value="<?= htmlspecialchars($m['dienstleister'] ?? '') ?>">
                  </td>
                  <td>
                    <input class="form-control form-control-sm emp-taetigkeit"
                           value="<?= htmlspecialchars($m['tatigkeit'] ?? '') ?>">
                  </td>

					<td>
					<div class="d-flex gap-2 align-items-center">
						<input type="week" class="form-control form-control-sm emp-week" value="<?= date('Y-\WW') ?>">
						<button type="button" class="btn btn-outline-info btn-sm btn-weekly-pdf"
								data-mitarbeiterid="<?= htmlspecialchars($m['mitarbeiterid']) ?>">
						PDF
						</button>
					</div>
					</td>

                  <td class="d-flex gap-2">
                    <button type="button" class="btn btn-primary btn-sm btn-emp-card" data-mitarbeiterid="<?= htmlspecialchars($m['mitarbeiterid']) ?>"><i class="fa-solid fa-address-card"></i></button>
                    <button type="button" class="btn btn-success btn-sm btn-emp-save"><i class="fa-solid fa-floppy-disk"></i></button>
                    <button type="button" class="btn btn-danger btn-sm btn-emp-del"><i class="fa-solid fa-trash"></i></button>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Schließen</button>
      </div>

    </div>
  </div>
</div>




<script>
// --- Helpers ---
function datetimeLocalToUnixSeconds(v) {
  // v = "YYYY-MM-DDTHH:MM"
  if (!v) return ""; // leer -> NULL/0 je nach Serverlogik
  const d = new Date(v);
  if (isNaN(d.getTime())) return "";
  return Math.floor(d.getTime() / 1000);
}

function unixSecondsToDisplay(sec) {
  sec = Number(sec || 0);
  if (!sec) return "";
  const d = new Date(sec * 1000);
  const pad = n => String(n).padStart(2, "0");
  return `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// --- Inline edit on click ---
document.addEventListener("click", function(e) {
  const td = e.target.closest("td.editable");
  if (!td) return;
  if (td.querySelector("input")) return;

  const current = td.dataset.value || ""; // datetime-local
  const oldText = td.textContent;

  const input = document.createElement("input");
  input.type = "datetime-local";
  input.className = "form-control form-control-sm";
  input.value = current;

  td.textContent = "";
  td.appendChild(input);
  input.focus();

  const finish = (commit) => {
    if (!commit) {
      td.innerHTML = "";
      td.textContent = oldText;
      return;
    }
    saveCell(td, input.value, oldText);
  };

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") finish(true);
    if (ev.key === "Escape") finish(false);
  });

  input.addEventListener("blur", () => finish(true));
});

// --- Save cell via AJAX ---
function saveCell(td, datetimeLocalValue, oldText) {
  const unix = datetimeLocalToUnixSeconds(datetimeLocalValue);

  td.classList.add("cell-saving");
  td.classList.remove("cell-error", "cell-ok");

  fetch("api/update_time.php", {
    method: "POST",
    headers: {"Content-Type":"application/x-www-form-urlencoded"},
    body: "id="+encodeURIComponent(td.dataset.id)+
          "&field="+encodeURIComponent(td.dataset.field)+
          "&value="+encodeURIComponent(unix)
  })
  .then(async (res) => {
    const txt = await res.text();
    // BOM entfernen + trim
    const cleaned = txt.replace(/^\uFEFF/, "").trim();

    // Debug bei 500/HTML
    if (!res.ok) {
      console.error("HTTP", res.status, cleaned);
      throw new Error("Serverfehler (HTTP " + res.status + ")");
    }

    try {
      return JSON.parse(cleaned);
    } catch (e) {
      console.error("Antwort ist kein JSON:", cleaned);
      throw new Error("Server lieferte kein JSON (siehe Konsole)");
    }
  })
  .then((data) => {
    if (!data.success) throw new Error(data.error || "Unbekannter Fehler");

	toastr.success('Gespeichert!', '', {
        timeOut: 3000,
        progressBar: true,
        showDuration: 300,
        hideDuration: 100
    });

    // wir speichern weiterhin den datetime-local Wert fürs nächste Öffnen
    td.dataset.value = datetimeLocalValue || "";

    // Anzeige aus der Server-Rückgabe (Unix)
    td.innerHTML = "";
    td.textContent = unixSecondsToDisplay(data.unix);

    // Dauer updaten
    const durTd = td.parentElement.querySelector(".duration");
    if (durTd) durTd.textContent = data.duration || "";

    td.classList.add("cell-ok");
    setTimeout(() => td.classList.remove("cell-ok"), 600);
  })
  .catch((err) => {
    td.classList.add("cell-error");
    alert(err.message);
    td.innerHTML = "";
    td.textContent = oldText;
  })
  .finally(() => {
    td.classList.remove("cell-saving");
  });
}

function unixFromLocal(v){
  if(!v) return "";
  const d = new Date(v);
  if(isNaN(d.getTime())) return "";
  return Math.floor(d.getTime()/1000);
}

// ✅ Eintrag anlegen (Modal Button)
document.getElementById("btnCreateEntry")?.addEventListener("click", function(){
  const form = document.getElementById("formNewEntry");
  if(!form) return;

  if(!form.reportValidity()) return;

  const fd = new FormData(form);
  const mitarbeiterid = (fd.get("mitarbeiterid") || "").toString().trim();
  const time_begin = unixFromLocal(fd.get("time_begin"));
  const time_end   = unixFromLocal(fd.get("time_end"));

  fetch("api/create_entry.php", {
    method: "POST",
    headers: {"Content-Type":"application/x-www-form-urlencoded"},
    body: "mitarbeiterid="+encodeURIComponent(mitarbeiterid)+
          "&time_begin="+encodeURIComponent(time_begin)+
          "&time_end="+encodeURIComponent(time_end)
  })
  .then(res => res.text())
  .then(txt => {
    const data = JSON.parse(txt.replace(/^\uFEFF/, "").trim());
    if(!data.success) throw new Error(data.error || "Fehler");

    toastr.success("Erfolg!", "Eintrag angelegt");

    // Modal schließen
    const modalEl = document.getElementById("modalNewEntry");
    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modal.hide();

    // reset
    form.reset();

    // Tabelle aktualisieren (einfach & zuverlässig)
    location.reload();
  })
  .catch(err => {
    console.error(err);
    toastr.error(err.message, "Fehler");
  });
});


// ✅ Eintrag löschen
document.addEventListener("click", function(e){
  const btn = e.target.closest(".btn-delete");
  if(!btn) return;

  const id = btn.dataset.id;
  if(!confirm("Eintrag wirklich löschen?")) return;

  fetch("api/delete_entry.php", {
    method: "POST",
    headers: {"Content-Type":"application/x-www-form-urlencoded"},
    body: "id="+encodeURIComponent(id)
  })
  .then(res => res.text())
  .then(txt => {
    const data = JSON.parse(txt.replace(/^\uFEFF/, "").trim());
    if(!data.success) throw new Error(data.error || "Fehler");
    toastr.success("", "Eintrag gelöscht");
    btn.closest("tr")?.remove();
  })
  .catch(err => {
    console.error(err);
    toastr.error(err.message, "Fehler");
  });
});

document.getElementById("btnCreateEmployee")?.addEventListener("click", function () {
  const form = document.getElementById("formNewEmployee");
  if (!form) return;

  // HTML5 Validation
  if (!form.reportValidity()) return;

  const fd = new FormData(form);
  const vorname = (fd.get("vorname") || "").toString().trim();
  const nachname = (fd.get("nachname") || "").toString().trim();
  const tatigkeit = (fd.get("tatigkeit") || "").toString().trim();
  const dienstleister = (fd.get("dienstleister") || "").toString().trim();

  fetch("api/create_employee.php", {
  method: "POST",
  headers: {"Content-Type":"application/x-www-form-urlencoded"},
  body: "vorname="+encodeURIComponent(vorname)+
        "&nachname="+encodeURIComponent(nachname)+
		"&tatigkeit="+encodeURIComponent(tatigkeit)+
		"&dl="+encodeURIComponent(dienstleister)
	})
	.then(async (res) => {
	const txt = await res.text();
	const cleaned = txt.replace(/^\uFEFF/, "").trim();

	if (!res.ok) {
		console.error("HTTP", res.status, cleaned);
		throw new Error("Serverfehler (HTTP " + res.status + ")");
	}

	try {
		return JSON.parse(cleaned);
	} catch (e) {
		console.error("Antwort ist kein JSON:", cleaned);
		throw new Error("Server lieferte HTML statt JSON (siehe Konsole)");
	}
	})
	.then((data) => {
	if(!data.success) throw new Error(data.error || "Fehler");
	toastr.success("Mitarbeiter angelegt: " + data.mitarbeiterid, "Erfolg!");
	location.reload();
	})
	.catch(err => {
	toastr.error(err.message, "Fehler");
	});

});

function postFormUrlEncoded(url, dataObj) {
  const body = Object.entries(dataObj)
    .map(([k,v]) => encodeURIComponent(k) + "=" + encodeURIComponent(v ?? ""))
    .join("&");

  return fetch(url, {
    method: "POST",
    headers: {"Content-Type":"application/x-www-form-urlencoded"},
    body
  })
  .then(async res => {
    const txt = (await res.text()).replace(/^\uFEFF/, "").trim();
    if (!res.ok) {
      console.error("HTTP", res.status, txt);
      throw new Error("Serverfehler (HTTP " + res.status + ")");
    }
    let json;
    try { json = JSON.parse(txt); }
    catch { throw new Error("Server lieferte kein JSON (siehe Konsole)"); }
    if (!json.success) throw new Error(json.error || "Fehler");
    return json;
  });
}

// ✅ Mitarbeiter speichern
document.addEventListener("click", function(e){
  const btn = e.target.closest(".btn-emp-save");
  if(!btn) return;

  const tr = btn.closest("tr[data-id]");
  const id = tr.dataset.id;

  const vorname = tr.querySelector(".emp-vorname")?.value.trim() || "";
  const nachname = tr.querySelector(".emp-nachname")?.value.trim() || "";
  const dienstleister = tr.querySelector(".emp-dienstleister")?.value.trim() || "";
  const taetigkeit = tr.querySelector(".emp-taetigkeit")?.value.trim() || "";

  btn.disabled = true;

  postFormUrlEncoded("api/update_employee.php", { id, vorname, nachname, dienstleister, taetigkeit })
    .then(() => {
      toastr.success("Gespeichert!", "");
    })
    .catch(err => {
      console.error(err);
      toastr.error(err.message, "Fehler");
    })
    .finally(() => btn.disabled = false);
});

// ✅ Mitarbeiter löschen
document.addEventListener("click", function(e){
  const btn = e.target.closest(".btn-emp-del");
  if(!btn) return;

  const tr = btn.closest("tr[data-id]");
  const id = tr.dataset.id;

  if(!confirm("Mitarbeiter wirklich löschen? (nur möglich ohne Anwesenheits-Einträge)")) return;

  btn.disabled = true;

  postFormUrlEncoded("api/delete_employee.php", { id })
    .then(() => {
      toastr.success("Mitarbeiter gelöscht!", "");
      tr.remove();
    })
    .catch(err => {
      console.error(err);
      toastr.error(err.message, "Fehler");
    })
    .finally(() => btn.disabled = false);
});

document.addEventListener("click", function(e){
  const btn = e.target.closest(".btn-emp-card");
  if(!btn) return;

  const mid = btn.dataset.mitarbeiterid;

    const url = `api/card.php?mitarbeiterid=${encodeURIComponent(mid)}`;
    window.open(url, "_blank");

});

document.addEventListener("click", function(e){
  const btn = e.target.closest(".btn-weekly-pdf");
  if(!btn) return;

  const tr = btn.closest("tr");
  const weekInput = tr.querySelector(".emp-week");
  const val = (weekInput?.value || "").trim(); // "YYYY-Www"

  if(!val || !val.includes("-W")) {
    toastr.error("Bitte eine Kalenderwoche auswählen.", "Fehler");
    return;
  }

  const [yearStr, weekStr] = val.split("-W");
  const year = parseInt(yearStr, 10);
  const week = parseInt(weekStr, 10);

  if(!year || !week) {
    toastr.error("Ungültige Kalenderwoche.", "Fehler");
    return;
  }

  const mid = btn.dataset.mitarbeiterid;

  const url = `api/weekly_report.php?mitarbeiterid=${encodeURIComponent(mid)}&year=${encodeURIComponent(year)}&week=${encodeURIComponent(week)}`;
  window.open(url, "_blank");
});

</script>

