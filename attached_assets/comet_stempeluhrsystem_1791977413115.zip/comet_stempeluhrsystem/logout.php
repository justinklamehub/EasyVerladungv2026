<?php
include('../functions.php');

if(isset($_SESSION['loggedin'])) 
{ 
	unset($_SESSION['loggedin']); 
}

header('location: index.php');
